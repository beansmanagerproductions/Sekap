import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { db, subscribeToDBUpdates } from '../../services/database';
import { User, Shop, UserRole } from '../../types';
import { 
  Users, 
  UserPlus, 
  Shield, 
  Store, 
  Coffee, 
  CheckCircle2, 
  AlertCircle, 
  KeyRound, 
  Trash2, 
  Edit3, 
  X,
  Lock,
  Phone
} from 'lucide-react';

export const AccountManagementView: React.FC = () => {
  const { currentUser, currentShop, isMaster, isOwner, isStaff, allShops } = useAuth();
  const [users, setUsers] = useState<User[]>([]);
  const [shops, setShops] = useState<Shop[]>([]);
  const [loading, setLoading] = useState(true);

  // Modal create/edit user
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalType, setModalType] = useState<'create_owner' | 'create_staff'>('create_owner');
  const [roleFilter, setRoleFilter] = useState<'ALL' | 'OWNER' | 'MASTER'>('ALL');
  
  // Form fields
  const [formData, setFormData] = useState({
    name: '',
    username: '',
    password: '',
    phone: '',
    shopName: '',
    shopAddress: '',
  });

  const [formError, setFormError] = useState<string | null>(null);
  const [successToast, setSuccessToast] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const loadData = async () => {
    try {
      const [allUsers, allShopsList] = await Promise.all([
        db.getUsers(),
        db.getShops()
      ]);
      setUsers(allUsers);
      setShops(allShopsList);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
    const unsub = subscribeToDBUpdates(() => {
      loadData();
    });
    return () => unsub();
  }, [currentShop?.id]);

  const handleOpenCreateOwner = () => {
    setModalType('create_owner');
    setFormData({
      name: '',
      username: '',
      password: '',
      phone: '',
      shopName: '',
      shopAddress: '',
    });
    setFormError(null);
    setIsModalOpen(true);
  };

  const handleOpenCreateStaff = () => {
    setModalType('create_staff');
    setFormData({
      name: '',
      username: '',
      password: '',
      phone: '',
      shopName: currentShop?.name || '',
      shopAddress: '',
    });
    setFormError(null);
    setIsModalOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);

    if (!formData.username.trim() || !formData.password || !formData.name.trim()) {
      setFormError('Harap lengkapi semua kolom wajib.');
      return;
    }

    try {
      setIsSubmitting(true);

      if (modalType === 'create_owner') {
        // Master creating Owner & their Coffee Shop
        if (!formData.shopName.trim()) {
          setFormError('Nama Coffee Shop wajib diisi.');
          setIsSubmitting(false);
          return;
        }

        // 1. Create Owner User
        const newOwner = await db.createUser({
          username: formData.username.trim().toLowerCase(),
          name: formData.name.trim(),
          role: 'OWNER',
          password: formData.password,
          is_active: true,
          phone: formData.phone.trim() || undefined
        });

        // 2. Create Shop tied to this Owner
        const newShop = await db.createShop({
          name: formData.shopName.trim(),
          address: formData.shopAddress.trim() || undefined,
          phone: formData.phone.trim() || undefined,
          owner_id: newOwner.id,
          conversion_ratio: 3.0
        });

        // 3. Link owner to shop
        await db.updateUser(newOwner.id, { shop_id: newShop.id });

        setSuccessToast(`Owner "${newOwner.name}" dan Coffee Shop "${newShop.name}" berhasil dibuat & langsung aktif!`);
      } else {
        // Owner creating Staff Produksi
        if (!currentShop) {
          setFormError('Toko aktif tidak ditemukan.');
          setIsSubmitting(false);
          return;
        }

        const newStaff = await db.createUser({
          username: formData.username.trim().toLowerCase(),
          name: formData.name.trim(),
          role: 'STAFF',
          password: formData.password,
          shop_id: currentShop.id,
          is_active: true,
          phone: formData.phone.trim() || undefined
        });

        setSuccessToast(`Staff Produksi "${newStaff.name}" berhasil dibuat & langsung aktif!`);
      }

      setTimeout(() => setSuccessToast(null), 4000);
      setIsModalOpen(false);
      await loadData();
    } catch (err: any) {
      setFormError(err?.message || 'Gagal membuat akun.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleToggleActive = async (user: User) => {
    if (user.role === 'MASTER') return;
    try {
      await db.updateUser(user.id, { is_active: !user.is_active });
      await loadData();
    } catch (err: any) {
      alert(`Gagal mengubah status: ${err?.message}`);
    }
  };

  const handleDeleteUser = async (user: User) => {
    if (user.role === 'MASTER') {
      alert('Akun Master tidak dapat dihapus.');
      return;
    }
    if (!confirm(`Hapus akun "${user.name}" (@${user.username})?`)) return;

    try {
      await db.deleteUser(user.id);
      await loadData();
    } catch (err: any) {
      alert(`Gagal menghapus akun: ${err?.message}`);
    }
  };

  // Filter users based on role
  // Master sees all Owners & Masters
  // Owner only sees Staff from their shop!
  const displayedUsers = isMaster
    ? users.filter((u) => {
        if (roleFilter === 'OWNER') return u.role === 'OWNER';
        if (roleFilter === 'MASTER') return u.role === 'MASTER';
        return u.role === 'OWNER' || u.role === 'MASTER';
      })
    : isOwner
    ? users.filter((u) => u.role === 'STAFF' && u.shop_id === currentShop?.id)
    : [];

  if (isStaff) {
    return (
      <div className="bg-[#1A1410] border border-[#2D221A] rounded-2xl p-6 text-center max-w-lg mx-auto space-y-3 pb-20">
        <Lock className="w-12 h-12 text-[#C5A059] mx-auto" />
        <h3 className="text-base font-bold text-[#F4ECE6]">Profil Akun Staff Produksi</h3>
        <p className="text-xs text-[#9E8E81]">
          Anda masuk sebagai <strong>{currentUser?.name}</strong> (@{currentUser?.username}) di coffee shop <strong>{currentShop?.name}</strong>.
        </p>
        <p className="text-[11px] text-[#736356]">
          Role Staff Produksi tidak memiliki wewenang untuk menambah atau mengelola akun lain.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-4 pb-20">
      {/* Header Banner */}
      <div className="bg-[#0F172A]/80 backdrop-blur-xl border border-white/10 rounded-2xl p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-lg">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-emerald-400 mb-1">
            <Users className="w-4 h-4" />
            <span>Manajemen Akses & Akun</span>
          </div>
          <h2 className="text-lg sm:text-xl font-bold text-slate-100">
            {isMaster ? 'Kelola Akun Owner & Toko Kopi' : `Kelola Tim Staff: ${currentShop?.name}`}
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            {isMaster
              ? 'Master dapat mendaftarkan akun Owner baru beserta profil coffee shop-nya. Akun langsung aktif tanpa verifikasi email.'
              : 'Owner dapat mendaftarkan Staff Produksi (Barista) yang langsung aktif tanpa menunggu approval.'}
          </p>
        </div>

        {isMaster ? (
          <button
            onClick={handleOpenCreateOwner}
            className="min-h-[44px] flex items-center justify-center gap-2 px-4 py-2 bg-gradient-to-r from-emerald-500 to-teal-600 text-slate-950 font-bold text-xs sm:text-sm rounded-xl hover:brightness-110 active:scale-95 transition-all shadow-md shadow-emerald-500/20 shrink-0 cursor-pointer"
          >
            <UserPlus className="w-4 h-4" />
            <span>Daftarkan Owner Baru</span>
          </button>
        ) : (
          <button
            onClick={handleOpenCreateStaff}
            className="min-h-[44px] flex items-center justify-center gap-2 px-4 py-2 bg-gradient-to-r from-emerald-500 to-teal-600 text-slate-950 font-bold text-xs sm:text-sm rounded-xl hover:brightness-110 active:scale-95 transition-all shadow-md shadow-emerald-500/20 shrink-0 cursor-pointer"
          >
            <UserPlus className="w-4 h-4" />
            <span>Daftarkan Staff Baru</span>
          </button>
        )}
      </div>

      {/* Role Filter for Master */}
      {isMaster && (
        <div className="flex items-center gap-1.5 p-1 bg-[#090D16] border border-white/10 rounded-xl max-w-xs">
          <button
            onClick={() => setRoleFilter('ALL')}
            className={`flex-1 py-1.5 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
              roleFilter === 'ALL' ? 'bg-gradient-to-r from-emerald-500 to-teal-600 text-slate-950 font-bold shadow-sm' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Semua
          </button>
          <button
            onClick={() => setRoleFilter('OWNER')}
            className={`flex-1 py-1.5 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
              roleFilter === 'OWNER' ? 'bg-gradient-to-r from-emerald-500 to-teal-600 text-slate-950 font-bold shadow-sm' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Owner Toko
          </button>
          <button
            onClick={() => setRoleFilter('MASTER')}
            className={`flex-1 py-1.5 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
              roleFilter === 'MASTER' ? 'bg-gradient-to-r from-emerald-500 to-teal-600 text-slate-950 font-bold shadow-sm' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Master Admin
          </button>
        </div>
      )}

      {successToast && (
        <div className="p-3 bg-emerald-950/70 border border-emerald-800 text-emerald-300 rounded-xl text-xs flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{successToast}</span>
        </div>
      )}

      {/* Account List */}
      <div className="space-y-3">
        {displayedUsers.length === 0 ? (
          <div className="bg-[#0F172A]/80 backdrop-blur-xl border border-white/10 rounded-2xl p-8 text-center text-slate-400 shadow-lg">
            <Users className="w-10 h-10 mx-auto text-slate-600 mb-2" />
            <p className="text-sm">
              {isMaster
                ? 'Belum ada akun Owner terdaftar. Klik tombol di atas untuk mendaftarkan Owner pertama.'
                : 'Belum ada akun Staff Produksi terdaftar di toko ini.'}
            </p>
          </div>
        ) : (
          displayedUsers.map((user) => {
            const userShop = shops.find((s) => s.id === user.shop_id || s.owner_id === user.id);
            const staffCount = users.filter((u) => u.shop_id === userShop?.id && u.role === 'STAFF').length;

            return (
              <div
                key={user.id}
                className="p-4 rounded-2xl bg-[#0F172A]/80 backdrop-blur-xl border border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-md hover:border-emerald-500/30 transition-all"
              >
                <div className="overflow-hidden">
                  <div className="flex items-center gap-2 text-xs">
                    <span className="font-bold text-emerald-400">
                      {user.role === 'OWNER' ? 'Owner Toko' : user.role === 'MASTER' ? 'Master Admin' : 'Staff Produksi'}
                    </span>
                    <span aria-hidden="true" className="text-slate-600">·</span>
                    <span className="font-mono text-xs text-slate-400">
                      @{user.username}
                    </span>
                    <span aria-hidden="true" className="text-slate-600">·</span>
                    <span className={`text-xs font-medium flex items-center gap-1 ${
                      user.is_active ? 'text-emerald-400' : 'text-rose-400'
                    }`}>
                      <span className={`w-1.5 h-1.5 rounded-full ${user.is_active ? 'bg-emerald-400 shadow-[0_0_6px_#10B981]' : 'bg-rose-400'}`} />
                      <span>{user.is_active ? 'Aktif' : 'Nonaktif'}</span>
                    </span>
                  </div>

                  <h3 className="text-base font-bold text-slate-100 mt-1">
                    {user.name}
                  </h3>

                  <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-slate-400 mt-1">
                    {userShop && (
                      <span className="flex items-center gap-1 text-slate-200">
                        <Store className="w-3.5 h-3.5 text-emerald-400" />
                        <span>{userShop.name}</span>
                      </span>
                    )}
                    {user.phone && (
                      <>
                        <span aria-hidden="true" className="text-slate-600">·</span>
                        <span className="flex items-center gap-1">
                          <Phone className="w-3.5 h-3.5" />
                          <span>{user.phone}</span>
                        </span>
                      </>
                    )}
                    {user.role === 'OWNER' && (
                      <>
                        <span aria-hidden="true" className="text-slate-600">·</span>
                        <span>{staffCount} Staff Produksi</span>
                      </>
                    )}
                  </div>
                </div>

                {/* Actions */}
                <div className="flex items-center gap-2 pt-2 sm:pt-0 border-t sm:border-t-0 border-[#271E17]">
                  <button
                    onClick={() => handleToggleActive(user)}
                    className={`min-h-[36px] px-3 py-1.5 rounded-xl text-xs font-medium border transition-colors ${
                      user.is_active
                        ? 'bg-[#241A14] hover:bg-[#32231B] text-[#D8CCC1] border-[#3E2D21]'
                        : 'bg-emerald-950/50 hover:bg-emerald-900/50 text-emerald-400 border-emerald-800'
                    }`}
                  >
                    {user.is_active ? 'Nonaktifkan' : 'Aktifkan'}
                  </button>

                  <button
                    onClick={() => handleDeleteUser(user)}
                    className="min-h-[36px] min-w-[36px] flex items-center justify-center rounded-xl bg-red-950/40 hover:bg-red-900/60 text-red-400 border border-red-900/50 transition-colors"
                    title="Hapus Akun"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* MODAL: DAFTARKAN AKUN BARU */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#1A1410] border border-[#34261B] rounded-2xl w-full max-w-md p-5 sm:p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-[#2C2117]">
              <div>
                <h3 className="text-base font-bold text-[#F4ECE6]">
                  {modalType === 'create_owner'
                    ? 'Daftarkan Akun Owner Baru'
                    : 'Daftarkan Staff Produksi'}
                </h3>
                <p className="text-xs text-[#8E7E72] mt-0.5">
                  Akun langsung aktif tanpa verifikasi email & tanpa approval
                </p>
              </div>
              <button
                onClick={() => setIsModalOpen(false)}
                className="text-[#8E7E72] hover:text-[#E8DFD8] p-1.5 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-3.5">
              {formError && (
                <div className="p-3 text-xs bg-red-950/60 border border-red-800/60 text-red-300 rounded-xl">
                  {formError}
                </div>
              )}

              {modalType === 'create_owner' && (
                <>
                  <div>
                    <label className="block text-xs font-medium text-[#C8BCB3] mb-1">
                      Nama Coffee Shop *
                    </label>
                    <input
                      type="text"
                      value={formData.shopName}
                      onChange={(e) => setFormData({ ...formData, shopName: e.target.value })}
                      placeholder="Contoh: Kopi Nusantara Artisan"
                      className="w-full px-3 py-2 bg-[#120F0D] border border-[#35281E] rounded-xl text-sm text-[#E8DFD8] focus:outline-none focus:border-[#C5A059]"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-[#C8BCB3] mb-1">
                      Alamat Coffee Shop
                    </label>
                    <input
                      type="text"
                      value={formData.shopAddress}
                      onChange={(e) => setFormData({ ...formData, shopAddress: e.target.value })}
                      placeholder="Contoh: Jl. Gatot Subroto No. 8"
                      className="w-full px-3 py-2 bg-[#120F0D] border border-[#35281E] rounded-xl text-sm text-[#E8DFD8] focus:outline-none focus:border-[#C5A059]"
                    />
                  </div>
                </>
              )}

              <div>
                <label className="block text-xs font-medium text-[#C8BCB3] mb-1">
                  Nama Lengkap *
                </label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder={
                    modalType === 'create_owner'
                      ? 'Nama Pemilik Toko'
                      : 'Nama Barista / Staff'
                  }
                  className="w-full px-3 py-2 bg-[#120F0D] border border-[#35281E] rounded-xl text-sm text-[#E8DFD8] focus:outline-none focus:border-[#C5A059]"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-[#C8BCB3] mb-1">
                    Username Login *
                  </label>
                  <input
                    type="text"
                    value={formData.username}
                    onChange={(e) => setFormData({ ...formData, username: e.target.value })}
                    placeholder="username"
                    className="w-full px-3 py-2 bg-[#120F0D] border border-[#35281E] rounded-xl text-sm text-[#E8DFD8] focus:outline-none focus:border-[#C5A059]"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-[#C8BCB3] mb-1">
                    Password *
                  </label>
                  <input
                    type="password"
                    value={formData.password}
                    onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                    placeholder="Minimal 6 karakter"
                    className="w-full px-3 py-2 bg-[#120F0D] border border-[#35281E] rounded-xl text-sm text-[#E8DFD8] focus:outline-none focus:border-[#C5A059]"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-[#C8BCB3] mb-1">
                  No. Telepon / WhatsApp
                </label>
                <input
                  type="tel"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  placeholder="0812xxxxxxxx"
                  className="w-full px-3 py-2 bg-[#120F0D] border border-[#35281E] rounded-xl text-sm text-[#E8DFD8] focus:outline-none focus:border-[#C5A059]"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-[#2C2117]">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs font-medium text-[#A8988B] hover:bg-[#251D17]"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-5 py-2.5 rounded-xl bg-[#C5A059] text-[#120F0D] text-xs font-bold hover:brightness-110 active:scale-95 transition-all shadow-md"
                >
                  {isSubmitting ? 'Menyimpan...' : 'Daftarkan Akun'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
