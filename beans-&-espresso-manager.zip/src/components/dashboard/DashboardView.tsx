import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { db, subscribeToDBUpdates } from '../../services/database';
import { 
  InventoryItem, 
  StockTransaction, 
  ProductionLog, 
  EspressoUsageLog,
  WasteLog,
  Expense 
} from '../../types';
import { 
  Coffee, 
  AlertTriangle, 
  ReceiptText, 
  Clock, 
  Plus, 
  Layers, 
  Sparkles,
  ArrowUpRight,
  ArrowDownLeft,
  ChevronRight,
  Calculator,
  Flame,
  TrendingDown,
  Calendar,
  Zap,
  CreditCard,
  Wifi,
  ShieldCheck,
  Droplets,
  PackagePlus,
  Coins
} from 'lucide-react';

interface DashboardViewProps {
  onNavigate: (tab: any) => void;
  onQuickRestock: (item: InventoryItem) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({ onNavigate, onQuickRestock }) => {
  const { currentShop, currentUser, isOwner, isMaster } = useAuth();
  const [items, setItems] = useState<InventoryItem[]>([]);
  const [transactions, setTransactions] = useState<StockTransaction[]>([]);
  const [productions, setProductions] = useState<ProductionLog[]>([]);
  const [usages, setUsages] = useState<EspressoUsageLog[]>([]);
  const [wasteLogs, setWasteLogs] = useState<WasteLog[]>([]);
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [loading, setLoading] = useState(true);

  const loadData = async () => {
    if (!currentShop) return;
    try {
      const [itemList, txList, prodList, useList, wasteList, expList] = await Promise.all([
        db.getInventory(currentShop.id),
        db.getTransactions(currentShop.id, undefined, 10),
        db.getProductions(currentShop.id, 50),
        db.getEspressoUsages(currentShop.id, 50),
        db.getWasteLogs(currentShop.id, 50),
        db.getExpenses(currentShop.id, 100),
      ]);

      setItems(itemList);
      setTransactions(txList);
      setProductions(prodList);
      setUsages(useList);
      setWasteLogs(wasteList);
      setExpenses(expList);
    } catch (err) {
      console.error('Error loading dashboard data:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
    const unsubscribe = subscribeToDBUpdates(() => {
      loadData();
    });
    return () => unsubscribe();
  }, [currentShop?.id]);

  if (!currentShop) {
    return (
      <div className="p-8 text-center text-slate-400">
        <p>Silakan pilih atau daftarkan toko untuk melihat dashboard operasional.</p>
      </div>
    );
  }

  const conversionRatio = currentShop.conversion_ratio || 3.0;

  // 1. Stok Beans
  const beansItems = items.filter((i) => i.category === 'Coffee Beans');
  const totalBeansKg = beansItems.reduce((acc, curr) => {
    const qty = Number(curr.current_stock) || 0;
    return acc + (curr.unit === 'gr' ? qty / 1000 : qty);
  }, 0);

  // 2. Stok Espresso
  const espressoItems = items.filter((i) => i.category === 'Espresso Base');
  const totalEspressoLiter = espressoItems.reduce((acc, curr) => {
    const qty = Number(curr.current_stock) || 0;
    return acc + (curr.unit === 'ml' ? qty / 1000 : qty);
  }, 0);

  // 3. Estimasi Espresso yang dapat diproduksi (Stok Beans × Rasio)
  const estimatedEspressoOutputL = Math.round(totalBeansKg * conversionRatio * 100) / 100;

  // Today Date Strings
  const todayStr = new Date().toISOString().split('T')[0];
  const currentMonthStr = todayStr.substring(0, 7); // YYYY-MM

  // 4. Produksi Hari Ini
  const todayProductions = productions.filter((p) => p.created_at.startsWith(todayStr));
  const todayEspressoBrewed = todayProductions.reduce((sum, p) => sum + Number(p.espresso_produced_liter), 0);

  // 5. Pemakaian Hari Ini
  const todayUsages = usages.filter((u) => u.created_at.startsWith(todayStr));
  const todayEspressoUsed = todayUsages.reduce((sum, u) => sum + Number(u.amount_liter), 0);

  // 6. Waste Hari Ini
  const todayWasteFromProds = todayProductions.reduce((sum, p) => sum + Number(p.waste_liter || 0), 0);
  const todayWasteFromLogs = wasteLogs
    .filter((w) => w.created_at.startsWith(todayStr))
    .reduce((sum, w) => sum + (w.item_type === 'ESPRESSO' ? Number(w.quantity) : 0), 0);
  const totalWasteTodayL = Math.round((todayWasteFromProds + todayWasteFromLogs) * 100) / 100;

  // 7. Pengeluaran Hari Ini
  const todayExpenses = expenses
    .filter((e) => e.expense_date.startsWith(todayStr))
    .reduce((sum, e) => sum + Number(e.amount), 0);

  // 8. Pengeluaran Bulan Berjalan
  const currentMonthExpenses = expenses
    .filter((e) => e.expense_date.startsWith(currentMonthStr))
    .reduce((sum, e) => sum + Number(e.amount), 0);

  // 9. HPP Espresso (Rata-rata aktual produksi atau beans utama ÷ rasio)
  let avgHppPerLiter = 0;
  if (productions.length > 0) {
    const totalHppWeighted = productions.slice(0, 10).reduce((sum, p) => sum + (Number(p.hpp_per_liter || 0) * Number(p.espresso_produced_liter)), 0);
    const totalEspressoSlice = productions.slice(0, 10).reduce((sum, p) => sum + Number(p.espresso_produced_liter), 0);
    avgHppPerLiter = totalEspressoSlice > 0 ? Math.round(totalHppWeighted / totalEspressoSlice) : 60000;
  } else if (beansItems.length > 0) {
    avgHppPerLiter = Math.round((Number(beansItems[0].cost_price) || 180000) / conversionRatio);
  } else {
    avgHppPerLiter = 60000;
  }

  // Low stock warning items
  const lowStockItems = items.filter((i) => Number(i.current_stock) <= Number(i.min_stock));

  const formatRupiah = (val: number) => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      maximumFractionDigits: 0,
    }).format(val);
  };

  // Calculation for Espresso Liquidity ratio vs beans reserve capacity
  const totalCapacityPossible = totalEspressoLiter + estimatedEspressoOutputL;
  const currentLiquidityPercent = totalCapacityPossible > 0 ? Math.min(100, Math.round((totalEspressoLiter / totalCapacityPossible) * 100)) : 0;
  const estimatedCups = Math.round(totalEspressoLiter * 33.3);

  return (
    <div className="space-y-6 pb-24">
      {/* ======================================================== */}
      {/* 1. SOPHISTICATED BANK APP HERO: DIGITAL ASSET / DEBIT CARD */}
      {/* ======================================================== */}
      <div className="relative">
        <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-[#1E293B] via-[#0F172A] to-[#020617] border border-white/10 p-5 sm:p-7 shadow-2xl shadow-black/80">
          {/* Subtle background ambient holographic glow & light arcs */}
          <div className="pointer-events-none absolute -right-20 -top-20 w-80 h-80 rounded-full bg-emerald-500/15 blur-3xl" />
          <div className="pointer-events-none absolute -left-20 -bottom-20 w-80 h-80 rounded-full bg-blue-600/15 blur-3xl" />
          <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_top_right,rgba(255,255,255,0.06),transparent_60%)]" />

          {/* Card Top Row: Chip, Contactless, & Coffee Shop / Tier Badge */}
          <div className="flex items-center justify-between relative z-10 mb-6">
            <div className="flex items-center gap-3">
              {/* Metallic Smart Chip */}
              <div className="w-10 h-7 rounded-md bg-gradient-to-br from-amber-200 via-amber-400 to-amber-600 border border-amber-200/40 p-1 flex items-center justify-center shadow-inner relative overflow-hidden">
                <div className="w-full h-full border border-amber-800/40 rounded-sm grid grid-cols-2 gap-0.5 opacity-60">
                  <div className="border-r border-amber-800/40" />
                  <div />
                </div>
              </div>

              {/* Contactless Wave Icon */}
              <div className="text-slate-400 flex items-center" title="Contactless Sync">
                <Wifi className="w-4 h-4 rotate-90" />
              </div>

              <span className="text-[10px] sm:text-xs font-mono font-semibold tracking-widest text-slate-400 uppercase hidden xs:inline">
                BEM PLATINUM RESERVE
              </span>
            </div>

            {/* Shop Badge & Realtime Status */}
            <div className="flex items-center gap-2">
              <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-white/[0.06] border border-white/10 text-slate-200 truncate max-w-[140px] sm:max-w-[200px]">
                {currentShop.name}
              </span>
              <div className="w-2 h-2 rounded-full bg-emerald-400 shadow-[0_0_8px_#10B981]" title="Realtime Online" />
            </div>
          </div>

          {/* Card Middle Balance: Main Espresso Liquidity & Valuation */}
          <div className="relative z-10 mb-6 sm:mb-8">
            <div className="text-[11px] font-semibold tracking-wider text-slate-400 uppercase mb-1 flex items-center gap-1.5">
              <span>Total Cadangan Espresso (Ready at Bar)</span>
              <span aria-hidden="true" className="text-slate-600">·</span>
              <span className="text-emerald-400 font-mono">Realtime Live</span>
            </div>

            <div className="flex flex-wrap items-baseline gap-3">
              <span className="text-3xl sm:text-4xl lg:text-5xl font-bold font-mono tracking-tight text-white drop-shadow-sm">
                {totalEspressoLiter.toFixed(2)}{' '}
                <span className="text-xl sm:text-2xl font-light text-emerald-400">Liter</span>
              </span>
              <span className="text-xs sm:text-sm font-medium text-slate-300 px-2.5 py-1 rounded-xl bg-white/[0.05] border border-white/10">
                ≈ {estimatedCups} Double Shots
              </span>
            </div>

            <div className="mt-2 text-xs sm:text-sm text-slate-300 flex items-center gap-2">
              <span className="text-slate-400">Valuasi HPP:</span>
              <strong className="text-emerald-400 font-mono font-semibold">
                {formatRupiah(totalEspressoLiter * avgHppPerLiter)}
              </strong>
              <span className="text-slate-500">·</span>
              <span className="text-slate-400 font-mono text-[11px]">
                @{formatRupiah(avgHppPerLiter)}/L
              </span>
            </div>
          </div>

          {/* Card Bottom Row: Cardholder, Number & Yield Ratio */}
          <div className="relative z-10 pt-4 border-t border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-4">
              <div>
                <div className="text-[10px] text-slate-400 uppercase tracking-wider">Cardholder / PIC</div>
                <div className="font-semibold text-slate-100 font-mono uppercase tracking-wide truncate max-w-[150px]">
                  {currentUser?.name || 'MASTER ADMIN'}
                </div>
              </div>

              <div>
                <div className="text-[10px] text-slate-400 uppercase tracking-wider">Nomor Cadangan</div>
                <div className="font-mono text-slate-300 font-medium tracking-wider">
                  •••• •••• •••• {Math.round(conversionRatio * 1000)}
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2 sm:text-right">
              <div className="px-2.5 py-1 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-[11px] font-mono font-semibold">
                RATIO 1 KG = {conversionRatio} L
              </div>
              <div className="px-2.5 py-1 rounded-lg bg-amber-500/10 border border-amber-500/20 text-amber-300 text-[11px] font-mono font-medium">
                BIJI: {totalBeansKg.toFixed(2)} KG
              </div>
            </div>
          </div>
        </div>

        {/* ======================================================== */}
        {/* 2. FINTECH QUICK ACTION ROW (CIRCULAR / SQUIRCLE DOCK) */}
        {/* ======================================================== */}
        <div className="grid grid-cols-4 gap-2 sm:gap-4 mt-4 px-1">
          {/* Action 1: Produksi / Brew */}
          <button
            onClick={() => onNavigate('production')}
            className="flex flex-col items-center justify-center group active:scale-95 transition-all p-2 rounded-2xl bg-[#0F172A]/70 hover:bg-[#1E293B]/80 border border-white/10 shadow-lg"
          >
            <div className="w-11 h-11 sm:w-12 sm:h-12 rounded-2xl bg-gradient-to-br from-emerald-500 to-teal-700 flex items-center justify-center text-white shadow-md shadow-emerald-500/20 group-hover:scale-105 transition-transform mb-1.5">
              <Zap className="w-5 h-5" />
            </div>
            <span className="text-[11px] sm:text-xs font-semibold text-slate-200">Produksi</span>
            <span className="text-[9px] text-slate-400 hidden xs:inline">Ekstraksi Batch</span>
          </button>

          {/* Action 2: Catat Pakai / Serving */}
          <button
            onClick={() => onNavigate('production')}
            className="flex flex-col items-center justify-center group active:scale-95 transition-all p-2 rounded-2xl bg-[#0F172A]/70 hover:bg-[#1E293B]/80 border border-white/10 shadow-lg"
          >
            <div className="w-11 h-11 sm:w-12 sm:h-12 rounded-2xl bg-gradient-to-br from-cyan-500 to-blue-700 flex items-center justify-center text-white shadow-md shadow-cyan-500/20 group-hover:scale-105 transition-transform mb-1.5">
              <Droplets className="w-5 h-5" />
            </div>
            <span className="text-[11px] sm:text-xs font-semibold text-slate-200">Pakai Bar</span>
            <span className="text-[9px] text-slate-400 hidden xs:inline">Tuang Espresso</span>
          </button>

          {/* Action 3: Catat Beban / Expenses */}
          <button
            onClick={() => onNavigate('expenses')}
            className="flex flex-col items-center justify-center group active:scale-95 transition-all p-2 rounded-2xl bg-[#0F172A]/70 hover:bg-[#1E293B]/80 border border-white/10 shadow-lg"
          >
            <div className="w-11 h-11 sm:w-12 sm:h-12 rounded-2xl bg-gradient-to-br from-rose-500 to-red-700 flex items-center justify-center text-white shadow-md shadow-rose-500/20 group-hover:scale-105 transition-transform mb-1.5">
              <Coins className="w-5 h-5" />
            </div>
            <span className="text-[11px] sm:text-xs font-semibold text-slate-200">Beban</span>
            <span className="text-[9px] text-slate-400 hidden xs:inline">Catat Biaya</span>
          </button>

          {/* Action 4: Restock Beans / Inventory */}
          <button
            onClick={() => onNavigate('inventory')}
            className="flex flex-col items-center justify-center group active:scale-95 transition-all p-2 rounded-2xl bg-[#0F172A]/70 hover:bg-[#1E293B]/80 border border-white/10 shadow-lg"
          >
            <div className="w-11 h-11 sm:w-12 sm:h-12 rounded-2xl bg-gradient-to-br from-amber-500 to-orange-700 flex items-center justify-center text-white shadow-md shadow-amber-500/20 group-hover:scale-105 transition-transform mb-1.5">
              <PackagePlus className="w-5 h-5" />
            </div>
            <span className="text-[11px] sm:text-xs font-semibold text-slate-200">Restock</span>
            <span className="text-[9px] text-slate-400 hidden xs:inline">Biji & Stok</span>
          </button>
        </div>
      </div>

      {/* ======================================================== */}
      {/* 3. OPERATIONAL TELEMETRY & LIQUIDITY BAR */}
      {/* ======================================================== */}
      <div className="bg-[#0F172A]/80 backdrop-blur-xl border border-white/10 rounded-2xl p-4 sm:p-5 shadow-lg">
        <div className="flex items-center justify-between mb-2.5">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-emerald-400" />
            <span className="text-xs sm:text-sm font-bold text-slate-200">
              Kapasitas & Likuiditas Produksi
            </span>
          </div>
          <span className="text-xs font-mono font-semibold text-emerald-400">
            {currentLiquidityPercent}% Sudah Diekstraksi
          </span>
        </div>

        {/* Multi-segment high-tech progress bar */}
        <div className="w-full h-3 rounded-full bg-slate-800/80 overflow-hidden flex p-0.5 border border-white/5">
          <div
            style={{ width: `${currentLiquidityPercent}%` }}
            className="h-full bg-gradient-to-r from-emerald-500 to-teal-400 rounded-full transition-all duration-500"
            title="Espresso Cair Siap Pakai"
          />
          <div
            style={{ width: `${100 - currentLiquidityPercent}%` }}
            className="h-full bg-gradient-to-r from-amber-500/50 to-amber-600/50 rounded-r-full transition-all duration-500"
            title="Potensi dari Stok Beans"
          />
        </div>

        <div className="flex items-center justify-between text-[11px] text-slate-400 mt-2">
          <div className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-400" />
            <span>Espresso Cair: <strong>{totalEspressoLiter.toFixed(2)} L</strong></span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-amber-400" />
            <span>Potensi Beans: <strong>+{estimatedEspressoOutputL.toFixed(1)} L</strong></span>
          </div>
        </div>
      </div>

      {/* ======================================================== */}
      {/* 4. DASHBOARD OWNER 9 CORE METRICS (FINTECH BENTO GRID) */}
      {/* ======================================================== */}
      <div>
        <div className="flex items-center justify-between mb-3 px-1">
          <h3 className="text-xs sm:text-sm font-bold uppercase tracking-wider text-slate-300 flex items-center gap-2">
            <CreditCard className="w-4 h-4 text-emerald-400" />
            <span>9 Ringkasan Metrik Bisnis & Finansial</span>
          </h3>
          <span className="text-[11px] text-slate-400 font-mono">
            Synced Supabase
          </span>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-3 gap-3 sm:gap-4">
          {/* 1. Stok Beans */}
          <div className="bg-[#0F172A]/70 backdrop-blur-md border border-white/10 hover:border-emerald-500/30 transition-all rounded-2xl p-4 flex flex-col justify-between shadow-lg">
            <div className="flex items-center justify-between text-slate-400 mb-1.5">
              <span className="text-xs font-semibold uppercase">1. Stok Beans</span>
              <Coffee className="w-4 h-4 text-amber-400" />
            </div>
            <div>
              <div className="text-2xl sm:text-3xl font-bold font-mono text-white">
                {totalBeansKg.toFixed(2)}{' '}
                <span className="text-xs font-normal text-slate-400">kg</span>
              </div>
              <div className="text-[11px] text-slate-400 mt-0.5">
                {beansItems.length} varian biji kopi
              </div>
            </div>
          </div>

          {/* 2. Stok Espresso */}
          <div className="bg-[#0F172A]/70 backdrop-blur-md border border-white/10 hover:border-emerald-500/30 transition-all rounded-2xl p-4 flex flex-col justify-between shadow-lg">
            <div className="flex items-center justify-between text-slate-400 mb-1.5">
              <span className="text-xs font-semibold uppercase">2. Stok Espresso</span>
              <Layers className="w-4 h-4 text-emerald-400" />
            </div>
            <div>
              <div className="text-2xl sm:text-3xl font-bold font-mono text-emerald-400">
                {totalEspressoLiter.toFixed(2)}{' '}
                <span className="text-xs font-normal text-slate-400">Liter</span>
              </div>
              <div className="text-[11px] text-slate-400 mt-0.5">
                Espresso siap saji di bar
              </div>
            </div>
          </div>

          {/* 3. Estimasi Espresso yang Dapat Diproduksi */}
          <div className="bg-[#0F172A]/70 backdrop-blur-md border border-white/10 hover:border-emerald-500/30 transition-all rounded-2xl p-4 flex flex-col justify-between shadow-lg">
            <div className="flex items-center justify-between text-slate-400 mb-1.5">
              <span className="text-xs font-semibold uppercase">3. Estimasi Output</span>
              <Calculator className="w-4 h-4 text-cyan-400" />
            </div>
            <div>
              <div className="text-2xl sm:text-3xl font-bold font-mono text-cyan-400">
                {estimatedEspressoOutputL.toFixed(1)}{' '}
                <span className="text-xs font-normal text-slate-400">Liter</span>
              </div>
              <div className="text-[11px] text-slate-400 mt-0.5">
                Stok Beans × Rasio {conversionRatio}x
              </div>
            </div>
          </div>

          {/* 4. Produksi Hari Ini */}
          <div className="bg-[#0F172A]/70 backdrop-blur-md border border-white/10 hover:border-emerald-500/30 transition-all rounded-2xl p-4 flex flex-col justify-between shadow-lg">
            <div className="flex items-center justify-between text-slate-400 mb-1.5">
              <span className="text-xs font-semibold uppercase">4. Produksi Hari Ini</span>
              <Zap className="w-4 h-4 text-emerald-400" />
            </div>
            <div>
              <div className="text-2xl sm:text-3xl font-bold font-mono text-white">
                {todayEspressoBrewed.toFixed(2)}{' '}
                <span className="text-xs font-normal text-slate-400">Liter</span>
              </div>
              <div className="text-[11px] text-slate-400 mt-0.5">
                {todayProductions.length} batch diekstraksi
              </div>
            </div>
          </div>

          {/* 5. Pemakaian Hari Ini */}
          <div className="bg-[#0F172A]/70 backdrop-blur-md border border-white/10 hover:border-emerald-500/30 transition-all rounded-2xl p-4 flex flex-col justify-between shadow-lg">
            <div className="flex items-center justify-between text-slate-400 mb-1.5">
              <span className="text-xs font-semibold uppercase">5. Pemakaian Hari Ini</span>
              <TrendingDown className="w-4 h-4 text-blue-400" />
            </div>
            <div>
              <div className="text-2xl sm:text-3xl font-bold font-mono text-blue-400">
                {todayEspressoUsed.toFixed(2)}{' '}
                <span className="text-xs font-normal text-slate-400">Liter</span>
              </div>
              <div className="text-[11px] text-slate-400 mt-0.5">
                {todayUsages.length} kali pemakaian bar
              </div>
            </div>
          </div>

          {/* 6. Waste Hari Ini */}
          <div className="bg-[#0F172A]/70 backdrop-blur-md border border-white/10 hover:border-emerald-500/30 transition-all rounded-2xl p-4 flex flex-col justify-between shadow-lg">
            <div className="flex items-center justify-between text-slate-400 mb-1.5">
              <span className="text-xs font-semibold uppercase">6. Waste Hari Ini</span>
              <Flame className="w-4 h-4 text-rose-400" />
            </div>
            <div>
              <div className="text-2xl sm:text-3xl font-bold font-mono text-rose-400">
                {totalWasteTodayL.toFixed(2)}{' '}
                <span className="text-xs font-normal text-slate-400">Liter</span>
              </div>
              <div className="text-[11px] text-slate-400 mt-0.5">
                Susut dial-in & ampas
              </div>
            </div>
          </div>

          {/* 7. Pengeluaran Hari Ini */}
          <div className="bg-[#0F172A]/70 backdrop-blur-md border border-white/10 hover:border-emerald-500/30 transition-all rounded-2xl p-4 flex flex-col justify-between shadow-lg">
            <div className="flex items-center justify-between text-slate-400 mb-1.5">
              <span className="text-xs font-semibold uppercase">7. Beban Hari Ini</span>
              <ReceiptText className="w-4 h-4 text-rose-400" />
            </div>
            <div>
              <div className="text-xl sm:text-2xl font-bold font-mono text-white truncate">
                {formatRupiah(todayExpenses)}
              </div>
              <div className="text-[11px] text-slate-400 mt-0.5">
                Tercatat tanpa approval
              </div>
            </div>
          </div>

          {/* 8. Pengeluaran Bulan Berjalan */}
          <div className="bg-[#0F172A]/70 backdrop-blur-md border border-white/10 hover:border-emerald-500/30 transition-all rounded-2xl p-4 flex flex-col justify-between shadow-lg">
            <div className="flex items-center justify-between text-slate-400 mb-1.5">
              <span className="text-xs font-semibold uppercase">8. Beban Bulan Ini</span>
              <Calendar className="w-4 h-4 text-amber-400" />
            </div>
            <div>
              <div className="text-xl sm:text-2xl font-bold font-mono text-rose-400 truncate">
                {formatRupiah(currentMonthExpenses)}
              </div>
              <div className="text-[11px] text-slate-400 mt-0.5">
                Total bulan {new Date().toLocaleDateString('id-ID', { month: 'long', year: 'numeric' })}
              </div>
            </div>
          </div>

          {/* 9. HPP Espresso */}
          <div className="bg-[#0F172A]/70 backdrop-blur-md border border-white/10 hover:border-emerald-500/30 transition-all rounded-2xl p-4 flex flex-col justify-between shadow-lg">
            <div className="flex items-center justify-between text-slate-400 mb-1.5">
              <span className="text-xs font-semibold uppercase">9. HPP Espresso</span>
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
            </div>
            <div>
              <div className="text-xl sm:text-2xl font-bold font-mono text-emerald-400 truncate">
                {formatRupiah(avgHppPerLiter)}
                <span className="text-xs font-normal text-slate-400">/L</span>
              </div>
              <div className="text-[11px] text-slate-400 mt-0.5">
                Otomatis: Harga Beans ÷ Rasio
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* ======================================================== */}
      {/* 5. LOW STOCK SECURITY / INVENTORY ALERT */}
      {/* ======================================================== */}
      {lowStockItems.length > 0 && (
        <div className="bg-amber-950/20 border border-amber-500/30 rounded-2xl p-4 shadow-lg backdrop-blur-md">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
              <h3 className="text-xs sm:text-sm font-semibold text-amber-200">
                Peringatan Stok Menipis ({lowStockItems.length} Item)
              </h3>
            </div>
            <button
              onClick={() => onNavigate('inventory')}
              className="text-xs text-amber-400 hover:underline font-medium"
            >
              Lihat Inventaris
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">
            {lowStockItems.slice(0, 3).map((item) => (
              <div
                key={item.id}
                className="flex items-center justify-between bg-[#0F172A]/90 border border-white/10 rounded-xl p-3 shadow-sm"
              >
                <div className="overflow-hidden pr-2">
                  <div className="text-xs font-semibold text-slate-200 truncate">{item.name}</div>
                  <div className="text-[11px] text-slate-400 flex items-center gap-1.5 mt-0.5">
                    <span>Sisa: <strong className="text-amber-400 font-mono">{item.current_stock} {item.unit}</strong></span>
                    <span>·</span>
                    <span>Min: {item.min_stock} {item.unit}</span>
                  </div>
                </div>

                <button
                  onClick={() => onQuickRestock(item)}
                  className="min-h-[36px] px-3 py-1 text-xs font-semibold bg-amber-500/15 hover:bg-amber-500/25 text-amber-300 border border-amber-500/30 rounded-lg transition-colors whitespace-nowrap shrink-0"
                >
                  + Tambah
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* 6. BANKING-STYLE REALTIME ACTIVITY / TRANSACTION LEDGER */}
      {/* ======================================================== */}
      <div className="bg-[#0F172A]/80 backdrop-blur-xl border border-white/10 rounded-2xl p-4 sm:p-5 shadow-lg">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-emerald-400" />
            <h3 className="text-xs sm:text-sm font-bold text-slate-200">
              Aktivitas Stok & Transaksi Realtime
            </h3>
          </div>
          <button
            onClick={() => onNavigate('reports')}
            className="text-xs text-emerald-400 hover:text-emerald-300 hover:underline font-medium flex items-center gap-1"
          >
            <span>Buka Laporan Owner</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {transactions.length === 0 ? (
          <div className="py-8 text-center text-xs text-slate-400">
            Belum ada mutasi stok tercatat.
          </div>
        ) : (
          <div className="space-y-2">
            {transactions.slice(0, 6).map((tx) => {
              const isIncoming = tx.type === 'IN' || tx.type === 'PRODUCTION_IN';
              return (
                <div
                  key={tx.id}
                  className="p-3 rounded-xl bg-white/[0.03] hover:bg-white/[0.06] border border-white/5 flex items-center justify-between transition-colors"
                >
                  <div className="flex items-center gap-3 overflow-hidden">
                    <div
                      className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 shadow-inner ${
                        isIncoming
                          ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
                          : 'bg-rose-500/15 text-rose-400 border border-rose-500/30'
                      }`}
                    >
                      {isIncoming ? (
                        <ArrowDownLeft className="w-4 h-4" />
                      ) : (
                        <ArrowUpRight className="w-4 h-4" />
                      )}
                    </div>
                    <div className="truncate">
                      <div className="text-xs font-semibold text-slate-200 truncate">
                        {tx.item_name}
                      </div>
                      <div className="text-[10px] text-slate-400 truncate">
                        {tx.notes || tx.type} · oleh {tx.created_by}
                      </div>
                    </div>
                  </div>

                  <div className="text-right shrink-0 ml-2">
                    <div
                      className={`text-xs font-mono font-bold ${
                        isIncoming ? 'text-emerald-400' : 'text-slate-300'
                      }`}
                    >
                      {isIncoming ? '+' : '-'}{tx.quantity}
                    </div>
                    <div className="text-[10px] text-slate-400 font-mono">
                      {new Date(tx.created_at).toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
