import React, { useState, useEffect } from 'react';
import { Logo } from './Logo';
import { useAuth } from '../../context/AuthContext';
import { getStoredSupabaseConfig, getSupabaseClient } from '../../services/supabaseClient';
import { LogOut, Store, Shield, User as UserIcon, Wifi, ChevronDown } from 'lucide-react';

interface HeaderProps {
  onOpenSettings: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onOpenSettings }) => {
  const { currentUser, currentShop, allShops, isMaster, switchActiveShop, logout } = useAuth();
  const [supabaseStatus, setSupabaseStatus] = useState<'realtime' | 'local'>('local');

  useEffect(() => {
    const config = getStoredSupabaseConfig();
    const client = getSupabaseClient();
    if (config.isConfigured && client) {
      setSupabaseStatus('realtime');
    } else {
      setSupabaseStatus('local');
    }
  }, []);

  const getRoleLabel = (role?: string) => {
    switch (role) {
      case 'MASTER':
        return 'Master Admin';
      case 'OWNER':
        return 'Owner Toko';
      case 'STAFF':
        return 'Staff Produksi';
      default:
        return '';
    }
  };

  return (
    <header className="sticky top-0 z-30 bg-[#0B0F17]/85 backdrop-blur-xl border-b border-white/[0.08] px-3 sm:px-6 py-2.5 transition-all">
      <div className="max-w-6xl mx-auto flex items-center justify-between gap-2">
        {/* Zone 1: Brand Wordmark */}
        <div className="flex items-center gap-2 sm:gap-3 shrink-0">
          <Logo size="sm" showText={true} />
        </div>

        {/* Zone 2: Shop & User Context / Master Shop Switcher */}
        <div className="flex items-center gap-2 sm:gap-3 overflow-hidden">
          {isMaster ? (
            <div className="flex items-center gap-1.5 bg-[#111726]/90 border border-white/10 rounded-xl px-2.5 sm:px-3 py-1 shadow-sm">
              <Store className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
              <select
                value={currentShop?.id || ''}
                onChange={(e) => switchActiveShop(e.target.value)}
                className="bg-transparent text-xs sm:text-sm font-medium text-slate-200 focus:outline-none cursor-pointer max-w-[130px] sm:max-w-[180px] truncate"
                title="Pilih Toko untuk Diinspeksi"
              >
                {allShops.map((shop) => (
                  <option key={shop.id} value={shop.id} className="bg-[#0F172A] text-slate-200">
                    {shop.name}
                  </option>
                ))}
              </select>
            </div>
          ) : (
            currentShop && (
              <div className="hidden xs:flex items-center gap-1.5 text-xs text-slate-300 truncate max-w-[150px] sm:max-w-[200px] bg-[#111726]/60 border border-white/10 rounded-xl px-2.5 py-1">
                <Store className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <span className="truncate font-medium text-slate-200">{currentShop.name}</span>
              </div>
            )
          )}

          {/* Realtime / Supabase setup badge */}
          <button
            onClick={onOpenSettings}
            title={supabaseStatus === 'realtime' ? 'Supabase Realtime Terkoneksi (Klik untuk Pengaturan)' : 'Klik untuk Mengatur Supabase URL & Anon Key'}
            className="flex items-center gap-1.5 px-2.5 py-1 rounded-xl text-[11px] font-medium transition-all bg-[#111726]/90 hover:bg-[#1A2234] border border-white/10 active:scale-95 shadow-sm"
          >
            <span
              className={`w-2 h-2 rounded-full shrink-0 ${
                supabaseStatus === 'realtime' ? 'bg-emerald-400 shadow-[0_0_8px_#10B981]' : 'bg-amber-400'
              }`}
            />
            <span className="text-emerald-400 font-semibold tracking-wide">
              {supabaseStatus === 'realtime' ? 'Realtime Synced' : 'Setup DB'}
            </span>
          </button>
        </div>

        {/* Zone 3: User Profile & Actions */}
        <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
          {currentUser && (
            <div className="flex items-center gap-2">
              <div className="text-right hidden sm:block">
                <div className="text-xs font-semibold text-slate-200 truncate max-w-[120px]">
                  {currentUser.name}
                </div>
                <div className="text-[10px] text-emerald-400 font-medium tracking-wide">
                  {getRoleLabel(currentUser.role)}
                </div>
              </div>

              <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-[#1E293B] to-[#0F172A] border border-white/10 flex items-center justify-center text-emerald-400 font-bold text-xs shadow-inner">
                {currentUser.role === 'MASTER' ? (
                  <Shield className="w-4 h-4 text-amber-400" />
                ) : (
                  <UserIcon className="w-4 h-4 text-emerald-400" />
                )}
              </div>

              <button
                onClick={logout}
                title="Keluar / Ganti Akun"
                className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl text-slate-400 hover:text-slate-100 hover:bg-white/[0.06] transition-colors"
                aria-label="Logout"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
