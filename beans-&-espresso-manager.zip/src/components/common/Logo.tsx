import React from 'react';

interface LogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showText?: boolean;
}

export const Logo: React.FC<LogoProps> = ({ 
  className = '', 
  size = 'md',
  showText = true 
}) => {
  const iconSizes = {
    sm: 'w-7 h-7',
    md: 'w-10 h-10',
    lg: 'w-14 h-14',
    xl: 'w-20 h-20'
  };

  const textSizes = {
    sm: 'text-sm',
    md: 'text-base',
    lg: 'text-xl',
    xl: 'text-2xl'
  };

  return (
    <div className={`flex items-center gap-3 ${className}`}>
      {/* Golden Coffee Bean & Espresso Machine Vector Emblem */}
      <div className={`relative ${iconSizes[size]} shrink-0 flex items-center justify-center rounded-xl bg-gradient-to-br from-[#261E19] to-[#171310] border border-[#C5A059]/30 shadow-md shadow-black/40 p-1.5`}>
        <svg 
          viewBox="0 0 100 100" 
          fill="none" 
          xmlns="http://www.w3.org/2000/svg"
          className="w-full h-full text-[#C5A059]"
        >
          {/* Coffee Bean Contour (Left side) */}
          <path
            d="M48 20C32 20 20 33 20 50C20 67 32 80 48 80C50 80 52 79.5 54 79V21C52 20.5 50 20 48 20Z"
            stroke="currentColor"
            strokeWidth="4"
            strokeLinecap="round"
          />
          {/* Coffee Bean Inner S-Curve */}
          <path
            d="M36 28C42 36 32 46 38 56C42 62 36 70 34 72"
            stroke="currentColor"
            strokeWidth="3.5"
            strokeLinecap="round"
          />

          {/* Espresso Machine Silhouette (Right side) */}
          <path
            d="M54 26H78C80 26 82 28 82 30V40C82 42 80 44 78 44H68V72H82C84 72 84 74 84 76V78C84 80 82 80 80 80H54V26Z"
            stroke="currentColor"
            strokeWidth="4"
            strokeLinejoin="round"
          />

          {/* Grouphead / Portafilter Handle */}
          <path
            d="M68 44V52H62C60 52 59 53 59 55C59 57 60 58 62 58H86C88 58 90 56 90 54C90 52 88 50 86 50H74V44"
            stroke="currentColor"
            strokeWidth="3.5"
            strokeLinecap="round"
            strokeLinejoin="round"
          />

          {/* Coffee Drip */}
          <path
            d="M66 61C66 61 63 65 63 67C63 69 64.5 70 66 70C67.5 70 69 69 69 67C69 65 66 61 66 61Z"
            fill="currentColor"
          />
        </svg>
      </div>

      {showText && (
        <div className="flex flex-col">
          <div className="flex items-center gap-1.5">
            <span className={`font-brand font-bold tracking-wider text-[#C5A059] ${textSizes[size]}`}>
              BEM
            </span>
          </div>
          <span className="text-[10px] sm:text-[11px] font-medium tracking-widest text-[#B5A599] uppercase">
            Beans & Espresso Manager
          </span>
        </div>
      )}
    </div>
  );
};
