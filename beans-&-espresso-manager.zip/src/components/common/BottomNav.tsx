import React from 'react';
import { 
  LayoutDashboard, 
  Boxes, 
  Coffee, 
  ReceiptText, 
  BarChart3, 
  Users, 
  Settings 
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

export type NavTab = 'dashboard' | 'inventory' | 'production' | 'expenses' | 'reports' | 'accounts' | 'settings';

interface BottomNavProps {
  activeTab: NavTab;
  onChangeTab: (tab: NavTab) => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({ activeTab, onChangeTab }) => {
  const { isMaster, isOwner } = useAuth();

  const navItems = [
    {
      id: 'dashboard' as NavTab,
      label: 'Dashboard',
      icon: LayoutDashboard,
    },
    {
      id: 'inventory' as NavTab,
      label: 'Stok',
      icon: Boxes,
    },
    {
      id: 'production' as NavTab,
      label: 'Produksi',
      icon: Coffee,
    },
    {
      id: 'expenses' as NavTab,
      label: 'Beban',
      icon: ReceiptText,
    },
    {
      id: 'reports' as NavTab,
      label: 'Laporan',
      icon: BarChart3,
    },
    // Show Accounts tab if Master or Owner
    ...(isMaster || isOwner
      ? [
          {
            id: 'accounts' as NavTab,
            label: isMaster ? 'Kelola Owner' : 'Kelola Staff',
            icon: Users,
          },
        ]
      : []),
    {
      id: 'settings' as NavTab,
      label: 'Setting',
      icon: Settings,
    },
  ];

  return (
    <nav className="fixed bottom-2.5 left-2.5 right-2.5 sm:max-w-lg sm:mx-auto z-40 bg-[#0F172A]/90 backdrop-blur-2xl border border-white/10 rounded-2xl shadow-2xl shadow-black/90 p-1 transition-all">
      <div className="grid grid-flow-col auto-cols-fr items-center h-14">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;

          return (
            <button
              key={item.id}
              onClick={() => onChangeTab(item.id)}
              className="min-h-[44px] flex flex-col items-center justify-center py-1 transition-all active:scale-95 group focus:outline-none"
              aria-label={item.label}
            >
              <div
                className={`relative px-2.5 py-1 rounded-xl transition-all ${
                  isActive
                    ? 'text-emerald-400 bg-emerald-500/15 border border-emerald-500/30 shadow-[0_0_12px_rgba(16,185,129,0.2)]'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-white/[0.04]'
                }`}
              >
                <Icon className="w-4 h-4 sm:w-5 sm:h-5 stroke-[2.2]" />
                {isActive && (
                  <span className="absolute -top-0.5 -right-0.5 w-1.5 h-1.5 rounded-full bg-emerald-400 shadow-[0_0_6px_#10B981]" />
                )}
              </div>
              <span
                className={`text-[9px] sm:text-[10px] font-medium tracking-tight mt-0.5 truncate max-w-[56px] transition-colors ${
                  isActive ? 'text-emerald-400 font-semibold' : 'text-slate-400'
                }`}
              >
                {item.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
