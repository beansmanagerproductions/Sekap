import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { db, subscribeToDBUpdates } from '../../services/database';
import { 
  InventoryItem, 
  InventoryCategory, 
  StockUnit, 
  StockTransaction,
  TransactionType 
} from '../../types';
import { 
  Plus, 
  Search, 
  Filter, 
  AlertTriangle, 
  ArrowDownLeft, 
  ArrowUpRight, 
  SlidersHorizontal, 
  History, 
  Edit3, 
  Trash2, 
  X,
  Package,
  Layers,
  CheckCircle2,
  Clock
} from 'lucide-react';

const CATEGORIES: InventoryCategory[] = [
  'Coffee Beans',
  'Espresso Base',
  'Dairy & Susu',
  'Sirup & Perasa',
  'Packaging',
  'Bahan Baku Lain',
  'Alat & Kebersihan'
];

const UNITS: StockUnit[] = ['kg', 'gr', 'Liter', 'ml', 'pcs', 'pack', 'botol', 'can'];

interface InventoryViewProps {
  initialRestockItem?: InventoryItem | null;
  onClearInitialRestock?: () => void;
}

export const InventoryView: React.FC<InventoryViewProps> = ({ 
  initialRestockItem, 
  onClearInitialRestock 
}) => {
  const { currentShop, currentUser, isStaff, isOwner, isMaster } = useAuth();
  const [items, setItems] = useState<InventoryItem[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [loading, setLoading] = useState(true);

  // Modals state
  const [isItemModalOpen, setIsItemModalOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<InventoryItem | null>(null);

  const [isMovementModalOpen, setIsMovementModalOpen] = useState(false);
  const [movementTargetItem, setMovementTargetItem] = useState<InventoryItem | null>(null);
  const [movementType, setMovementType] = useState<TransactionType>('IN');
  const [movementQty, setMovementQty] = useState('');
  const [movementNotes, setMovementNotes] = useState('');
  const [movementError, setMovementError] = useState<string | null>(null);
  const [isSubmittingMovement, setIsSubmittingMovement] = useState(false);

  // History Drawer state
  const [historyItem, setHistoryItem] = useState<InventoryItem | null>(null);
  const [itemHistory, setItemHistory] = useState<StockTransaction[]>([]);
  const [loadingHistory, setLoadingHistory] = useState(false);

  // New/Edit Item Form State
  const [formData, setFormData] = useState({
    name: '',
    category: 'Coffee Beans' as InventoryCategory,
    unit: 'kg' as StockUnit,
    current_stock: '',
    min_stock: '',
    cost_price: '',
    supplier: '',
    notes: ''
  });

  const loadInventory = async () => {
    if (!currentShop) return;
    try {
      const data = await db.getInventory(currentShop.id);
      setItems(data);
    } catch (err) {
      console.error('Failed to load items:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadInventory();
    const unsub = subscribeToDBUpdates(() => {
      loadInventory();
    });
    return () => unsub();
  }, [currentShop?.id]);

  // Handle triggered restock from dashboard
  useEffect(() => {
    if (initialRestockItem) {
      handleOpenMovement(initialRestockItem, 'IN');
      if (onClearInitialRestock) onClearInitialRestock();
    }
  }, [initialRestockItem]);

  const handleOpenItemModal = (item?: InventoryItem) => {
    if (item) {
      setEditingItem(item);
      setFormData({
        name: item.name,
        category: item.category,
        unit: item.unit,
        current_stock: item.current_stock.toString(),
        min_stock: item.min_stock.toString(),
        cost_price: item.cost_price.toString(),
        supplier: item.supplier || '',
        notes: item.notes || ''
      });
    } else {
      setEditingItem(null);
      setFormData({
        name: '',
        category: 'Coffee Beans',
        unit: 'kg',
        current_stock: '0',
        min_stock: '5',
        cost_price: '0',
        supplier: '',
        notes: ''
      });
    }
    setIsItemModalOpen(true);
  };

  const handleSaveItem = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentShop) return;

    try {
      if (editingItem) {
        await db.updateInventoryItem(editingItem.id, {
          name: formData.name.trim(),
          category: formData.category,
          unit: formData.unit,
          min_stock: Number(formData.min_stock) || 0,
          cost_price: Number(formData.cost_price) || 0,
          supplier: formData.supplier.trim(),
          notes: formData.notes.trim()
        });
      } else {
        await db.createInventoryItem({
          shop_id: currentShop.id,
          name: formData.name.trim(),
          category: formData.category,
          unit: formData.unit,
          current_stock: Number(formData.current_stock) || 0,
          min_stock: Number(formData.min_stock) || 0,
          cost_price: Number(formData.cost_price) || 0,
          supplier: formData.supplier.trim(),
          notes: formData.notes.trim()
        });
      }
      setIsItemModalOpen(false);
      await loadInventory();
    } catch (err: any) {
      alert(`Gagal menyimpan item: ${err?.message || 'Error'}`);
    }
  };

  const handleDeleteItem = async (item: InventoryItem) => {
    if (!confirm(`Hapus item "${item.name}" dari inventaris? Semua riwayat stok item ini akan ikut terhapus.`)) return;
    try {
      await db.deleteInventoryItem(item.id);
      await loadInventory();
    } catch (err: any) {
      alert(`Gagal menghapus: ${err?.message}`);
    }
  };

  const handleOpenMovement = (item: InventoryItem, type: TransactionType) => {
    setMovementTargetItem(item);
    setMovementType(type);
    setMovementQty('');
    setMovementNotes('');
    setMovementError(null);
    setIsMovementModalOpen(true);
  };

  const handleSubmitMovement = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentShop || !currentUser || !movementTargetItem) return;

    const qty = Number(movementQty);
    if (isNaN(qty) || qty < 0) {
      setMovementError('Masukkan jumlah yang valid.');
      return;
    }

    if (movementType === 'OUT' && qty > movementTargetItem.current_stock) {
      setMovementError(`Jumlah keluar (${qty} ${movementTargetItem.unit}) melebihi stok yang tersedia (${movementTargetItem.current_stock} ${movementTargetItem.unit}).`);
      return;
    }

    try {
      setIsSubmittingMovement(true);
      await db.recordStockMovement({
        shop_id: currentShop.id,
        item_id: movementTargetItem.id,
        type: movementType,
        quantity: qty,
        notes: movementNotes.trim() || undefined,
        user: { id: currentUser.id, name: currentUser.name }
      });
      setIsMovementModalOpen(false);
      await loadInventory();
    } catch (err: any) {
      setMovementError(err?.message || 'Gagal memperbarui stok.');
    } finally {
      setIsSubmittingMovement(false);
    }
  };

  const handleViewHistory = async (item: InventoryItem) => {
    setHistoryItem(item);
    setLoadingHistory(true);
    try {
      const history = await db.getTransactions(item.shop_id, item.id, 50);
      setItemHistory(history);
    } catch (err) {
      console.error(err);
    } finally {
      setLoadingHistory(false);
    }
  };

  // Filter items
  const filteredItems = items.filter((item) => {
    const matchesSearch = item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (item.supplier && item.supplier.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchesCategory = selectedCategory === 'ALL' || item.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const formatRupiah = (val: number) => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      maximumFractionDigits: 0
    }).format(val);
  };

  return (
    <div className="space-y-4 pb-20">
      {/* Top Controls: Search & Category Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Cari biji kopi, sirup, susu, supplier..."
            className="w-full pl-10 pr-4 py-2.5 bg-[#0F172A]/80 backdrop-blur-xl border border-white/10 rounded-xl text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-emerald-500 shadow-md"
          />
        </div>

        {/* Add item button */}
        <button
          onClick={() => handleOpenItemModal()}
          className="min-h-[44px] flex items-center justify-center gap-2 px-4 py-2 bg-gradient-to-r from-emerald-500 to-teal-600 text-slate-950 font-bold text-xs sm:text-sm rounded-xl hover:brightness-110 active:scale-95 transition-all shadow-md shadow-emerald-500/20 shrink-0 cursor-pointer"
        >
          <Plus className="w-4 h-4 stroke-[3]" />
          <span>Tambah Item Stok</span>
        </button>
      </div>

      {/* Category Filter Chips / Segmented Control */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none text-xs">
        <button
          onClick={() => setSelectedCategory('ALL')}
          className={`px-3 py-1.5 rounded-xl font-medium whitespace-nowrap transition-all min-h-[36px] cursor-pointer ${
            selectedCategory === 'ALL'
              ? 'bg-gradient-to-r from-emerald-500 to-teal-600 text-slate-950 font-bold shadow-sm'
              : 'bg-white/[0.04] text-slate-400 hover:text-slate-100 border border-white/5'
          }`}
        >
          Semua ({items.length})
        </button>
        {CATEGORIES.map((cat) => {
          const count = items.filter((i) => i.category === cat).length;
          return (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1.5 rounded-xl font-medium whitespace-nowrap transition-all min-h-[36px] cursor-pointer ${
                selectedCategory === cat
                  ? 'bg-gradient-to-r from-emerald-500 to-teal-600 text-slate-950 font-bold shadow-sm'
                  : 'bg-white/[0.04] text-slate-400 hover:text-slate-100 border border-white/5'
              }`}
            >
              {cat} ({count})
            </button>
          );
        })}
      </div>

      {/* Inventory Item List */}
      {filteredItems.length === 0 ? (
        <div className="bg-[#0F172A]/80 backdrop-blur-xl border border-white/10 rounded-2xl p-8 text-center text-slate-400 shadow-lg">
          <Package className="w-10 h-10 mx-auto text-slate-600 mb-2" />
          <p className="text-sm">Tidak ada item inventaris yang cocok.</p>
          <p className="text-xs text-slate-500 mt-1">Gunakan tombol "Tambah Item Stok" di atas untuk menambahkan bahan baku baru.</p>
        </div>
      ) : (
        <div className="space-y-2.5">
          {filteredItems.map((item) => {
            const isLow = Number(item.current_stock) <= Number(item.min_stock);
            return (
              <div
                key={item.id}
                className={`p-3.5 sm:p-4 rounded-2xl bg-[#0F172A]/80 backdrop-blur-xl border transition-all shadow-md ${
                  isLow ? 'border-amber-500/30 bg-amber-950/15' : 'border-white/10 hover:border-emerald-500/30'
                }`}
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  {/* Left info */}
                  <div className="overflow-hidden">
                    <div className="flex items-center gap-2">
                      <span className="text-xs text-emerald-400 font-medium">{item.category}</span>
                      {isLow && (
                        <>
                          <span aria-hidden="true" className="text-slate-600">·</span>
                          <span className="text-xs text-amber-400 font-medium flex items-center gap-1">
                            <AlertTriangle className="w-3 h-3" />
                            Stok Menipis
                          </span>
                        </>
                      )}
                    </div>

                    <h3 className="text-sm sm:text-base font-semibold text-slate-100 mt-0.5 truncate">
                      {item.name}
                    </h3>

                    <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-slate-400 mt-1">
                      <span>Harga Beli: <strong className="text-emerald-400 font-mono">{formatRupiah(item.cost_price)}</strong>/{item.unit}</span>
                      <span aria-hidden="true">·</span>
                      <span>Min: <strong className="font-mono text-slate-200">{item.min_stock} {item.unit}</strong></span>
                      {item.supplier && (
                        <>
                          <span aria-hidden="true">·</span>
                          <span className="truncate">Supplier: {item.supplier}</span>
                        </>
                      )}
                    </div>
                  </div>

                  {/* Right: Current Stock count & Action Buttons */}
                  <div className="flex items-center justify-between sm:justify-end gap-3 pt-2 sm:pt-0 border-t sm:border-t-0 border-[#271E17]">
                    <div className="text-left sm:text-right">
                      <div className="text-xs text-[#7F7063]">Sisa Stok</div>
                      <div className={`text-xl sm:text-2xl font-bold font-mono tabular-nums ${
                        isLow ? 'text-amber-400' : 'text-[#F4ECE6]'
                      }`}>
                        {item.current_stock}{' '}
                        <span className="text-xs font-normal text-[#A8988B]">{item.unit}</span>
                      </div>
                    </div>

                    {/* Operational Action buttons (Hit targets >= 44x44px) */}
                    <div className="flex items-center gap-1.5 shrink-0">
                      {/* Stok Masuk (+) */}
                      <button
                        onClick={() => handleOpenMovement(item, 'IN')}
                        title="Catat Stok Masuk"
                        className="min-h-[40px] px-2.5 py-1.5 rounded-xl bg-emerald-950/60 hover:bg-emerald-900/60 text-emerald-400 border border-emerald-800/60 text-xs font-semibold flex items-center gap-1 transition-colors"
                      >
                        <ArrowDownLeft className="w-3.5 h-3.5" />
                        <span>Masuk</span>
                      </button>

                      {/* Stok Keluar (-) */}
                      <button
                        onClick={() => handleOpenMovement(item, 'OUT')}
                        title="Catat Stok Keluar"
                        className="min-h-[40px] px-2.5 py-1.5 rounded-xl bg-amber-950/60 hover:bg-amber-900/60 text-amber-400 border border-amber-800/60 text-xs font-semibold flex items-center gap-1 transition-colors"
                      >
                        <ArrowUpRight className="w-3.5 h-3.5" />
                        <span>Keluar</span>
                      </button>

                      {/* Opname / Adjustment */}
                      <button
                        onClick={() => handleOpenMovement(item, 'ADJUSTMENT')}
                        title="Opname / Penyesuaian Stok"
                        className="min-h-[40px] min-w-[40px] flex items-center justify-center rounded-xl bg-[#251D17] hover:bg-[#32261E] text-[#C5A059] border border-[#3E2E21] transition-colors"
                      >
                        <SlidersHorizontal className="w-3.5 h-3.5" />
                      </button>

                      {/* Riwayat Mutasi */}
                      <button
                        onClick={() => handleViewHistory(item)}
                        title="Riwayat Mutasi Item"
                        className="min-h-[40px] min-w-[40px] flex items-center justify-center rounded-xl bg-[#251D17] hover:bg-[#32261E] text-[#A8988B] border border-[#3E2E21] transition-colors"
                      >
                        <History className="w-3.5 h-3.5" />
                      </button>

                      {/* Edit (Staff can edit, delete restricted to Owner/Master) */}
                      <button
                        onClick={() => handleOpenItemModal(item)}
                        title="Edit Item"
                        className="min-h-[40px] min-w-[40px] flex items-center justify-center rounded-xl bg-[#251D17] hover:bg-[#32261E] text-[#A8988B] border border-[#3E2E21] transition-colors"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                      </button>

                      {!isStaff && (
                        <button
                          onClick={() => handleDeleteItem(item)}
                          title="Hapus Item"
                          className="min-h-[40px] min-w-[40px] flex items-center justify-center rounded-xl bg-red-950/40 hover:bg-red-900/60 text-red-400 border border-red-900/50 transition-colors"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* MODAL 1: Tambah / Edit Item Form */}
      {isItemModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-[#1A1410] border border-[#34261B] rounded-2xl w-full max-w-lg p-5 sm:p-6 shadow-2xl space-y-4 my-8">
            <div className="flex items-center justify-between pb-3 border-b border-[#2C2117]">
              <h3 className="text-base font-bold text-[#F4ECE6]">
                {editingItem ? 'Edit Item Inventaris' : 'Tambah Item Inventaris Baru'}
              </h3>
              <button
                onClick={() => setIsItemModalOpen(false)}
                className="text-[#8E7E72] hover:text-[#E8DFD8] p-1.5 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveItem} className="space-y-3.5">
              <div>
                <label className="block text-xs font-medium text-[#C8BCB3] mb-1">
                  Nama Item / Bahan Baku *
                </label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="Contoh: Arabica Gayo Washed, Susu Oatside, Paper Cup 8oz"
                  className="w-full px-3 py-2 bg-[#120F0D] border border-[#35281E] rounded-xl text-sm text-[#E8DFD8] focus:outline-none focus:border-[#C5A059]"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-[#C8BCB3] mb-1">
                    Kategori *
                  </label>
                  <select
                    value={formData.category}
                    onChange={(e) => setFormData({ ...formData, category: e.target.value as InventoryCategory })}
                    className="w-full px-3 py-2 bg-[#120F0D] border border-[#35281E] rounded-xl text-sm text-[#E8DFD8] focus:outline-none focus:border-[#C5A059]"
                  >
                    {CATEGORIES.map((cat) => (
                      <option key={cat} value={cat}>{cat}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-[#C8BCB3] mb-1">
                    Satuan *
                  </label>
                  <select
                    value={formData.unit}
                    onChange={(e) => setFormData({ ...formData, unit: e.target.value as StockUnit })}
                    className="w-full px-3 py-2 bg-[#120F0D] border border-[#35281E] rounded-xl text-sm text-[#E8DFD8] focus:outline-none focus:border-[#C5A059]"
                  >
                    {UNITS.map((u) => (
                      <option key={u} value={u}>{u}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                {!editingItem && (
                  <div>
                    <label className="block text-xs font-medium text-[#C8BCB3] mb-1">
                      Jumlah Stok Awal
                    </label>
                    <input
                      type="number"
                      step="any"
                      value={formData.current_stock}
                      onChange={(e) => setFormData({ ...formData, current_stock: e.target.value })}
                      placeholder="0"
                      className="w-full px-3 py-2 bg-[#120F0D] border border-[#35281E] rounded-xl text-sm text-[#E8DFD8] font-mono focus:outline-none focus:border-[#C5A059]"
                    />
                  </div>
                )}

                <div className={editingItem ? 'col-span-2' : ''}>
                  <label className="block text-xs font-medium text-[#C8BCB3] mb-1">
                    Batas Minimum Stok *
                  </label>
                  <input
                    type="number"
                    step="any"
                    value={formData.min_stock}
                    onChange={(e) => setFormData({ ...formData, min_stock: e.target.value })}
                    placeholder="Contoh: 5"
                    className="w-full px-3 py-2 bg-[#120F0D] border border-[#35281E] rounded-xl text-sm text-[#E8DFD8] font-mono focus:outline-none focus:border-[#C5A059]"
                    required
                  />
                  <span className="text-[10px] text-[#78695C]">Peringatan stok menipis jika di bawah angka ini.</span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-[#C8BCB3] mb-1">
                    Harga Beli per {formData.unit} (Rp)
                  </label>
                  <input
                    type="number"
                    value={formData.cost_price}
                    onChange={(e) => setFormData({ ...formData, cost_price: e.target.value })}
                    placeholder="0"
                    className="w-full px-3 py-2 bg-[#120F0D] border border-[#35281E] rounded-xl text-sm text-[#E8DFD8] font-mono focus:outline-none focus:border-[#C5A059]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-[#C8BCB3] mb-1">
                    Supplier / Vendor
                  </label>
                  <input
                    type="text"
                    value={formData.supplier}
                    onChange={(e) => setFormData({ ...formData, supplier: e.target.value })}
                    placeholder="Nama vendor supplier"
                    className="w-full px-3 py-2 bg-[#120F0D] border border-[#35281E] rounded-xl text-sm text-[#E8DFD8] focus:outline-none focus:border-[#C5A059]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-[#C8BCB3] mb-1">
                  Catatan Tambahan
                </label>
                <textarea
                  rows={2}
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  placeholder="Keterangan rasa, roast level, atau instruksi penyimpanan..."
                  className="w-full px-3 py-2 bg-[#120F0D] border border-[#35281E] rounded-xl text-sm text-[#E8DFD8] focus:outline-none focus:border-[#C5A059]"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-[#2C2117]">
                <button
                  type="button"
                  onClick={() => setIsItemModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs font-medium text-[#A8988B] hover:bg-[#251D17]"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-[#C5A059] text-[#120F0D] text-xs font-bold hover:brightness-110 active:scale-95 transition-all shadow-md"
                >
                  {editingItem ? 'Simpan Perubahan' : 'Tambahkan Item'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 2: Catat Mutasi Stok (IN / OUT / ADJUSTMENT) */}
      {isMovementModalOpen && movementTargetItem && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#1A1410] border border-[#34261B] rounded-2xl w-full max-w-md p-5 sm:p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-[#2C2117]">
              <div>
                <h3 className="text-base font-bold text-[#F4ECE6]">
                  {movementType === 'IN' && 'Catat Stok Masuk (Restock)'}
                  {movementType === 'OUT' && 'Catat Stok Keluar'}
                  {movementType === 'ADJUSTMENT' && 'Penyesuaian / Stok Opname'}
                </h3>
                <p className="text-xs text-[#C5A059] font-medium mt-0.5">
                  {movementTargetItem.name}
                </p>
              </div>
              <button
                onClick={() => setIsMovementModalOpen(false)}
                className="text-[#8E7E72] hover:text-[#E8DFD8] p-1.5 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmitMovement} className="space-y-4">
              {movementError && (
                <div className="p-3 text-xs bg-red-950/60 border border-red-800/60 text-red-300 rounded-xl">
                  {movementError}
                </div>
              )}

              {/* Current stock status */}
              <div className="p-3 bg-[#120F0D] rounded-xl border border-[#2D2117] flex items-center justify-between">
                <span className="text-xs text-[#8E7E72]">Stok Saat Ini:</span>
                <span className="text-sm font-bold font-mono text-[#F4ECE6]">
                  {movementTargetItem.current_stock} {movementTargetItem.unit}
                </span>
              </div>

              <div>
                <label className="block text-xs font-medium text-[#C8BCB3] mb-1.5">
                  {movementType === 'ADJUSTMENT' ? 'Jumlah Stok Fisik Sebenarnya' : 'Jumlah Perubahan'} ({movementTargetItem.unit}) *
                </label>
                <input
                  type="number"
                  step="any"
                  value={movementQty}
                  onChange={(e) => setMovementQty(e.target.value)}
                  placeholder={movementType === 'ADJUSTMENT' ? `Stok baru (misal: 12.5)` : `Jumlah ${movementTargetItem.unit} (misal: 5)`}
                  className="w-full px-3 py-2.5 bg-[#120F0D] border border-[#35281E] rounded-xl text-base font-mono text-[#E8DFD8] focus:outline-none focus:border-[#C5A059]"
                  required
                  autoFocus
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-[#C8BCB3] mb-1.5">
                  Keterangan / Alasan
                </label>
                <input
                  type="text"
                  value={movementNotes}
                  onChange={(e) => setMovementNotes(e.target.value)}
                  placeholder={
                    movementType === 'IN'
                      ? 'Contoh: Restock faktur supplier #821'
                      : movementType === 'OUT'
                      ? 'Contoh: Spillage tumpah / sampel cupping'
                      : 'Contoh: Hasil stock opname bulanan'
                  }
                  className="w-full px-3 py-2 bg-[#120F0D] border border-[#35281E] rounded-xl text-sm text-[#E8DFD8] focus:outline-none focus:border-[#C5A059]"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-[#2C2117]">
                <button
                  type="button"
                  onClick={() => setIsMovementModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs font-medium text-[#A8988B] hover:bg-[#251D17]"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  disabled={isSubmittingMovement}
                  className={`px-5 py-2.5 rounded-xl text-xs font-bold transition-all shadow-md ${
                    movementType === 'IN'
                      ? 'bg-emerald-500 text-black hover:bg-emerald-400'
                      : movementType === 'OUT'
                      ? 'bg-amber-500 text-black hover:bg-amber-400'
                      : 'bg-[#C5A059] text-[#120F0D] hover:brightness-110'
                  }`}
                >
                  {isSubmittingMovement ? 'Menyimpan...' : 'Simpan Mutasi'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* DRAWER / MODAL 3: Riwayat Mutasi Stok Item */}
      {historyItem && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4">
          <div className="bg-[#1A1410] border border-[#34261B] rounded-t-3xl sm:rounded-2xl w-full max-w-lg max-h-[85vh] flex flex-col p-5 sm:p-6 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-[#2C2117]">
              <div>
                <h3 className="text-base font-bold text-[#F4ECE6]">Riwayat Mutasi Stok</h3>
                <p className="text-xs text-[#C5A059] font-medium mt-0.5">{historyItem.name}</p>
              </div>
              <button
                onClick={() => setHistoryItem(null)}
                className="text-[#8E7E72] hover:text-[#E8DFD8] p-1.5 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto py-3 space-y-2">
              {loadingHistory ? (
                <div className="py-8 text-center text-xs text-[#8E7E72]">Memuat riwayat...</div>
              ) : itemHistory.length === 0 ? (
                <div className="py-8 text-center text-xs text-[#8E7E72]">
                  Belum ada riwayat transaksi untuk item ini.
                </div>
              ) : (
                itemHistory.map((tx) => {
                  const isIncoming = tx.type === 'IN' || tx.type === 'PRODUCTION_IN';
                  return (
                    <div
                      key={tx.id}
                      className="p-3 bg-[#130F0D] border border-[#2B2018] rounded-xl flex items-center justify-between"
                    >
                      <div>
                        <div className="flex items-center gap-1.5">
                          <span
                            className={`text-xs font-bold font-mono ${
                              isIncoming ? 'text-emerald-400' : 'text-amber-400'
                            }`}
                          >
                            {isIncoming ? '+' : '-'}{tx.quantity} {historyItem.unit}
                          </span>
                          <span className="text-[10px] text-[#7F7063]">
                            ({tx.previous_stock} &rarr; {tx.new_stock} {historyItem.unit})
                          </span>
                        </div>
                        <div className="text-xs text-[#D8CCC1] mt-0.5">
                          {tx.notes || (
                            tx.type === 'IN' ? 'Stok Masuk' :
                            tx.type === 'OUT' ? 'Stok Keluar' :
                            tx.type === 'PRODUCTION_USE' ? 'Produksi (Pemakaian Beans)' :
                            tx.type === 'PRODUCTION_IN' ? 'Produksi (Hasil Espresso)' :
                            tx.type === 'ESPRESSO_USAGE' ? 'Pemakaian Espresso Serving' :
                            tx.type === 'WASTE' ? 'Waste / Susut' : 'Penyesuaian'
                          )}
                        </div>
                        <div className="text-[10px] text-[#7F7063] mt-0.5 flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          <span>{new Date(tx.created_at).toLocaleString('id-ID')}</span>
                          <span>·</span>
                          <span>Oleh: {tx.created_by}</span>
                        </div>
                      </div>
                    </div>
                  );
                })
              )}
            </div>

            <div className="pt-3 border-t border-[#2C2117] text-right">
              <button
                onClick={() => setHistoryItem(null)}
                className="px-4 py-2 bg-[#261E18] text-[#E8DFD8] text-xs font-medium rounded-xl hover:bg-[#32261E]"
              >
                Tutup
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
