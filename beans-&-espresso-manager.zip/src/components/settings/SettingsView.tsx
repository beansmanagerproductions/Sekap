import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { db, initSupabaseRealtimeListener } from '../../services/database';
import { 
  getStoredSupabaseConfig, 
  saveSupabaseConfig, 
  clearSupabaseConfig, 
  testSupabaseConnection, 
  SUPABASE_SQL_SCHEMA
} from '../../services/supabaseClient';
import { 
  Settings, 
  Database, 
  Wifi, 
  Copy, 
  Check, 
  RefreshCw, 
  Store, 
  User, 
  Shield, 
  LogOut,
  AlertTriangle,
  UploadCloud,
  CheckCircle2,
  ExternalLink,
  Code2,
  X
} from 'lucide-react';

export const SettingsView: React.FC = () => {
  const { currentUser, currentShop, logout, refreshAuthData } = useAuth();
  
  // Supabase input states
  const [supabaseUrl, setSupabaseUrl] = useState('');
  const [supabaseAnonKey, setSupabaseAnonKey] = useState('');
  const [testResult, setTestResult] = useState<{ success: boolean; message: string; tablesExist?: boolean } | null>(null);
  const [isTesting, setIsTesting] = useState(false);
  const [isSyncingData, setIsSyncingData] = useState(false);
  const [syncMessage, setSyncMessage] = useState<string | null>(null);
  const [copiedSql, setCopiedSql] = useState(false);
  const [showSqlModal, setShowSqlModal] = useState(false);

  // Shop Edit State
  const [shopName, setShopName] = useState(currentShop?.name || '');
  const [shopAddress, setShopAddress] = useState(currentShop?.address || '');
  const [shopPhone, setShopPhone] = useState(currentShop?.phone || '');
  const [conversionRatioInput, setConversionRatioInput] = useState(
    currentShop?.conversion_ratio ? currentShop.conversion_ratio.toString() : '3.0'
  );
  const [isSavingShop, setIsSavingShop] = useState(false);
  const [shopSaveSuccess, setShopSaveSuccess] = useState(false);

  useEffect(() => {
    const config = getStoredSupabaseConfig();
    setSupabaseUrl(config.url);
    setSupabaseAnonKey(config.anonKey);
  }, []);

  useEffect(() => {
    if (currentShop) {
      setShopName(currentShop.name);
      setShopAddress(currentShop.address || '');
      setShopPhone(currentShop.phone || '');
      setConversionRatioInput(
        currentShop.conversion_ratio ? currentShop.conversion_ratio.toString() : '3.0'
      );
    }
  }, [currentShop]);

  const handleTestConnection = async () => {
    setIsTesting(true);
    setTestResult(null);
    setSyncMessage(null);
    try {
      const res = await testSupabaseConnection(supabaseUrl, supabaseAnonKey);
      setTestResult(res);

      if (res.success) {
        saveSupabaseConfig(supabaseUrl, supabaseAnonKey);
        initSupabaseRealtimeListener();
      }
    } catch (e: any) {
      setTestResult({ success: false, message: e?.message || 'Gagal mengetes koneksi.' });
    } finally {
      setIsTesting(false);
    }
  };

  const handleSaveSupabaseConfig = async () => {
    saveSupabaseConfig(supabaseUrl, supabaseAnonKey);
    initSupabaseRealtimeListener();
    await handleTestConnection();
  };

  const handleClearConfig = () => {
    clearSupabaseConfig();
    setSupabaseUrl('');
    setSupabaseAnonKey('');
    setTestResult(null);
  };

  const handleCopySql = () => {
    navigator.clipboard.writeText(SUPABASE_SQL_SCHEMA);
    setCopiedSql(true);
    setTimeout(() => setCopiedSql(false), 3000);
  };

  const handleUploadLocalSeedToSupabase = async () => {
    setIsSyncingData(true);
    setSyncMessage(null);
    try {
      const res = await db.pushLocalDataToSupabase();
      setSyncMessage(res.message);
      if (res.success) {
        await refreshAuthData();
      }
    } catch (e: any) {
      setSyncMessage(e?.message || 'Error saat sinkronisasi');
    } finally {
      setIsSyncingData(false);
    }
  };

  const handleSaveShopProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentShop) return;
    setIsSavingShop(true);
    try {
      const ratioNum = parseFloat(conversionRatioInput) || 3.0;
      if (ratioNum <= 0) {
        alert('Rasio konversi harus lebih dari 0.');
        setIsSavingShop(false);
        return;
      }

      await db.updateShop(currentShop.id, {
        name: shopName.trim(),
        address: shopAddress.trim(),
        phone: shopPhone.trim(),
        conversion_ratio: ratioNum
      });
      setShopSaveSuccess(true);
      setTimeout(() => setShopSaveSuccess(false), 3000);
      await refreshAuthData();
    } catch (e: any) {
      alert(`Gagal menyimpan toko: ${e?.message}`);
    } finally {
      setIsSavingShop(false);
    }
  };

  const isConfigured = Boolean(supabaseUrl && supabaseAnonKey);

  return (
    <div className="space-y-6 pb-20 max-w-4xl mx-auto">
      {/* Header Banner */}
      <div className="bg-[#0F172A]/80 backdrop-blur-xl border border-white/10 rounded-2xl p-4 sm:p-5 shadow-lg">
        <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-emerald-400 mb-1">
          <Settings className="w-4 h-4" />
          <span>Konfigurasi & Pengaturan</span>
        </div>
        <h2 className="text-lg sm:text-xl font-bold text-slate-100">
          Pengaturan Sistem & Database Supabase
        </h2>
        <p className="text-xs text-slate-400 mt-0.5">
          Hubungkan ke Supabase Database & Realtime untuk sinkronisasi otomatis antar tablet kasir & smartphone bar.
        </p>
      </div>

      {/* SECTION 1: SUPABASE CONFIGURATION */}
      <div className="bg-[#0F172A]/80 backdrop-blur-xl border border-white/10 rounded-2xl p-5 shadow-xl space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-white/10">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-[#1E293B] to-[#0F172A] border border-white/10 flex items-center justify-center text-emerald-400 shadow-inner">
              <Database className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm sm:text-base font-bold text-slate-100">
                Koneksi Supabase (Database & Realtime)
              </h3>
              <p className="text-xs text-slate-400">
                Hanya memerlukan Project URL dan Anon/Publishable Key (Tanpa Supabase Auth)
              </p>
            </div>
          </div>

          <span
            className={`text-xs px-2.5 py-1 rounded-full font-semibold flex items-center gap-1.5 ${
              isConfigured
                ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                : 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
            }`}
          >
            <span className={`w-2 h-2 rounded-full ${isConfigured ? 'bg-emerald-400 shadow-[0_0_6px_#10B981]' : 'bg-amber-400'}`} />
            <span>{isConfigured ? 'Terkonfigurasi' : 'Mode Offline/Lokal'}</span>
          </span>
        </div>

        {/* Inputs */}
        <div className="space-y-3">
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">
              1. Supabase Project URL *
            </label>
            <input
              type="url"
              value={supabaseUrl}
              onChange={(e) => setSupabaseUrl(e.target.value.trim())}
              placeholder="https://your-project-id.supabase.co"
              className="w-full px-3 py-2.5 bg-[#090D16] border border-white/10 rounded-xl text-xs sm:text-sm font-mono text-slate-100 focus:outline-none focus:border-emerald-500"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">
              2. Supabase Anon / Publishable Key *
            </label>
            <input
              type="text"
              value={supabaseAnonKey}
              onChange={(e) => setSupabaseAnonKey(e.target.value.trim())}
              placeholder="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
              className="w-full px-3 py-2.5 bg-[#090D16] border border-white/10 rounded-xl text-xs sm:text-sm font-mono text-slate-100 focus:outline-none focus:border-emerald-500"
            />
          </div>
        </div>

        {/* Test Result Feedback */}
        {testResult && (
          <div
            className={`p-3.5 rounded-xl text-xs border ${
              testResult.success
                ? 'bg-emerald-950/60 border-emerald-800 text-emerald-300'
                : 'bg-red-950/60 border-red-800 text-red-300'
            }`}
          >
            <div className="flex items-start gap-2">
              {testResult.success ? (
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              ) : (
                <AlertTriangle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
              )}
              <div>
                <p className="font-semibold">{testResult.message}</p>
                {testResult.tablesExist === false && (
                  <p className="mt-1 text-[11px] text-amber-200">
                    Gunakan tombol "Salin Skrip SQL Supabase" di bawah, buka SQL Editor di Supabase Console, lalu paste & Run.
                  </p>
                )}
              </div>
            </div>
          </div>
        )}

        {syncMessage && (
          <div className="p-3 bg-[#241A14] border border-[#3E2D20] text-[#E8DFD8] rounded-xl text-xs flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-[#C5A059]" />
            <span>{syncMessage}</span>
          </div>
        )}

        {/* Action Buttons */}
        <div className="flex flex-wrap items-center gap-2.5 pt-2">
          <button
            onClick={handleTestConnection}
            disabled={isTesting || !supabaseUrl || !supabaseAnonKey}
            className="min-h-[44px] flex items-center gap-2 px-4 py-2 bg-[#C5A059] text-[#120F0D] font-bold text-xs rounded-xl hover:brightness-110 active:scale-95 transition-all disabled:opacity-50"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isTesting ? 'animate-spin' : ''}`} />
            <span>{isTesting ? 'Menguji Koneksi...' : 'Test & Simpan Koneksi'}</span>
          </button>

          <button
            onClick={handleCopySql}
            className="min-h-[44px] flex items-center gap-2 px-3.5 py-2 bg-[#251D17] hover:bg-[#32251D] text-[#E8DFD8] border border-[#3E2E22] font-semibold text-xs rounded-xl active:scale-95 transition-colors"
          >
            {copiedSql ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-400" />
                <span className="text-emerald-400">Skrip SQL Disalin!</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5 text-[#C5A059]" />
                <span>Salin Skrip SQL Supabase</span>
              </>
            )}
          </button>

          <button
            onClick={() => setShowSqlModal(true)}
            className="min-h-[44px] flex items-center gap-2 px-3.5 py-2 bg-[#251D17] hover:bg-[#32251D] text-[#A8988B] hover:text-[#E8DFD8] border border-[#3E2E22] font-medium text-xs rounded-xl transition-colors"
          >
            <Code2 className="w-3.5 h-3.5" />
            <span>Lihat Skrip SQL</span>
          </button>

          {isConfigured && (
            <button
              onClick={handleUploadLocalSeedToSupabase}
              disabled={isSyncingData}
              className="min-h-[44px] flex items-center gap-2 px-3.5 py-2 bg-[#211710] hover:bg-[#2E1E14] text-[#C5A059] border border-[#483323] font-medium text-xs rounded-xl transition-colors disabled:opacity-50"
              title="Unggah data toko, stok, dan akun awal ke Supabase"
            >
              <UploadCloud className="w-3.5 h-3.5" />
              <span>{isSyncingData ? 'Mengunggah...' : 'Inisialisasi Data ke Supabase'}</span>
            </button>
          )}

          {isConfigured && (
            <button
              onClick={handleClearConfig}
              className="text-xs text-[#8E7E72] hover:text-red-400 px-3 py-2 ml-auto"
            >
              Hapus Konfigurasi
            </button>
          )}
        </div>
      </div>

      {/* SECTION 2: PROFIL TOKO (OWNER & MASTER ONLY) */}
      {currentShop && currentUser?.role !== 'STAFF' && (
        <div className="bg-[#0F172A]/80 backdrop-blur-xl border border-white/10 rounded-2xl p-5 shadow-xl space-y-4">
          <div className="flex items-center gap-2.5 pb-3 border-b border-white/10">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-[#1E293B] to-[#0F172A] border border-white/10 flex items-center justify-center text-emerald-400 shadow-inner">
              <Store className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm sm:text-base font-bold text-slate-100">
                Profil Coffee Shop
              </h3>
              <p className="text-xs text-slate-400">
                Informasi toko dan standar konversi espresso
              </p>
            </div>
          </div>

          {shopSaveSuccess && (
            <div className="p-3 bg-emerald-950/60 border border-emerald-800 text-emerald-300 rounded-xl text-xs flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span>Data profil toko berhasil disimpan!</span>
            </div>
          )}

          <form onSubmit={handleSaveShopProfile} className="space-y-3">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Nama Coffee Shop *
              </label>
              <input
                type="text"
                value={shopName}
                onChange={(e) => setShopName(e.target.value)}
                className="w-full px-3 py-2 bg-[#090D16] border border-white/10 rounded-xl text-sm text-slate-100 focus:outline-none focus:border-emerald-500"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Alamat Toko
              </label>
              <input
                type="text"
                value={shopAddress}
                onChange={(e) => setShopAddress(e.target.value)}
                className="w-full px-3 py-2 bg-[#090D16] border border-white/10 rounded-xl text-sm text-slate-100 focus:outline-none focus:border-emerald-500"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                No. Telepon / Kontak
              </label>
              <input
                type="text"
                value={shopPhone}
                onChange={(e) => setShopPhone(e.target.value)}
                className="w-full px-3 py-2 bg-[#090D16] border border-white/10 rounded-xl text-sm text-slate-100 focus:outline-none focus:border-emerald-500"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Rasio Konversi Produksi (1 KG Beans = X Liter Espresso) *
              </label>
              <div className="flex items-center gap-3">
                <div className="relative flex-1">
                  <input
                    type="number"
                    step="0.1"
                    min="1.0"
                    max="10.0"
                    value={conversionRatioInput}
                    onChange={(e) => setConversionRatioInput(e.target.value)}
                    className="w-full px-3 py-2 bg-[#090D16] border border-white/10 rounded-xl text-sm font-mono text-slate-100 focus:outline-none focus:border-emerald-500"
                    required
                  />
                  <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-emerald-400 font-bold">
                    Liter / kg
                  </span>
                </div>
              </div>
              <p className="text-[11px] text-slate-400 mt-1">
                Default: 1 KG = 3.0 L. Perubahan hanya berlaku untuk produksi berikutnya dan tidak mengubah transaksi lama.
              </p>
            </div>

            <div className="pt-2 text-right">
              <button
                type="submit"
                disabled={isSavingShop}
                className="min-h-[44px] px-5 py-2 bg-gradient-to-r from-emerald-500 to-teal-600 text-slate-950 font-bold text-xs rounded-xl hover:brightness-110 active:scale-95 transition-all shadow-md shadow-emerald-500/20 cursor-pointer"
              >
                {isSavingShop ? 'Menyimpan...' : 'Simpan Profil Toko'}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* SECTION 3: AKUN LOGIN SAAT INI */}
      <div className="bg-[#0F172A]/80 backdrop-blur-xl border border-white/10 rounded-2xl p-5 shadow-xl space-y-4">
        <div className="flex items-center gap-2.5 pb-3 border-b border-white/10">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-[#1E293B] to-[#0F172A] border border-white/10 flex items-center justify-center text-emerald-400 shadow-inner">
            <User className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm sm:text-base font-bold text-slate-100">
              Akun Pengguna
            </h3>
            <p className="text-xs text-slate-400">
              Sesi akun yang sedang aktif di perangkat ini
            </p>
          </div>
        </div>

        <div className="p-4 bg-[#090D16] border border-white/10 rounded-xl flex items-center justify-between">
          <div>
            <div className="text-sm font-bold text-slate-100">{currentUser?.name}</div>
            <div className="text-xs text-slate-400 mt-0.5">
              Username: <span className="font-mono text-slate-200">@{currentUser?.username}</span> · Role: <strong className="text-emerald-400">{currentUser?.role}</strong>
            </div>
            {currentShop && (
              <div className="text-xs text-slate-500 mt-0.5">
                Toko: {currentShop.name}
              </div>
            )}
          </div>

          <button
            onClick={logout}
            className="min-h-[44px] flex items-center gap-2 px-4 py-2 bg-rose-500/15 hover:bg-rose-500/25 text-rose-300 border border-rose-500/30 rounded-xl text-xs font-semibold transition-colors cursor-pointer"
          >
            <LogOut className="w-4 h-4" />
            <span>Keluar</span>
          </button>
        </div>
      </div>

      {/* MODAL: VIEW SQL SCRIPT */}
      {showSqlModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#1A1410] border border-[#34261B] rounded-2xl w-full max-w-2xl max-h-[85vh] flex flex-col p-5 sm:p-6 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-[#2C2117]">
              <div>
                <h3 className="text-base font-bold text-[#F4ECE6]">Skrip SQL Supabase</h3>
                <p className="text-xs text-[#8E7E72]">Jalankan di Supabase Dashboard &rarr; SQL Editor</p>
              </div>
              <button
                onClick={() => setShowSqlModal(false)}
                className="text-[#8E7E72] hover:text-[#E8DFD8] p-1.5 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto py-3">
              <pre className="p-3 bg-[#100D0B] border border-[#261C14] rounded-xl text-[11px] font-mono text-[#C5A059] overflow-x-auto whitespace-pre">
                {SUPABASE_SQL_SCHEMA}
              </pre>
            </div>

            <div className="pt-3 border-t border-[#2C2117] flex items-center justify-between">
              <span className="text-xs text-[#8E7E72]">
                Termasuk: tabel, RLS anon access, dan publikasi Realtime
              </span>
              <div className="flex items-center gap-2">
                <button
                  onClick={handleCopySql}
                  className="px-4 py-2 bg-[#C5A059] text-[#120F0D] text-xs font-bold rounded-xl hover:brightness-110"
                >
                  {copiedSql ? 'Tersalin!' : 'Salin Semua'}
                </button>
                <button
                  onClick={() => setShowSqlModal(false)}
                  className="px-4 py-2 bg-[#251D17] text-[#E8DFD8] text-xs rounded-xl hover:bg-[#32251D]"
                >
                  Tutup
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
