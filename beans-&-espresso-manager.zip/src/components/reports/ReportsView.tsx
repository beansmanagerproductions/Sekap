import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { db, subscribeToDBUpdates } from '../../services/database';
import { 
  InventoryItem, 
  StockTransaction, 
  ProductionLog, 
  EspressoUsageLog, 
  WasteLog, 
  Expense 
} from '../../types';
import { 
  BarChart3, 
  Printer, 
  Coffee, 
  ReceiptText, 
  Calendar, 
  ChevronLeft, 
  ChevronRight, 
  Clock, 
  Layers, 
  Sparkles,
  TrendingDown,
  Info,
  CheckCircle2,
  Trash2
} from 'lucide-react';

const MONTHS_LIST = [
  { value: 0, label: 'Januari' },
  { value: 1, label: 'Februari' },
  { value: 2, label: 'Maret' },
  { value: 3, label: 'April' },
  { value: 4, label: 'Mei' },
  { value: 5, label: 'Juni' },
  { value: 6, label: 'Juli' },
  { value: 7, label: 'Agustus' },
  { value: 8, label: 'September' },
  { value: 9, label: 'Oktober' },
  { value: 10, label: 'November' },
  { value: 11, label: 'Desember' }
];

type PeriodType = 'today' | 'week' | 'month' | 'monthly_archive' | 'custom';
type DetailTabType = 'transactions' | 'productions' | 'expenses' | 'waste';

export const ReportsView: React.FC = () => {
  const { currentShop } = useAuth();
  const [items, setItems] = useState<InventoryItem[]>([]);
  const [transactions, setTransactions] = useState<StockTransaction[]>([]);
  const [productions, setProductions] = useState<ProductionLog[]>([]);
  const [usages, setUsages] = useState<EspressoUsageLog[]>([]);
  const [wasteLogs, setWasteLogs] = useState<WasteLog[]>([]);
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [loading, setLoading] = useState(true);

  // Period Filter: 'today' | 'week' | 'month' | 'monthly_archive' | 'custom'
  const [period, setPeriod] = useState<PeriodType>('monthly_archive');

  // Month & Year selector states
  const now = new Date();
  const [selectedMonth, setSelectedMonth] = useState<number>(now.getMonth());
  const [selectedYear, setSelectedYear] = useState<number>(now.getFullYear());

  // Custom date ranges
  const [customStartDate, setCustomStartDate] = useState(
    new Date(Date.now() - 30 * 86400000).toISOString().split('T')[0]
  );
  const [customEndDate, setCustomEndDate] = useState(
    new Date().toISOString().split('T')[0]
  );

  // Detail Tab
  const [activeDetailTab, setActiveDetailTab] = useState<DetailTabType>('transactions');

  const loadData = async () => {
    if (!currentShop) return;
    try {
      const [itemList, txList, prodList, useList, wasteList, expList] = await Promise.all([
        db.getInventory(currentShop.id),
        db.getTransactions(currentShop.id, undefined, 500),
        db.getProductions(currentShop.id, 300),
        db.getEspressoUsages(currentShop.id, 300),
        db.getWasteLogs(currentShop.id, 300),
        db.getExpenses(currentShop.id, 500),
      ]);

      setItems(itemList);
      setTransactions(txList);
      setProductions(prodList);
      setUsages(useList);
      setWasteLogs(wasteList);
      setExpenses(expList);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
    const unsub = subscribeToDBUpdates(() => {
      loadData();
    });
    return () => unsub();
  }, [currentShop?.id]);

  // Current live inventory stock levels (independent of period)
  const beansItems = items.filter((i) => i.category === 'Coffee Beans');
  const currentStokBeansKg = beansItems.reduce((acc, curr) => {
    const qty = Number(curr.current_stock) || 0;
    return acc + (curr.unit === 'gr' ? qty / 1000 : qty);
  }, 0);

  const espressoItems = items.filter((i) => i.category === 'Espresso Base');
  const currentStokEspressoL = espressoItems.reduce((acc, curr) => {
    const qty = Number(curr.current_stock) || 0;
    return acc + (curr.unit === 'ml' ? qty / 1000 : qty);
  }, 0);

  // Helper for current week Monday
  const getStartOfWeek = (d: Date) => {
    const date = new Date(d);
    const day = date.getDay(); // 0: Sunday, 1: Monday...
    const diff = date.getDate() - day + (day === 0 ? -6 : 1);
    date.setDate(diff);
    date.setHours(0, 0, 0, 0);
    return date;
  };

  // Determine if a record falls within the active period filter
  const isInPeriod = (isoDateString: string) => {
    if (!isoDateString) return false;
    const d = new Date(isoDateString);
    if (isNaN(d.getTime())) return false;

    if (period === 'today') {
      // Harian: 00:00:00 s/d 23:59:59 hari ini (reset setiap hari otomatis)
      const dayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0, 0);
      const dayEnd = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 23, 59, 59, 999);
      return d >= dayStart && d <= dayEnd;
    }

    if (period === 'week') {
      // Mingguan: Senin 00:00 s/d Minggu 23:59 minggu ini (reset setiap minggu baru)
      const weekStart = getStartOfWeek(now);
      const weekEnd = new Date(weekStart);
      weekEnd.setDate(weekStart.getDate() + 6);
      weekEnd.setHours(23, 59, 59, 999);
      return d >= weekStart && d <= weekEnd;
    }

    if (period === 'month') {
      // Bulanan: Tanggal 1 bulan ini 00:00 s/d akhir bulan (reset setiap awal bulan)
      const monthStart = new Date(now.getFullYear(), now.getMonth(), 1, 0, 0, 0, 0);
      const monthEnd = new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59, 999);
      return d >= monthStart && d <= monthEnd;
    }

    if (period === 'monthly_archive') {
      // Laporan Per Bulan (Agustus, September, dll):
      const mStart = new Date(selectedYear, selectedMonth, 1, 0, 0, 0, 0);
      const mEnd = new Date(selectedYear, selectedMonth + 1, 0, 23, 59, 59, 999);
      return d >= mStart && d <= mEnd;
    }

    if (period === 'custom') {
      // Rentang tanggal manual
      const cStart = new Date(customStartDate + 'T00:00:00');
      const cEnd = new Date(customEndDate + 'T23:59:59');
      return d >= cStart && d <= cEnd;
    }

    return true;
  };

  // Filtered collections based on period
  const filteredProductions = productions.filter((p) => isInPeriod(p.created_at));
  const filteredUsages = usages.filter((u) => isInPeriod(u.created_at));
  const filteredWasteLogs = wasteLogs.filter((w) => isInPeriod(w.created_at));
  const filteredExpenses = expenses.filter((e) => isInPeriod(e.expense_date));
  const filteredTransactions = transactions.filter((t) => isInPeriod(t.created_at));

  // Calculations:
  // 1. Beans Digunakan (kg)
  const totalBeansUsedKg = filteredProductions.reduce((sum, p) => sum + Number(p.beans_used_kg || 0), 0);

  // 2. Espresso Diproduksi (Liter)
  const totalEspressoProducedL = filteredProductions.reduce((sum, p) => sum + Number(p.espresso_produced_liter || 0), 0);

  // 3. Espresso Digunakan (Liter)
  const totalEspressoUsedL = filteredUsages.reduce((sum, u) => sum + Number(u.amount_liter || 0), 0);

  // 4. Waste (Liter espresso + kg beans)
  const totalWasteProdL = filteredProductions.reduce((sum, p) => sum + Number(p.waste_liter || 0), 0);
  const totalWasteLogL = filteredWasteLogs.reduce((sum, w) => sum + (w.item_type === 'ESPRESSO' ? Number(w.quantity || 0) : 0), 0);
  const totalWasteBeansKg = filteredWasteLogs.reduce((sum, w) => sum + (w.item_type === 'BEANS' ? Number(w.quantity || 0) : 0), 0);
  const totalWasteLossRp = filteredWasteLogs.reduce((sum, w) => sum + Number(w.cost_loss || 0), 0);

  // 5. Total Pengeluaran (Rp)
  const totalExpenseAmount = filteredExpenses.reduce((sum, e) => sum + Number(e.amount || 0), 0);

  // 6. HPP Rata-rata Espresso
  let avgHpp = 0;
  if (filteredProductions.length > 0) {
    const totalWeighted = filteredProductions.reduce((sum, p) => sum + (Number(p.hpp_per_liter || 0) * Number(p.espresso_produced_liter || 0)), 0);
    avgHpp = totalEspressoProducedL > 0 ? Math.round(totalWeighted / totalEspressoProducedL) : 0;
  } else if (beansItems.length > 0) {
    avgHpp = Math.round((Number(beansItems[0].cost_price) || 180000) / (currentShop?.conversion_ratio || 3.0));
  }

  const formatRupiah = (val: number) => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      maximumFractionDigits: 0,
    }).format(val);
  };

  const handlePrint = () => {
    window.print();
  };

  const handlePrevMonth = () => {
    if (selectedMonth === 0) {
      setSelectedMonth(11);
      setSelectedYear((prev) => prev - 1);
    } else {
      setSelectedMonth((prev) => prev - 1);
    }
  };

  const handleNextMonth = () => {
    if (selectedMonth === 11) {
      setSelectedMonth(0);
      setSelectedYear((prev) => prev + 1);
    } else {
      setSelectedMonth((prev) => prev + 1);
    }
  };

  // Get active period human readable description
  const getPeriodDescription = () => {
    if (period === 'today') {
      return `Hari Ini (${now.toLocaleDateString('id-ID', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}) · Reset otomatis setiap hari (00:00)`;
    }
    if (period === 'week') {
      const wStart = getStartOfWeek(now);
      const wEnd = new Date(wStart);
      wEnd.setDate(wStart.getDate() + 6);
      return `Minggu Ini (${wStart.getDate()} - ${wEnd.toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' })}) · Reset otomatis setiap Senin`;
    }
    if (period === 'month') {
      return `Bulan Ini (${MONTHS_LIST[now.getMonth()].label} ${now.getFullYear()}) · Reset otomatis setiap tanggal 1`;
    }
    if (period === 'monthly_archive') {
      return `Laporan Bulan ${MONTHS_LIST[selectedMonth].label} ${selectedYear}`;
    }
    if (period === 'custom') {
      return `Rentang Kustom: ${customStartDate} s/d ${customEndDate}`;
    }
    return '';
  };

  return (
    <div className="space-y-5 pb-20 print:p-0 print:m-0">
      {/* Title & Filter Card */}
      <div className="bg-[#0F172A]/80 backdrop-blur-xl border border-white/10 rounded-2xl p-4 sm:p-5 flex flex-col md:flex-row md:items-center justify-between gap-4 print:border-none print:bg-white print:text-black shadow-lg">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-emerald-400 mb-1 print:text-black">
            <BarChart3 className="w-4 h-4" />
            <span>Laporan Operasional & Finansial</span>
          </div>
          <h2 className="text-lg sm:text-xl font-bold text-slate-100 print:text-black">
            Laporan Coffee Shop: {currentShop?.name}
          </h2>
          <p className="text-xs text-slate-400 mt-0.5 print:text-gray-600">
            Rekap stok beans, produksi espresso, pemakaian, waste, HPP, dan pengeluaran per periode.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2 print:hidden">
          {/* Period Selection Tabs */}
          <div className="flex items-center gap-1 bg-[#090D16] p-1 rounded-xl border border-white/10 overflow-x-auto max-w-full">
            <button
              onClick={() => setPeriod('today')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap cursor-pointer ${
                period === 'today' ? 'bg-gradient-to-r from-emerald-500 to-teal-600 text-slate-950 font-bold shadow-sm' : 'text-slate-400 hover:text-slate-100'
              }`}
            >
              Hari Ini
            </button>
            <button
              onClick={() => setPeriod('week')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap cursor-pointer ${
                period === 'week' ? 'bg-gradient-to-r from-emerald-500 to-teal-600 text-slate-950 font-bold shadow-sm' : 'text-slate-400 hover:text-slate-100'
              }`}
            >
              Minggu Ini
            </button>
            <button
              onClick={() => setPeriod('month')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap cursor-pointer ${
                period === 'month' ? 'bg-gradient-to-r from-emerald-500 to-teal-600 text-slate-950 font-bold shadow-sm' : 'text-slate-400 hover:text-slate-100'
              }`}
            >
              Bulan Ini
            </button>
            <button
              onClick={() => setPeriod('monthly_archive')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap flex items-center gap-1 cursor-pointer ${
                period === 'monthly_archive' ? 'bg-gradient-to-r from-emerald-500 to-teal-600 text-slate-950 font-bold shadow-sm' : 'text-slate-400 hover:text-slate-100'
              }`}
            >
              <Calendar className="w-3.5 h-3.5" />
              <span>Per Bulan</span>
            </button>
            <button
              onClick={() => setPeriod('custom')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap cursor-pointer ${
                period === 'custom' ? 'bg-gradient-to-r from-emerald-500 to-teal-600 text-slate-950 font-bold shadow-sm' : 'text-slate-400 hover:text-slate-100'
              }`}
            >
              Kustom
            </button>
          </div>

          <button
            onClick={handlePrint}
            className="min-h-[38px] px-3.5 py-1.5 bg-[#1E293B]/70 hover:bg-[#334155] border border-white/10 text-slate-200 text-xs font-semibold rounded-xl flex items-center gap-1.5 cursor-pointer"
          >
            <Printer className="w-4 h-4 text-emerald-400" />
            <span>Cetak PDF</span>
          </button>
        </div>
      </div>

      {/* Monthly Archive Selector (Agustus, September, dll) */}
      {period === 'monthly_archive' && (
        <div className="bg-[#0F172A]/80 backdrop-blur-xl border border-white/10 rounded-2xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-lg print:hidden">
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrevMonth}
              className="p-2 rounded-xl bg-[#1E293B]/70 hover:bg-[#334155] border border-white/10 text-slate-200 transition-colors cursor-pointer"
              title="Bulan Sebelumnya"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>

            {/* Month Select */}
            <select
              value={selectedMonth}
              onChange={(e) => setSelectedMonth(Number(e.target.value))}
              className="px-3.5 py-2 bg-[#090D16] border border-white/10 rounded-xl text-xs sm:text-sm font-semibold text-slate-200 focus:outline-none focus:border-emerald-500 cursor-pointer"
            >
              {MONTHS_LIST.map((m) => (
                <option key={m.value} value={m.value} className="bg-[#0F172A] text-slate-100">
                  {m.label}
                </option>
              ))}
            </select>

            {/* Year Select */}
            <select
              value={selectedYear}
              onChange={(e) => setSelectedYear(Number(e.target.value))}
              className="px-3 py-2 bg-[#090D16] border border-white/10 rounded-xl text-xs sm:text-sm font-semibold text-slate-200 focus:outline-none focus:border-emerald-500 cursor-pointer font-mono"
            >
              {[2024, 2025, 2026, 2027, 2028].map((yr) => (
                <option key={yr} value={yr} className="bg-[#0F172A] text-slate-100">
                  {yr}
                </option>
              ))}
            </select>

            <button
              onClick={handleNextMonth}
              className="p-2 rounded-xl bg-[#1E293B]/70 hover:bg-[#334155] border border-white/10 text-slate-200 transition-colors cursor-pointer"
              title="Bulan Berikutnya"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          <div className="text-xs text-slate-300 flex items-center gap-1.5">
            <Calendar className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>
              Laporan penuh bulan <b>{MONTHS_LIST[selectedMonth].label} {selectedYear}</b>
            </span>
          </div>
        </div>
      )}

      {/* Custom Date Range Picker */}
      {period === 'custom' && (
        <div className="bg-[#0F172A]/80 backdrop-blur-xl border border-white/10 rounded-2xl p-4 flex flex-wrap items-center gap-4 text-xs print:hidden shadow-lg">
          <div className="flex items-center gap-2">
            <span className="text-slate-400 font-medium">Dari Tanggal:</span>
            <input
              type="date"
              value={customStartDate}
              onChange={(e) => setCustomStartDate(e.target.value)}
              className="px-3 py-1.5 bg-[#090D16] border border-white/10 rounded-xl text-sm text-slate-200 focus:outline-none focus:border-emerald-500"
            />
          </div>
          <div className="flex items-center gap-2">
            <span className="text-slate-400 font-medium">Sampai Tanggal:</span>
            <input
              type="date"
              value={customEndDate}
              onChange={(e) => setCustomEndDate(e.target.value)}
              className="px-3 py-1.5 bg-[#090D16] border border-white/10 rounded-xl text-sm text-slate-200 focus:outline-none focus:border-emerald-500"
            />
          </div>
        </div>
      )}

      {/* Info Banner on reset & data persistence */}
      <div className="p-3 bg-emerald-500/10 border border-emerald-500/20 rounded-xl flex items-center justify-between gap-3 text-xs text-slate-300">
        <div className="flex items-center gap-2">
          <Info className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>
            <b>Periode:</b> {getPeriodDescription()}
          </span>
        </div>
        <span className="text-[11px] text-emerald-400 font-medium hidden sm:inline">
          ✓ Seluruh data transaksi tetap tersimpan permanen
        </span>
      </div>

      {/* 8 OWNER REPORT METRICS GRID */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 sm:gap-4">
        {/* 1. Stok Beans Saat Ini */}
        <div className="bg-[#0F172A]/70 backdrop-blur-md border border-white/10 rounded-2xl p-4 shadow-lg">
          <div className="text-[11px] text-slate-400 uppercase font-semibold">Stok Beans Saat Ini</div>
          <div className="text-xl sm:text-2xl font-bold font-mono text-white mt-1">
            {currentStokBeansKg.toFixed(2)} <span className="text-xs font-normal">kg</span>
          </div>
          <div className="text-[10px] text-slate-400 mt-0.5">Sisa stok gudang bar</div>
        </div>

        {/* 2. Stok Espresso Saat Ini */}
        <div className="bg-[#0F172A]/70 backdrop-blur-md border border-white/10 rounded-2xl p-4 shadow-lg">
          <div className="text-[11px] text-slate-400 uppercase font-semibold">Stok Espresso Saat Ini</div>
          <div className="text-xl sm:text-2xl font-bold font-mono text-emerald-400 mt-1">
            {currentStokEspressoL.toFixed(2)} <span className="text-xs font-normal">Liter</span>
          </div>
          <div className="text-[10px] text-slate-400 mt-0.5">Siap pakai di wadah</div>
        </div>

        {/* 3. Beans Digunakan */}
        <div className="bg-[#0F172A]/70 backdrop-blur-md border border-white/10 rounded-2xl p-4 shadow-lg">
          <div className="text-[11px] text-slate-400 uppercase font-semibold">Beans Digunakan</div>
          <div className="text-xl sm:text-2xl font-bold font-mono text-amber-400 mt-1">
            {totalBeansUsedKg.toFixed(2)} <span className="text-xs font-normal">kg</span>
          </div>
          <div className="text-[10px] text-slate-400 mt-0.5">Total biji kopi terpakai</div>
        </div>

        {/* 4. Espresso Diproduksi */}
        <div className="bg-[#0F172A]/70 backdrop-blur-md border border-white/10 rounded-2xl p-4 shadow-lg">
          <div className="text-[11px] text-slate-400 uppercase font-semibold">Espresso Diproduksi</div>
          <div className="text-xl sm:text-2xl font-bold font-mono text-emerald-400 mt-1">
            {totalEspressoProducedL.toFixed(2)} <span className="text-xs font-normal">Liter</span>
          </div>
          <div className="text-[10px] text-slate-400 mt-0.5">{filteredProductions.length} batch batching</div>
        </div>

        {/* 5. Espresso Digunakan */}
        <div className="bg-[#0F172A]/70 backdrop-blur-md border border-white/10 rounded-2xl p-4 shadow-lg">
          <div className="text-[11px] text-slate-400 uppercase font-semibold">Espresso Digunakan</div>
          <div className="text-xl sm:text-2xl font-bold font-mono text-cyan-400 mt-1">
            {totalEspressoUsedL.toFixed(2)} <span className="text-xs font-normal">Liter</span>
          </div>
          <div className="text-[10px] text-slate-400 mt-0.5">Penjualan menu serving</div>
        </div>

        {/* 6. Waste / Susut */}
        <div className="bg-[#0F172A]/70 backdrop-blur-md border border-white/10 rounded-2xl p-4 shadow-lg">
          <div className="text-[11px] text-slate-400 uppercase font-semibold">Waste / Susut</div>
          <div className="text-xl sm:text-2xl font-bold font-mono text-rose-400 mt-1">
            {(totalWasteProdL + totalWasteLogL).toFixed(2)} <span className="text-xs font-normal">L</span>
            {totalWasteBeansKg > 0 && <span className="text-xs text-slate-400 ml-1">· {totalWasteBeansKg} kg</span>}
          </div>
          <div className="text-[10px] text-slate-400 mt-0.5">
            {totalWasteLossRp > 0 ? `Rugi: ${formatRupiah(totalWasteLossRp)}` : 'Dial-in / purging'}
          </div>
        </div>

        {/* 7. Total Pengeluaran */}
        <div className="bg-[#0F172A]/70 backdrop-blur-md border border-white/10 rounded-2xl p-4 shadow-lg">
          <div className="text-[11px] text-slate-400 uppercase font-semibold">Total Pengeluaran</div>
          <div className="text-xl sm:text-2xl font-bold font-mono text-rose-400 mt-1 truncate">
            {formatRupiah(totalExpenseAmount)}
          </div>
          <div className="text-[10px] text-slate-400 mt-0.5">{filteredExpenses.length} transaksi beban</div>
        </div>

        {/* 8. HPP Espresso Rata-rata */}
        <div className="bg-[#0F172A]/70 backdrop-blur-md border border-white/10 rounded-2xl p-4 shadow-lg">
          <div className="text-[11px] text-slate-400 uppercase font-semibold">HPP Espresso</div>
          <div className="text-xl sm:text-2xl font-bold font-mono text-emerald-400 mt-1 truncate">
            {formatRupiah(avgHpp)}<span className="text-xs font-normal text-slate-400">/L</span>
          </div>
          <div className="text-[10px] text-slate-400 mt-0.5">Biaya beans per liter</div>
        </div>
      </div>

      {/* Tabs Detail: Transaksi, Produksi, Pengeluaran, Waste */}
      <div className="bg-[#0F172A]/80 backdrop-blur-xl border border-white/10 rounded-2xl p-4 sm:p-5 space-y-4 shadow-lg">
        <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-white/10">
          <div className="flex items-center gap-1.5 p-1 bg-[#090D16] rounded-xl border border-white/10 overflow-x-auto max-w-full">
            <button
              onClick={() => setActiveDetailTab('transactions')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
                activeDetailTab === 'transactions'
                  ? 'bg-gradient-to-r from-emerald-500 to-teal-600 text-slate-950 font-bold shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Mutasi Stok ({filteredTransactions.length})
            </button>
            <button
              onClick={() => setActiveDetailTab('productions')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
                activeDetailTab === 'productions'
                  ? 'bg-gradient-to-r from-emerald-500 to-teal-600 text-slate-950 font-bold shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Produksi ({filteredProductions.length})
            </button>
            <button
              onClick={() => setActiveDetailTab('expenses')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
                activeDetailTab === 'expenses'
                  ? 'bg-gradient-to-r from-emerald-500 to-teal-600 text-slate-950 font-bold shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Pengeluaran ({filteredExpenses.length})
            </button>
            <button
              onClick={() => setActiveDetailTab('waste')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
                activeDetailTab === 'waste'
                  ? 'bg-gradient-to-r from-emerald-500 to-teal-600 text-slate-950 font-bold shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Waste ({filteredWasteLogs.length})
            </button>
          </div>

          <span className="text-[11px] text-slate-400">
            Filter: {getPeriodDescription()}
          </span>
        </div>

        {/* 1. TAB: TRANSAKSI & MUTASI */}
        {activeDetailTab === 'transactions' && (
          filteredTransactions.length === 0 ? (
            <div className="py-8 text-center text-xs text-[#8E7E72]">
              Tidak ada transaksi mutasi pada periode yang dipilih.
            </div>
          ) : (
            <div className="space-y-2 max-h-[420px] overflow-y-auto">
              {filteredTransactions.map((tx) => {
                const isIncoming = tx.type === 'IN' || tx.type === 'PRODUCTION_IN';
                return (
                  <div
                    key={tx.id}
                    className="p-3 bg-[#130F0D] border border-[#281E17] rounded-xl flex items-center justify-between"
                  >
                    <div>
                      <div className="flex items-center gap-2 text-xs">
                        <span className="font-bold text-[#E8DFD8]">{tx.item_name}</span>
                        <span aria-hidden="true" className="text-[#5E4E42]">·</span>
                        <span className="text-[#A8988B] font-mono text-[11px]">
                          {tx.type}
                        </span>
                      </div>
                      <div className="text-xs text-[#D8CCC1] mt-0.5">
                        {tx.notes || tx.type}
                      </div>
                      <div className="text-[10px] text-[#736356] mt-0.5">
                        {new Date(tx.created_at).toLocaleString('id-ID')} · Oleh: {tx.created_by}
                      </div>
                    </div>

                    <div className="text-right">
                      <div
                        className={`text-xs font-mono font-bold ${
                          isIncoming ? 'text-emerald-400' : 'text-amber-400'
                        }`}
                      >
                        {isIncoming ? '+' : '-'}{tx.quantity}
                      </div>
                      <div className="text-[10px] text-[#78695C]">
                        {tx.previous_stock} &rarr; {tx.new_stock}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )
        )}

        {/* 2. TAB: PRODUKSI ESPRESSO */}
        {activeDetailTab === 'productions' && (
          filteredProductions.length === 0 ? (
            <div className="py-8 text-center text-xs text-[#8E7E72]">
              Tidak ada catatan produksi pada periode yang dipilih.
            </div>
          ) : (
            <div className="space-y-2 max-h-[420px] overflow-y-auto">
              {filteredProductions.map((prod) => (
                <div
                  key={prod.id}
                  className="p-3 bg-[#130F0D] border border-[#281E17] rounded-xl flex items-center justify-between"
                >
                  <div>
                    <div className="text-xs font-bold text-[#E8DFD8]">
                      {prod.beans_item_name}
                    </div>
                    <div className="text-xs text-[#A8988B] mt-0.5">
                      Beans terpakai: <span className="font-mono text-amber-400">{prod.beans_used_kg} kg</span> · Rasio: 1:{prod.conversion_ratio}
                    </div>
                    <div className="text-[10px] text-[#736356] mt-0.5">
                      {new Date(prod.created_at).toLocaleString('id-ID')} · Barista: {prod.operator_name}
                    </div>
                  </div>

                  <div className="text-right">
                    <div className="text-xs font-mono font-bold text-emerald-400">
                      +{prod.espresso_produced_liter} L Espresso
                    </div>
                    <div className="text-[11px] text-[#C5A059]">
                      HPP: {formatRupiah(prod.hpp_per_liter || 0)}/L
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )
        )}

        {/* 3. TAB: PENGELUARAN */}
        {activeDetailTab === 'expenses' && (
          filteredExpenses.length === 0 ? (
            <div className="py-8 text-center text-xs text-[#8E7E72]">
              Tidak ada pengeluaran operasional pada periode yang dipilih.
            </div>
          ) : (
            <div className="space-y-2 max-h-[420px] overflow-y-auto">
              {filteredExpenses.map((exp) => (
                <div
                  key={exp.id}
                  className="p-3 bg-[#130F0D] border border-[#281E17] rounded-xl flex items-center justify-between"
                >
                  <div>
                    <div className="flex items-center gap-2 text-xs">
                      <span className="font-bold text-[#E8DFD8]">{exp.description}</span>
                      <span aria-hidden="true" className="text-[#5E4E42]">·</span>
                      <span className="text-[#C5A059] font-medium text-[11px]">
                        {exp.category}
                      </span>
                    </div>
                    <div className="text-[10px] text-[#736356] mt-0.5">
                      {new Date(exp.expense_date).toLocaleDateString('id-ID')} · Dicatat oleh: {exp.recorded_by}
                    </div>
                  </div>

                  <div className="text-right font-mono font-bold text-xs text-red-400">
                    {formatRupiah(exp.amount)}
                  </div>
                </div>
              ))}
            </div>
          )
        )}

        {/* 4. TAB: WASTE / SUSUT */}
        {activeDetailTab === 'waste' && (
          filteredWasteLogs.length === 0 ? (
            <div className="py-8 text-center text-xs text-[#8E7E72]">
              Tidak ada catatan waste / susut pada periode yang dipilih.
            </div>
          ) : (
            <div className="space-y-2 max-h-[420px] overflow-y-auto">
              {filteredWasteLogs.map((waste) => (
                <div
                  key={waste.id}
                  className="p-3 bg-[#130F0D] border border-[#281E17] rounded-xl flex items-center justify-between"
                >
                  <div>
                    <div className="text-xs font-bold text-[#E8DFD8]">
                      {waste.item_name}
                    </div>
                    <div className="text-xs text-red-300 mt-0.5">
                      Alasan: {waste.reason}
                    </div>
                    <div className="text-[10px] text-[#736356] mt-0.5">
                      {new Date(waste.created_at).toLocaleString('id-ID')} · Operator: {waste.operator_name}
                    </div>
                  </div>

                  <div className="text-right">
                    <div className="text-xs font-mono font-bold text-red-400">
                      -{waste.quantity} {waste.unit}
                    </div>
                    {waste.cost_loss ? (
                      <div className="text-[10px] text-[#736356]">
                        Rugi: {formatRupiah(waste.cost_loss)}
                      </div>
                    ) : null}
                  </div>
                </div>
              ))}
            </div>
          )
        )}
      </div>
    </div>
  );
};
