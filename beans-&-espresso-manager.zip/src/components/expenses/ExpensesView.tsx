import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { db, subscribeToDBUpdates } from '../../services/database';
import { Expense, ExpenseCategory } from '../../types';
import { 
  ReceiptText, 
  Plus, 
  Calendar, 
  Filter, 
  CheckCircle2, 
  AlertCircle,
  Tag,
  Clock,
  ArrowDownRight,
  TrendingDown,
  X
} from 'lucide-react';

const EXPENSE_CATEGORIES: ExpenseCategory[] = [
  'Beans',
  'Bahan Baku',
  'Packaging',
  'Operasional',
  'Listrik',
  'Air',
  'Transportasi',
  'Gaji',
  'Lainnya'
];

export const ExpensesView: React.FC = () => {
  const { currentShop, currentUser } = useAuth();
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [loading, setLoading] = useState(true);

  // Filter state
  const [filterPeriod, setFilterPeriod] = useState<'today' | 'week' | 'month' | 'all'>('month');
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');

  // Modal / Form state
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [amount, setAmount] = useState('');
  const [category, setCategory] = useState<ExpenseCategory>('Beans');
  const [description, setDescription] = useState('');
  const [expenseDate, setExpenseDate] = useState(new Date().toISOString().split('T')[0]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);
  const [successToast, setSuccessToast] = useState<string | null>(null);

  const loadExpenses = async () => {
    if (!currentShop) return;
    try {
      const data = await db.getExpenses(currentShop.id, 100);
      setExpenses(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadExpenses();
    const unsub = subscribeToDBUpdates(() => {
      loadExpenses();
    });
    return () => unsub();
  }, [currentShop?.id]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentShop || !currentUser) return;

    setFormError(null);
    const numAmount = parseFloat(amount.replace(/[^0-9]/g, ''));
    if (isNaN(numAmount) || numAmount <= 0) {
      setFormError('Masukkan nominal pengeluaran yang valid.');
      return;
    }

    if (!description.trim()) {
      setFormError('Harap tuliskan keterangan pengeluaran.');
      return;
    }

    try {
      setIsSubmitting(true);
      await db.recordExpense({
        shop_id: currentShop.id,
        category,
        amount: numAmount,
        description: description.trim(),
        expense_date: new Date(expenseDate).toISOString(),
        user: { id: currentUser.id, name: currentUser.name }
      });

      setSuccessToast(`Pengeluaran sebesar ${formatRupiah(numAmount)} berhasil dicatat!`);
      setTimeout(() => setSuccessToast(null), 4000);

      // Reset form
      setAmount('');
      setDescription('');
      setIsModalOpen(false);
      await loadExpenses();
    } catch (err: any) {
      setFormError(err?.message || 'Gagal menyimpan pengeluaran.');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Filter calculations
  const now = new Date();
  const todayStr = now.toISOString().split('T')[0];
  const oneWeekAgo = new Date(now.getTime() - 7 * 86400000);
  const oneMonthAgo = new Date(now.getTime() - 30 * 86400000);

  const filteredExpenses = expenses.filter((exp) => {
    const expDate = new Date(exp.expense_date);

    if (filterPeriod === 'today') {
      if (!exp.expense_date.startsWith(todayStr)) return false;
    } else if (filterPeriod === 'week') {
      if (expDate < oneWeekAgo) return false;
    } else if (filterPeriod === 'month') {
      if (expDate < oneMonthAgo) return false;
    }

    if (selectedCategory !== 'ALL' && exp.category !== selectedCategory) {
      return false;
    }

    return true;
  });

  const totalFilteredAmount = filteredExpenses.reduce((sum, e) => sum + Number(e.amount), 0);

  const formatRupiah = (val: number) => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      maximumFractionDigits: 0
    }).format(val);
  };

  return (
    <div className="space-y-4 pb-20">
      {/* Top Banner & Quick Record */}
      <div className="bg-[#0F172A]/80 backdrop-blur-xl border border-white/10 rounded-2xl p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-lg">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-rose-400 mb-1">
            <ReceiptText className="w-4 h-4" />
            <span>Pengeluaran Operasional Toko</span>
          </div>
          <h2 className="text-lg sm:text-xl font-bold text-slate-100">
            Catat Pengeluaran Tanpa Tunggu Persetujuan
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Staff produksi & Owner dapat mencatat langsung beban harian (es batu, susu darurat, packaging, dll).
          </p>
        </div>

        <button
          onClick={() => setIsModalOpen(true)}
          className="min-h-[44px] flex items-center justify-center gap-2 px-4 py-2.5 bg-gradient-to-r from-emerald-500 to-teal-600 text-slate-950 font-bold text-xs sm:text-sm rounded-xl hover:brightness-110 active:scale-95 transition-all shadow-md shadow-emerald-500/20 shrink-0 cursor-pointer"
        >
          <Plus className="w-4 h-4 stroke-[3]" />
          <span>Catat Pengeluaran</span>
        </button>
      </div>

      {successToast && (
        <div className="p-3 bg-emerald-950/70 border border-emerald-800 text-emerald-300 rounded-xl text-xs flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{successToast}</span>
        </div>
      )}

      {/* Expense Summary KPI & Filter Tabs */}
      <div className="bg-[#0F172A]/80 backdrop-blur-xl border border-white/10 rounded-2xl p-4 space-y-4 shadow-lg">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-white/10">
          <div>
            <div className="text-xs text-slate-400">
              Total Beban ({filterPeriod === 'today' ? 'Hari Ini' : filterPeriod === 'week' ? '7 Hari Terakhir' : filterPeriod === 'month' ? '30 Hari Terakhir' : 'Semua Periode'})
            </div>
            <div className="text-2xl sm:text-3xl font-bold font-mono tabular-nums text-rose-400 mt-0.5">
              {formatRupiah(totalFilteredAmount)}
            </div>
          </div>

          {/* Period selector */}
          <div className="flex items-center gap-1 bg-[#090D16] p-1 rounded-xl border border-white/10">
            <button
              onClick={() => setFilterPeriod('today')}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors cursor-pointer ${
                filterPeriod === 'today'
                  ? 'bg-gradient-to-r from-emerald-500 to-teal-600 text-slate-950 font-bold shadow-sm'
                  : 'text-slate-400 hover:text-slate-100'
              }`}
            >
              Hari Ini
            </button>
            <button
              onClick={() => setFilterPeriod('week')}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors cursor-pointer ${
                filterPeriod === 'week'
                  ? 'bg-gradient-to-r from-emerald-500 to-teal-600 text-slate-950 font-bold shadow-sm'
                  : 'text-slate-400 hover:text-slate-100'
              }`}
            >
              7 Hari
            </button>
            <button
              onClick={() => setFilterPeriod('month')}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors cursor-pointer ${
                filterPeriod === 'month'
                  ? 'bg-gradient-to-r from-emerald-500 to-teal-600 text-slate-950 font-bold shadow-sm'
                  : 'text-slate-400 hover:text-slate-100'
              }`}
            >
              Bulan Ini
            </button>
            <button
              onClick={() => setFilterPeriod('all')}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors cursor-pointer ${
                filterPeriod === 'all'
                  ? 'bg-gradient-to-r from-emerald-500 to-teal-600 text-slate-950 font-bold shadow-sm'
                  : 'text-slate-400 hover:text-slate-100'
              }`}
            >
              Semua
            </button>
          </div>
        </div>

        {/* Category filter pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs scrollbar-none">
          <button
            onClick={() => setSelectedCategory('ALL')}
            className={`px-3 py-1.5 rounded-lg font-medium whitespace-nowrap min-h-[36px] ${
              selectedCategory === 'ALL'
                ? 'bg-[#2E231A] text-[#C5A059] border border-[#443325]'
                : 'bg-[#15100E] text-[#7F7063] hover:text-[#E8DFD8]'
            }`}
          >
            Semua Kategori
          </button>
          {EXPENSE_CATEGORIES.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1.5 rounded-xl font-medium whitespace-nowrap min-h-[36px] transition-all cursor-pointer ${
                selectedCategory === cat
                  ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 shadow-sm'
                  : 'bg-white/[0.04] text-slate-400 hover:text-slate-200 border border-white/5'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Expenses Feed */}
      {filteredExpenses.length === 0 ? (
        <div className="bg-[#0F172A]/80 backdrop-blur-xl border border-white/10 rounded-2xl p-8 text-center text-slate-400 shadow-lg">
          <ReceiptText className="w-10 h-10 mx-auto text-slate-600 mb-2" />
          <p className="text-sm">Belum ada pengeluaran pada periode atau kategori ini.</p>
        </div>
      ) : (
        <div className="space-y-2.5">
          {filteredExpenses.map((exp) => (
            <div
              key={exp.id}
              className="p-3.5 sm:p-4 rounded-xl bg-[#0F172A]/80 backdrop-blur-xl border border-white/10 flex items-center justify-between gap-3 shadow-md hover:border-emerald-500/30 transition-all"
            >
              <div className="overflow-hidden">
                <div className="flex items-center gap-2">
                  <span className="text-[11px] font-semibold text-rose-400">{exp.category}</span>
                  <span className="text-[10px] text-slate-400 font-mono">
                    · {new Date(exp.expense_date).toLocaleDateString('id-ID', { day: 'numeric', month: 'short', year: 'numeric' })}
                  </span>
                </div>
                <h4 className="text-sm font-semibold text-slate-100 mt-0.5 truncate">
                  {exp.description}
                </h4>
                <div className="text-[11px] text-slate-400 mt-0.5">
                  Dicatat oleh: <strong className="text-slate-200">{exp.recorded_by}</strong>
                </div>
              </div>

              <div className="text-right shrink-0">
                <div className="text-base sm:text-lg font-bold font-mono text-rose-400">
                  {formatRupiah(exp.amount)}
                </div>
                <div className="text-[10px] text-emerald-400 font-medium">Langsung Aktif</div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* MODAL: Form Catat Pengeluaran */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-[#0F172A]/95 border border-white/10 rounded-3xl w-full max-w-md p-5 sm:p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <div>
                <h3 className="text-base font-bold text-slate-100">Catat Pengeluaran Baru</h3>
                <p className="text-xs text-slate-400 mt-0.5">Langsung tersimpan tanpa approval</p>
              </div>
              <button
                onClick={() => setIsModalOpen(false)}
                className="text-slate-400 hover:text-slate-100 p-1.5 rounded-lg cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-3.5">
              {formError && (
                <div className="p-3 text-xs bg-rose-500/10 border border-rose-500/30 text-rose-300 rounded-xl">
                  {formError}
                </div>
              )}

              {/* Nominal (Rp) */}
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Nominal Pengeluaran (Rp) *
                </label>
                <input
                  type="number"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  placeholder="Contoh: 75000"
                  className="w-full px-3 py-2.5 bg-[#090D16] border border-white/10 rounded-xl text-base font-mono text-slate-100 focus:outline-none focus:border-emerald-500"
                  required
                  autoFocus
                />
              </div>

              {/* Kategori */}
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Kategori Pengeluaran *
                </label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value as ExpenseCategory)}
                  className="w-full px-3 py-2 bg-[#090D16] border border-white/10 rounded-xl text-sm text-slate-100 focus:outline-none focus:border-emerald-500"
                >
                  {EXPENSE_CATEGORIES.map((cat) => (
                    <option key={cat} value={cat} className="bg-[#0F172A] text-slate-100">{cat}</option>
                  ))}
                </select>
              </div>

              {/* Tanggal */}
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Tanggal Pengeluaran
                </label>
                <input
                  type="date"
                  value={expenseDate}
                  onChange={(e) => setExpenseDate(e.target.value)}
                  className="w-full px-3 py-2 bg-[#090D16] border border-white/10 rounded-xl text-sm text-slate-100 focus:outline-none focus:border-emerald-500"
                />
              </div>

              {/* Keterangan */}
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Keterangan / Rincian Belanja *
                </label>
                <textarea
                  rows={2}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Contoh: Beli 2 bal es batu kristal + 1 galon air di agen langganan"
                  className="w-full px-3 py-2 bg-[#090D16] border border-white/10 rounded-xl text-sm text-slate-100 focus:outline-none focus:border-emerald-500"
                  required
                />
              </div>

              {/* Pencatat */}
              <div className="p-2.5 bg-[#090D16] rounded-xl border border-white/10 text-xs text-slate-400 flex items-center justify-between">
                <span>Dicatat Oleh:</span>
                <span className="font-semibold text-slate-200">{currentUser?.name} ({currentUser?.role})</span>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-white/10">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs font-medium text-slate-400 hover:bg-white/[0.05] cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 text-slate-950 text-xs font-bold hover:brightness-110 active:scale-95 transition-all shadow-md shadow-emerald-500/20 cursor-pointer"
                >
                  {isSubmitting ? 'Menyimpan...' : 'Simpan Pengeluaran'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
