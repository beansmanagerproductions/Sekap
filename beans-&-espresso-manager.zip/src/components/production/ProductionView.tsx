import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { db, subscribeToDBUpdates } from '../../services/database';
import { InventoryItem, ProductionLog, EspressoUsageLog, WasteLog } from '../../types';
import { 
  Coffee, 
  Layers, 
  Sparkles, 
  CheckCircle2, 
  Clock, 
  AlertCircle,
  Calculator,
  User,
  History,
  Trash2,
  TrendingDown,
  ArrowRight,
  Flame,
  MinusCircle
} from 'lucide-react';

export const ProductionView: React.FC = () => {
  const { currentShop, currentUser, isStaff, isOwner, isMaster } = useAuth();
  const [beansList, setBeansList] = useState<InventoryItem[]>([]);
  const [espressoItems, setEspressoItems] = useState<InventoryItem[]>([]);
  const [productionHistory, setProductionHistory] = useState<ProductionLog[]>([]);
  const [usageHistory, setUsageHistory] = useState<EspressoUsageLog[]>([]);
  const [wasteHistory, setWasteHistory] = useState<WasteLog[]>([]);
  const [loading, setLoading] = useState(true);

  // Sub-tab inside Production view
  const [activeSubTab, setActiveSubTab] = useState<'produce' | 'usage' | 'waste'>('produce');

  // FORM 1: PRODUKSI BEANS -> ESPRESSO (Prompt 2: Staff memasukkan ESPRESSO AKTUAL)
  const [selectedBeansId, setSelectedBeansId] = useState('');
  const [espressoProducedLiter, setEspressoProducedLiter] = useState<string>('3.0');
  const [selectedEspressoId, setSelectedEspressoId] = useState('');
  const [prodWasteLiter, setProdWasteLiter] = useState<string>('0');
  const [batchNotes, setBatchNotes] = useState('');
  const [isSubmittingProd, setIsSubmittingProd] = useState(false);
  const [prodSuccessMsg, setProdSuccessMsg] = useState<string | null>(null);
  const [prodErrorMsg, setProdErrorMsg] = useState<string | null>(null);

  // FORM 2: PEMAKAIAN ESPRESSO (Prompt 2: Staff mencatat pemakaian espresso)
  const [usageEspressoId, setUsageEspressoId] = useState('');
  const [usageAmountLiter, setUsageAmountLiter] = useState<string>('0.5');
  const [usageType, setUsageType] = useState<'SERVING' | 'WASTE'>('SERVING');
  const [usageNotes, setUsageNotes] = useState('');
  const [isSubmittingUsage, setIsSubmittingUsage] = useState(false);
  const [usageSuccessMsg, setUsageSuccessMsg] = useState<string | null>(null);
  const [usageErrorMsg, setUsageErrorMsg] = useState<string | null>(null);

  // FORM 3: WASTE / SUSUT TERPISAH
  const [wasteItemType, setWasteItemType] = useState<'BEANS' | 'ESPRESSO'>('BEANS');
  const [wasteItemId, setWasteItemId] = useState('');
  const [wasteQty, setWasteQty] = useState('');
  const [wasteReason, setWasteReason] = useState('');
  const [isSubmittingWaste, setIsSubmittingWaste] = useState(false);
  const [wasteSuccessMsg, setWasteSuccessMsg] = useState<string | null>(null);
  const [wasteErrorMsg, setWasteErrorMsg] = useState<string | null>(null);

  // Current active conversion ratio from shop (default 3.0)
  const conversionRatio = currentShop?.conversion_ratio || 3.0;

  const loadData = async () => {
    if (!currentShop) return;
    try {
      const [inventory, prods, usages, wastes] = await Promise.all([
        db.getInventory(currentShop.id),
        db.getProductions(currentShop.id, 50),
        db.getEspressoUsages(currentShop.id, 50),
        db.getWasteLogs(currentShop.id, 50)
      ]);

      const beans = inventory.filter((i) => i.category === 'Coffee Beans');
      const espressos = inventory.filter((i) => i.category === 'Espresso Base');

      setBeansList(beans);
      setEspressoItems(espressos);
      setProductionHistory(prods);
      setUsageHistory(usages);
      setWasteHistory(wastes);

      if (beans.length > 0 && !selectedBeansId) {
        setSelectedBeansId(beans[0].id);
      }
      if (espressos.length > 0 && !selectedEspressoId) {
        setSelectedEspressoId(espressos[0].id);
      }
      if (espressos.length > 0 && !usageEspressoId) {
        setUsageEspressoId(espressos[0].id);
      }
    } catch (err) {
      console.error('Error loading production data:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
    const unsub = subscribeToDBUpdates(() => {
      loadData();
    });
    return () => unsub();
  }, [currentShop?.id]);

  // Selected beans details
  const selectedBeansItem = beansList.find((b) => b.id === selectedBeansId);
  const espressoLiterNum = parseFloat(espressoProducedLiter) || 0;

  // Formula Prompt 2:
  // Beans terpakai = Espresso diproduksi ÷ Rasio (default ÷ 3)
  // Contoh: 1,5 L -> 0,5 KG Beans; 2,8 L -> 0,933 KG Beans
  const calculatedBeansUsedKg = conversionRatio > 0 
    ? Math.round((espressoLiterNum / conversionRatio) * 1000) / 1000 
    : 0;

  // HPP Calculation:
  // Contoh: 1 KG Beans = Rp180.000, 1 KG = 3 L Espresso -> HPP Beans = Rp60.000/L
  const costPerKg = Number(selectedBeansItem?.cost_price) || 0;
  const hppPerLiter = conversionRatio > 0 ? Math.round(costPerKg / conversionRatio) : 0;
  const totalCostBatch = Math.round(calculatedBeansUsedKg * costPerKg);

  // Check if stock is sufficient
  const availableBeansStock = Number(selectedBeansItem?.current_stock) || 0;
  const isStockInsufficient = availableBeansStock < calculatedBeansUsedKg;

  // Handle Submit Production
  const handleSubmitProduction = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentShop || !currentUser) return;

    setProdErrorMsg(null);
    setProdSuccessMsg(null);

    if (!selectedBeansId) {
      setProdErrorMsg('Pilih biji kopi (Coffee Beans) yang digunakan.');
      return;
    }

    if (espressoLiterNum <= 0) {
      setProdErrorMsg('Jumlah Espresso aktual harus lebih dari 0 Liter.');
      return;
    }

    if (isStockInsufficient) {
      setProdErrorMsg(
        `Stok Beans tidak mencukupi! Tersedia: ${availableBeansStock} kg, dibutuhkan: ${calculatedBeansUsedKg} kg. Stok tidak boleh bernilai negatif.`
      );
      return;
    }

    try {
      setIsSubmittingProd(true);
      const wasteNum = parseFloat(prodWasteLiter) || 0;

      await db.recordProduction({
        shop_id: currentShop.id,
        beans_item_id: selectedBeansId,
        espresso_produced_liter: espressoLiterNum,
        espresso_item_id: selectedEspressoId || undefined,
        conversion_ratio: conversionRatio,
        waste_liter: wasteNum > 0 ? wasteNum : undefined,
        batch_notes: batchNotes.trim(),
        user: { id: currentUser.id, name: currentUser.name }
      });

      setProdSuccessMsg(
        `Produksi berhasil disimpan! Stok Espresso bertambah +${espressoLiterNum} Liter dan stok ${selectedBeansItem?.name} otomatis berkurang -${calculatedBeansUsedKg} kg. HPP: Rp${hppPerLiter.toLocaleString('id-ID')}/L.`
      );
      setBatchNotes('');
      setProdWasteLiter('0');
      await loadData();
    } catch (err: any) {
      setProdErrorMsg(err?.message || 'Gagal memproses produksi.');
    } finally {
      setIsSubmittingProd(false);
    }
  };

  // Handle Submit Espresso Usage
  const handleSubmitUsage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentShop || !currentUser) return;

    setUsageErrorMsg(null);
    setUsageSuccessMsg(null);

    const targetEspresso = espressoItems.find((e) => e.id === usageEspressoId) || espressoItems[0];
    if (!targetEspresso) {
      setUsageErrorMsg('Pilih item Espresso terlebih dahulu.');
      return;
    }

    const amount = parseFloat(usageAmountLiter) || 0;
    if (amount <= 0) {
      setUsageErrorMsg('Jumlah pemakaian harus lebih dari 0 Liter.');
      return;
    }

    if (targetEspresso.current_stock < amount) {
      setUsageErrorMsg(
        `Stok Espresso tidak cukup! Sisa stok: ${targetEspresso.current_stock} L, diminta: ${amount} L. Stok tidak boleh negatif.`
      );
      return;
    }

    try {
      setIsSubmittingUsage(true);
      await db.recordEspressoUsage({
        shop_id: currentShop.id,
        espresso_item_id: targetEspresso.id,
        amount_liter: amount,
        usage_type: usageType,
        notes: usageNotes.trim(),
        user: { id: currentUser.id, name: currentUser.name }
      });

      setUsageSuccessMsg(`Pemakaian ${amount} Liter Espresso berhasil dicatat! Sisa stok espresso otomatis berkurang.`);
      setUsageNotes('');
      await loadData();
    } catch (err: any) {
      setUsageErrorMsg(err?.message || 'Gagal mencatat pemakaian.');
    } finally {
      setIsSubmittingUsage(false);
    }
  };

  // Handle Submit Waste Log
  const handleSubmitWaste = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentShop || !currentUser) return;

    setWasteErrorMsg(null);
    setWasteSuccessMsg(null);

    const targetItem = wasteItemType === 'BEANS'
      ? beansList.find((b) => b.id === wasteItemId) || beansList[0]
      : espressoItems.find((es) => es.id === wasteItemId) || espressoItems[0];

    if (!targetItem) {
      setWasteErrorMsg('Pilih item bahan yang mengalami waste.');
      return;
    }

    const qty = parseFloat(wasteQty) || 0;
    if (qty <= 0) {
      setWasteErrorMsg('Jumlah waste harus lebih dari 0.');
      return;
    }

    if (targetItem.current_stock < qty) {
      setWasteErrorMsg(`Stok ${targetItem.name} tidak cukup (${targetItem.current_stock} ${targetItem.unit}) untuk dicatat waste sebesar ${qty} ${targetItem.unit}.`);
      return;
    }

    if (!wasteReason.trim()) {
      setWasteErrorMsg('Harap berikan alasan / penyebab waste.');
      return;
    }

    try {
      setIsSubmittingWaste(true);
      await db.recordWaste({
        shop_id: currentShop.id,
        item_type: wasteItemType,
        item_id: targetItem.id,
        quantity: qty,
        reason: wasteReason.trim(),
        user: { id: currentUser.id, name: currentUser.name }
      });

      setWasteSuccessMsg(`Waste ${qty} ${targetItem.unit} ${targetItem.name} berhasil dicatat.`);
      setWasteQty('');
      setWasteReason('');
      await loadData();
    } catch (err: any) {
      setWasteErrorMsg(err?.message || 'Gagal mencatat waste.');
    } finally {
      setIsSubmittingWaste(false);
    }
  };

  const formatRupiah = (val: number) => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      maximumFractionDigits: 0
    }).format(val);
  };

  return (
    <div className="space-y-6 pb-20">
      {/* Header Banner */}
      <div className="bg-[#0F172A]/80 backdrop-blur-xl border border-white/10 rounded-2xl p-4 sm:p-5 shadow-lg">
        <div className="flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-emerald-400 mb-1">
              <Coffee className="w-4 h-4" />
              <span>Operasional Espresso Bar</span>
            </div>
            <h2 className="text-lg sm:text-xl font-bold text-slate-100">
              Produksi & Pemakaian Espresso
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Rasio aktif: <strong className="text-emerald-400 font-mono">1 KG Beans = {conversionRatio} Liter Espresso</strong>. Staff memasukkan hasil Espresso aktual, sistem menghitung Beans dan HPP otomatis.
            </p>
          </div>

          <div className="hidden sm:block text-right">
            <div className="text-xs text-slate-400">Standar Rasio</div>
            <div className="text-sm font-bold font-mono text-emerald-400">1 kg : {conversionRatio} L</div>
          </div>
        </div>

        {/* Sub Navigation Segmented Tabs */}
        <div className="flex items-center gap-2 mt-4 pt-3 border-t border-white/10 overflow-x-auto">
          <button
            onClick={() => setActiveSubTab('produce')}
            className={`min-h-[40px] px-4 py-1.5 rounded-xl text-xs font-bold transition-all shrink-0 ${
              activeSubTab === 'produce'
                ? 'bg-gradient-to-r from-emerald-500 to-teal-600 text-slate-950 shadow-md shadow-emerald-500/20'
                : 'bg-white/[0.04] text-slate-400 hover:text-slate-100 border border-white/10'
            }`}
          >
            1. Catat Produksi (Beans &rarr; Espresso)
          </button>
          <button
            onClick={() => setActiveSubTab('usage')}
            className={`min-h-[40px] px-4 py-1.5 rounded-xl text-xs font-bold transition-all shrink-0 ${
              activeSubTab === 'usage'
                ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-slate-950 shadow-md shadow-cyan-500/20'
                : 'bg-white/[0.04] text-slate-400 hover:text-slate-100 border border-white/10'
            }`}
          >
            2. Pemakaian Espresso ({usageHistory.length})
          </button>
          <button
            onClick={() => setActiveSubTab('waste')}
            className={`min-h-[40px] px-4 py-1.5 rounded-xl text-xs font-bold transition-all shrink-0 ${
              activeSubTab === 'waste'
                ? 'bg-gradient-to-r from-rose-500 to-red-600 text-slate-950 shadow-md shadow-rose-500/20'
                : 'bg-white/[0.04] text-slate-400 hover:text-slate-100 border border-white/10'
            }`}
          >
            3. Waste / Susut ({wasteHistory.length})
          </button>
        </div>
      </div>

      {/* =========================================================================
          SUB-TAB 1: PRODUKSI BEANS -> ESPRESSO (Prompt 2 Formula)
      ========================================================================= */}
      {activeSubTab === 'produce' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Form (7 cols) */}
          <div className="lg:col-span-7 bg-[#0F172A]/80 backdrop-blur-xl border border-white/10 rounded-2xl p-5 shadow-xl">
            <h3 className="text-sm font-bold text-slate-100 mb-3 flex items-center gap-2">
              <Calculator className="w-4 h-4 text-emerald-400" />
              <span>Input Hasil Espresso Aktual</span>
            </h3>

            {prodSuccessMsg && (
              <div className="mb-4 p-3 bg-emerald-950/70 border border-emerald-800 text-emerald-300 rounded-xl text-xs flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>{prodSuccessMsg}</span>
              </div>
            )}

            {prodErrorMsg && (
              <div className="mb-4 p-3 bg-red-950/70 border border-red-800 text-red-300 rounded-xl text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
                <span>{prodErrorMsg}</span>
              </div>
            )}

            <form onSubmit={handleSubmitProduction} className="space-y-4">
              {/* 1. Pilih Biji Kopi */}
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">
                  Biji Kopi (Coffee Beans) yang Digiling *
                </label>
                {beansList.length === 0 ? (
                  <div className="p-3 bg-amber-950/30 border border-amber-800/40 rounded-xl text-xs text-amber-300">
                    Belum ada stok biji kopi terdaftar. Silakan tambahkan di menu Stok.
                  </div>
                ) : (
                  <select
                    value={selectedBeansId}
                    onChange={(e) => setSelectedBeansId(e.target.value)}
                    className="w-full px-3 py-2.5 bg-[#090D16] border border-white/10 rounded-xl text-sm text-slate-100 focus:outline-none focus:border-emerald-500"
                    required
                  >
                    {beansList.map((beans) => (
                      <option key={beans.id} value={beans.id} className="bg-[#0F172A] text-slate-100">
                        {beans.name} (Stok: {beans.current_stock} {beans.unit} · Rp{Number(beans.cost_price).toLocaleString('id-ID')}/kg)
                      </option>
                    ))}
                  </select>
                )}
                {selectedBeansItem && (
                  <div className="mt-1 flex items-center justify-between text-[11px] text-slate-400">
                    <span>
                      Sisa stok: <strong className={`font-mono ${availableBeansStock <= selectedBeansItem.min_stock ? 'text-amber-400' : 'text-slate-100'}`}>{availableBeansStock} kg</strong>
                    </span>
                    <span>Harga beli: <strong className="text-emerald-400 font-mono">{formatRupiah(selectedBeansItem.cost_price)}/kg</strong></span>
                  </div>
                )}
              </div>

              {/* 2. INPUT ESPRESSO AKTUAL (PROMPT 2 CORE) */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-xs font-medium text-slate-300">
                    Jumlah ESPRESSO AKTUAL yang Dihasilkan (Liter) *
                  </label>
                  {/* Quick Preset Buttons */}
                  <div className="flex items-center gap-1">
                    {[1.5, 2.0, 2.8, 3.0, 4.5].map((preset) => (
                      <button
                        key={preset}
                        type="button"
                        onClick={() => setEspressoProducedLiter(preset.toString())}
                        className={`px-2 py-0.5 rounded text-[10px] font-medium transition-colors ${
                          espressoLiterNum === preset
                            ? 'bg-emerald-500 text-slate-950 font-bold'
                            : 'bg-white/[0.05] text-slate-400 hover:text-slate-100 border border-white/5'
                        }`}
                      >
                        {preset} L
                      </button>
                    ))}
                  </div>
                </div>

                <div className="relative">
                  <input
                    type="number"
                    step="0.05"
                    min="0.1"
                    value={espressoProducedLiter}
                    onChange={(e) => setEspressoProducedLiter(e.target.value)}
                    placeholder="Contoh: 1.5 atau 2.8"
                    className="w-full pl-3 pr-14 py-2.5 bg-[#090D16] border border-white/10 rounded-xl text-base font-mono text-slate-100 focus:outline-none focus:border-emerald-500"
                    required
                  />
                  <div className="absolute right-3 top-1/2 -translate-y-1/2 text-xs font-bold text-emerald-400 pointer-events-none">
                    Liter
                  </div>
                </div>
                <p className="text-[10px] text-slate-400 mt-1">
                  Staff cukup memasukkan Espresso aktual. Sistem otomatis menghitung kebutuhan biji kopi.
                </p>
              </div>

              {/* 3. Target Espresso Storage */}
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">
                  Simpan ke Wadah / Item Inventaris Espresso
                </label>
                <select
                  value={selectedEspressoId}
                  onChange={(e) => setSelectedEspressoId(e.target.value)}
                  className="w-full px-3 py-2 bg-[#090D16] border border-white/10 rounded-xl text-sm text-slate-100 focus:outline-none focus:border-emerald-500"
                >
                  {espressoItems.map((esp) => (
                    <option key={esp.id} value={esp.id} className="bg-[#0F172A] text-slate-100">
                      {esp.name} (Stok Saat Ini: {esp.current_stock} {esp.unit})
                    </option>
                  ))}
                  {espressoItems.length === 0 && (
                    <option value="" className="bg-[#0F172A] text-slate-100">Espresso Base Concentrate (Otomatis dibuat)</option>
                  )}
                </select>
              </div>

              {/* 4. Susut / Waste Ekstraksi (Opsional) */}
              <div>
                <label className="block text-xs font-medium text-[#C8BCB3] mb-1.5">
                  Susut / Waste Ekstraksi (Liter) - Dial-in / Ampas / Tumpah
                </label>
                <input
                  type="number"
                  step="0.01"
                  min="0"
                  value={prodWasteLiter}
                  onChange={(e) => setProdWasteLiter(e.target.value)}
                  placeholder="0 (jika tidak ada)"
                  className="w-full px-3 py-2 bg-[#090D16] border border-white/10 rounded-xl text-sm font-mono text-slate-100 focus:outline-none focus:border-emerald-500"
                />
              </div>

              {/* 5. Catatan Batch */}
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">
                  Catatan Batch / Shift (Opsional)
                </label>
                <input
                  type="text"
                  value={batchNotes}
                  onChange={(e) => setBatchNotes(e.target.value)}
                  placeholder="Contoh: Batch Pagi - Ekstraksi 28 detik, crema tebal"
                  className="w-full px-3 py-2 bg-[#090D16] border border-white/10 rounded-xl text-sm text-slate-100 focus:outline-none focus:border-emerald-500"
                />
              </div>

              {/* Submit CTA */}
              <button
                type="submit"
                disabled={isSubmittingProd || isStockInsufficient || espressoLiterNum <= 0}
                className="w-full min-h-[48px] flex items-center justify-center gap-2 px-4 py-3 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 text-slate-950 font-bold text-sm shadow-lg shadow-emerald-500/20 hover:brightness-110 active:scale-[0.98] transition-all disabled:opacity-50 cursor-pointer"
              >
                {isSubmittingProd ? (
                  <span>Menyimpan ke Supabase...</span>
                ) : (
                  <>
                    <Coffee className="w-4 h-4" />
                    <span>
                      Simpan Produksi ({espressoLiterNum} L Espresso &rarr; -{calculatedBeansUsedKg} kg Beans)
                    </span>
                  </>
                )}
              </button>

              {isStockInsufficient && (
                <div className="p-2.5 bg-rose-950/40 border border-rose-900/60 rounded-xl text-[11px] text-rose-300 text-center">
                  ⚠️ Stok Beans tidak mencukupi untuk batch ini. Jangan izinkan stok Beans negatif.
                </div>
              )}
            </form>
          </div>

          {/* Right Live Engine & HPP Preview (5 cols) */}
          <div className="lg:col-span-5 space-y-4">
            <div className="bg-[#0F172A]/80 backdrop-blur-xl border border-white/10 rounded-2xl p-5 shadow-lg space-y-4">
              <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-400 uppercase tracking-wider">
                <Sparkles className="w-3.5 h-3.5" />
                <span>Kalkulasi Otomatis & HPP</span>
              </div>

              <div className="bg-[#090D16] rounded-xl p-4 border border-white/10 space-y-3">
                {/* 1. Beans Used Calculation */}
                <div className="flex items-center justify-between pb-2 border-b border-white/5">
                  <div>
                    <span className="text-xs text-slate-400">Rumus Beans Terpakai</span>
                    <div className="text-xs text-slate-200">
                      {espressoLiterNum} L ÷ {conversionRatio} =
                    </div>
                  </div>
                  <div className="text-right">
                    <div className={`text-xl font-bold font-mono ${isStockInsufficient ? 'text-rose-400' : 'text-amber-400'}`}>
                      -{calculatedBeansUsedKg} kg
                    </div>
                    <div className="text-[10px] text-slate-400">Biji kopi terpakai</div>
                  </div>
                </div>

                {/* 2. Output Espresso */}
                <div className="flex items-center justify-between pb-2 border-b border-white/5">
                  <div>
                    <span className="text-xs text-slate-400">Hasil Espresso</span>
                    <div className="text-xs text-slate-200">Stok bertambah</div>
                  </div>
                  <div className="text-right">
                    <div className="text-xl font-bold font-mono text-emerald-400">
                      +{espressoLiterNum} Liter
                    </div>
                    <div className="text-[10px] text-slate-400">Siap pakai di bar</div>
                  </div>
                </div>

                {/* 3. HPP BEANS PER LITER ESPRESSO (Prompt 2 Requirement 5) */}
                <div className="flex items-center justify-between pt-1">
                  <div>
                    <span className="text-xs font-semibold text-emerald-400">HPP Biji Kopi</span>
                    <div className="text-[10px] text-slate-400">
                      {formatRupiah(costPerKg)} ÷ {conversionRatio}
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-lg font-bold font-mono text-[#F4ECE6]">
                      {formatRupiah(hppPerLiter)}
                      <span className="text-xs font-normal text-[#A8988B]">/L</span>
                    </div>
                    <div className="text-[10px] text-[#7A6A5D]">
                      Total batch: {formatRupiah(totalCostBatch)}
                    </div>
                  </div>
                </div>
              </div>

              {/* Operator info */}
              <div className="p-3 bg-[#150F0D] rounded-xl border border-[#2B1F16] text-xs text-[#9E8E81] flex items-center justify-between">
                <span>Barista Operator:</span>
                <span className="font-semibold text-[#E8DFD8] flex items-center gap-1">
                  <User className="w-3.5 h-3.5 text-[#C5A059]" />
                  {currentUser?.name}
                </span>
              </div>
            </div>

            {/* Riwayat Produksi Ringkas */}
            <div className="bg-[#1A1410] border border-[#2D221A] rounded-2xl p-4 space-y-2">
              <div className="flex items-center justify-between text-xs font-bold text-[#E8DFD8]">
                <span>Batch Terakhir ({productionHistory.length})</span>
                <span className="text-[#C5A059] font-mono">Realtime Supabase</span>
              </div>

              <div className="space-y-2 max-h-[220px] overflow-y-auto">
                {productionHistory.slice(0, 4).map((p) => (
                  <div
                    key={p.id}
                    className="p-2.5 bg-[#140F0C] border border-[#271E17] rounded-xl flex items-center justify-between text-xs"
                  >
                    <div>
                      <div className="font-bold text-[#F4ECE6]">
                        {p.espresso_produced_liter} L Espresso
                      </div>
                      <div className="text-[10px] text-[#8E7E72]">
                        -{p.beans_used_kg} kg {p.beans_item_name}
                      </div>
                      <div className="text-[9px] text-[#6E5E52]">
                        {new Date(p.created_at).toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })} · Oleh: {p.operator_name}
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-mono text-[#C5A059] font-semibold text-[11px]">
                        HPP {formatRupiah(p.hpp_per_liter || 0)}/L
                      </div>
                      {p.waste_liter ? (
                        <div className="text-[10px] text-amber-400">Susut {p.waste_liter} L</div>
                      ) : null}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          SUB-TAB 2: PEMAKAIAN ESPRESSO (Prompt 2 Requirement 3)
      ========================================================================= */}
      {activeSubTab === 'usage' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-6 bg-[#1A1410] border border-[#2D221A] rounded-2xl p-5 shadow-xl">
            <h3 className="text-sm font-bold text-[#F4ECE6] mb-3 flex items-center gap-2">
              <MinusCircle className="w-4 h-4 text-amber-400" />
              <span>Catat Pemakaian Espresso (Serving / Shift)</span>
            </h3>

            {usageSuccessMsg && (
              <div className="mb-4 p-3 bg-emerald-950/70 border border-emerald-800 text-emerald-300 rounded-xl text-xs flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>{usageSuccessMsg}</span>
              </div>
            )}

            {usageErrorMsg && (
              <div className="mb-4 p-3 bg-red-950/70 border border-red-800 text-red-300 rounded-xl text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
                <span>{usageErrorMsg}</span>
              </div>
            )}

            <form onSubmit={handleSubmitUsage} className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-[#C8BCB3] mb-1.5">
                  Item Espresso Base *
                </label>
                <select
                  value={usageEspressoId}
                  onChange={(e) => setUsageEspressoId(e.target.value)}
                  className="w-full px-3 py-2.5 bg-[#120F0D] border border-[#35281E] rounded-xl text-sm text-[#E8DFD8] focus:outline-none focus:border-[#C5A059]"
                  required
                >
                  {espressoItems.map((esp) => (
                    <option key={esp.id} value={esp.id}>
                      {esp.name} (Sisa Stok: {esp.current_stock} Liter)
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-[#C8BCB3] mb-1.5">
                  Jumlah Espresso Digunakan (Liter) *
                </label>
                <input
                  type="number"
                  step="0.05"
                  min="0.05"
                  value={usageAmountLiter}
                  onChange={(e) => setUsageAmountLiter(e.target.value)}
                  placeholder="Contoh: 0.5 atau 1.2"
                  className="w-full px-3 py-2.5 bg-[#120F0D] border border-[#35281E] rounded-xl text-base font-mono text-[#E8DFD8] focus:outline-none focus:border-[#C5A059]"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-[#C8BCB3] mb-1.5">
                  Jenis Pemakaian
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setUsageType('SERVING')}
                    className={`py-2 px-3 rounded-xl text-xs font-semibold border transition-all ${
                      usageType === 'SERVING'
                        ? 'bg-[#C5A059] text-[#120F0D] border-[#C5A059]'
                        : 'bg-[#18120E] text-[#8E7E72] border-[#302218]'
                    }`}
                  >
                    Serving Penjualan
                  </button>
                  <button
                    type="button"
                    onClick={() => setUsageType('WASTE')}
                    className={`py-2 px-3 rounded-xl text-xs font-semibold border transition-all ${
                      usageType === 'WASTE'
                        ? 'bg-amber-500 text-black border-amber-500'
                        : 'bg-[#18120E] text-[#8E7E72] border-[#302218]'
                    }`}
                  >
                    Susut / Waste
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-[#C8BCB3] mb-1.5">
                  Keterangan / Rincian Menu
                </label>
                <input
                  type="text"
                  value={usageNotes}
                  onChange={(e) => setUsageNotes(e.target.value)}
                  placeholder="Contoh: Shift 1 - 25 cup Es Kopi Susu & 10 Americano"
                  className="w-full px-3 py-2 bg-[#120F0D] border border-[#35281E] rounded-xl text-sm text-[#E8DFD8] focus:outline-none focus:border-[#C5A059]"
                />
              </div>

              <button
                type="submit"
                disabled={isSubmittingUsage}
                className="w-full min-h-[44px] flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-black font-bold text-xs sm:text-sm shadow-md transition-all disabled:opacity-50"
              >
                {isSubmittingUsage ? 'Menyimpan...' : 'Simpan Pemakaian Espresso'}
              </button>
            </form>
          </div>

          {/* Usage History List (6 cols) */}
          <div className="lg:col-span-6 bg-[#1A1410] border border-[#2D221A] rounded-2xl p-5 shadow-xl space-y-3">
            <h3 className="text-sm font-bold text-[#F4ECE6] flex items-center gap-2">
              <History className="w-4 h-4 text-[#C5A059]" />
              <span>Riwayat Pemakaian Espresso ({usageHistory.length})</span>
            </h3>

            {usageHistory.length === 0 ? (
              <div className="py-8 text-center text-xs text-[#8E7E72]">
                Belum ada pemakaian espresso yang dicatat.
              </div>
            ) : (
              <div className="space-y-2 max-h-[380px] overflow-y-auto">
                {usageHistory.map((u) => (
                  <div
                    key={u.id}
                    className="p-3 bg-[#140F0C] border border-[#271E17] rounded-xl flex items-center justify-between"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-red-400 font-mono">
                          -{u.amount_liter} Liter
                        </span>
                        <span className="text-[10px] px-2 py-0.5 rounded bg-[#201813] text-[#C5A059] border border-[#302218]">
                          {u.usage_type === 'SERVING' ? 'Serving Menu' : 'Waste'}
                        </span>
                      </div>
                      <div className="text-xs text-[#E8DFD8] mt-0.5">
                        {u.notes || 'Pemakaian Espresso'}
                      </div>
                      <div className="text-[10px] text-[#6E5E52] mt-0.5">
                        {new Date(u.created_at).toLocaleString('id-ID')} · Oleh: {u.operator_name}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* =========================================================================
          SUB-TAB 3: WASTE / SUSUT UMUM (Prompt 2 Requirement 2)
      ========================================================================= */}
      {activeSubTab === 'waste' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-6 bg-[#1A1410] border border-[#2D221A] rounded-2xl p-5 shadow-xl">
            <h3 className="text-sm font-bold text-[#F4ECE6] mb-3 flex items-center gap-2">
              <Flame className="w-4 h-4 text-red-400" />
              <span>Catat Waste / Susut Produksi</span>
            </h3>

            {wasteSuccessMsg && (
              <div className="mb-4 p-3 bg-emerald-950/70 border border-emerald-800 text-emerald-300 rounded-xl text-xs flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>{wasteSuccessMsg}</span>
              </div>
            )}

            {wasteErrorMsg && (
              <div className="mb-4 p-3 bg-red-950/70 border border-red-800 text-red-300 rounded-xl text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
                <span>{wasteErrorMsg}</span>
              </div>
            )}

            <form onSubmit={handleSubmitWaste} className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-[#C8BCB3] mb-1.5">
                  Jenis Bahan Waste *
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setWasteItemType('BEANS');
                      if (beansList.length > 0) setWasteItemId(beansList[0].id);
                    }}
                    className={`py-2 px-3 rounded-xl text-xs font-semibold border transition-all ${
                      wasteItemType === 'BEANS'
                        ? 'bg-[#C5A059] text-[#120F0D] border-[#C5A059]'
                        : 'bg-[#18120E] text-[#8E7E72] border-[#302218]'
                    }`}
                  >
                    Biji Kopi (Beans)
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setWasteItemType('ESPRESSO');
                      if (espressoItems.length > 0) setWasteItemId(espressoItems[0].id);
                    }}
                    className={`py-2 px-3 rounded-xl text-xs font-semibold border transition-all ${
                      wasteItemType === 'ESPRESSO'
                        ? 'bg-[#C5A059] text-[#120F0D] border-[#C5A059]'
                        : 'bg-[#18120E] text-[#8E7E72] border-[#302218]'
                    }`}
                  >
                    Espresso Base
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-[#C8BCB3] mb-1.5">
                  Pilih Item *
                </label>
                <select
                  value={wasteItemId}
                  onChange={(e) => setWasteItemId(e.target.value)}
                  className="w-full px-3 py-2.5 bg-[#120F0D] border border-[#35281E] rounded-xl text-sm text-[#E8DFD8] focus:outline-none focus:border-[#C5A059]"
                  required
                >
                  {(wasteItemType === 'BEANS' ? beansList : espressoItems).map((i) => (
                    <option key={i.id} value={i.id}>
                      {i.name} (Stok: {i.current_stock} {i.unit})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-[#C8BCB3] mb-1.5">
                  Jumlah Terbuang / Susut ({wasteItemType === 'BEANS' ? 'kg' : 'Liter'}) *
                </label>
                <input
                  type="number"
                  step="0.01"
                  min="0.01"
                  value={wasteQty}
                  onChange={(e) => setWasteQty(e.target.value)}
                  placeholder="Contoh: 0.15"
                  className="w-full px-3 py-2.5 bg-[#120F0D] border border-[#35281E] rounded-xl text-base font-mono text-[#E8DFD8] focus:outline-none focus:border-[#C5A059]"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-[#C8BCB3] mb-1.5">
                  Alasan / Penyebab Waste *
                </label>
                <input
                  type="text"
                  value={wasteReason}
                  onChange={(e) => setWasteReason(e.target.value)}
                  placeholder="Contoh: Dial-in grind size ampas basah / tumpah / espresso basi"
                  className="w-full px-3 py-2 bg-[#120F0D] border border-[#35281E] rounded-xl text-sm text-[#E8DFD8] focus:outline-none focus:border-[#C5A059]"
                  required
                />
              </div>

              <button
                type="submit"
                disabled={isSubmittingWaste}
                className="w-full min-h-[44px] flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-red-600 hover:bg-red-500 text-white font-bold text-xs sm:text-sm shadow-md transition-all disabled:opacity-50"
              >
                {isSubmittingWaste ? 'Menyimpan...' : 'Catat Waste'}
              </button>
            </form>
          </div>

          {/* Waste History List (6 cols) */}
          <div className="lg:col-span-6 bg-[#1A1410] border border-[#2D221A] rounded-2xl p-5 shadow-xl space-y-3">
            <h3 className="text-sm font-bold text-[#F4ECE6] flex items-center gap-2">
              <History className="w-4 h-4 text-[#C5A059]" />
              <span>Riwayat Waste & Susut ({wasteHistory.length})</span>
            </h3>

            {wasteHistory.length === 0 ? (
              <div className="py-8 text-center text-xs text-[#8E7E72]">
                Belum ada catatan waste atau susut.
              </div>
            ) : (
              <div className="space-y-2 max-h-[380px] overflow-y-auto">
                {wasteHistory.map((w) => (
                  <div
                    key={w.id}
                    className="p-3 bg-[#140F0C] border border-[#271E17] rounded-xl flex items-center justify-between"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-red-400 font-mono">
                          {w.quantity} {w.unit}
                        </span>
                        <span className="text-[10px] text-[#A8988B] bg-[#221812] px-2 py-0.5 rounded border border-[#35241B]">
                          {w.item_type}
                        </span>
                      </div>
                      <div className="text-xs text-[#E8DFD8] mt-0.5">{w.reason}</div>
                      <div className="text-[10px] text-[#6E5E52] mt-0.5">
                        {new Date(w.created_at).toLocaleString('id-ID')} · Oleh: {w.operator_name}
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-xs font-mono font-bold text-red-400">
                        Kerugian {formatRupiah(w.cost_loss)}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
