export type UserRole = 'MASTER' | 'OWNER' | 'STAFF';

export interface Shop {
  id: string;
  name: string;
  address?: string;
  phone?: string;
  owner_id: string;
  created_at: string;
  conversion_ratio?: number; // Standard: 3 (1 kg beans = 3 L espresso)
}

export interface User {
  id: string;
  username: string;
  name: string;
  role: UserRole;
  password?: string;
  shop_id?: string; // Nullable for MASTER
  is_active: boolean;
  created_at: string;
  phone?: string;
}

export type InventoryCategory = 
  | 'Coffee Beans'
  | 'Dairy & Susu'
  | 'Sirup & Perasa'
  | 'Packaging'
  | 'Espresso Base'
  | 'Bahan Baku Lain'
  | 'Alat & Kebersihan';

export type StockUnit = 'kg' | 'gr' | 'Liter' | 'ml' | 'pcs' | 'pack' | 'botol' | 'can';

export interface InventoryItem {
  id: string;
  shop_id: string;
  name: string;
  category: InventoryCategory;
  unit: StockUnit;
  current_stock: number;
  min_stock: number;
  cost_price: number; // Harga beli per unit (IDR)
  supplier?: string;
  notes?: string;
  updated_at: string;
  created_at: string;
}

export type TransactionType = 
  | 'IN' 
  | 'OUT' 
  | 'PRODUCTION_USE' 
  | 'PRODUCTION_IN' 
  | 'ESPRESSO_USAGE' 
  | 'WASTE' 
  | 'ADJUSTMENT';

export interface StockTransaction {
  id: string;
  shop_id: string;
  item_id: string;
  item_name: string;
  type: TransactionType;
  quantity: number; // Positive change
  previous_stock: number;
  new_stock: number;
  notes?: string;
  reference_id?: string; // e.g., production ID / usage ID
  created_by: string; // User name
  user_id: string;
  created_at: string;
}

export interface ProductionLog {
  id: string;
  shop_id: string;
  beans_item_id: string;
  beans_item_name: string;
  beans_used_kg: number;
  espresso_item_id?: string;
  espresso_produced_liter: number;
  conversion_ratio: number; // e.g. 3.0 (3 Liter / 1 Kg)
  waste_liter?: number; // Susut / waste espresso saat produksi
  cost_per_kg: number; // Harga beli beans per kg saat produksi
  hpp_per_liter: number; // HPP per liter = cost_per_kg ÷ conversion_ratio
  batch_notes?: string;
  operator_name: string;
  user_id: string;
  created_at: string;
}

export interface EspressoUsageLog {
  id: string;
  shop_id: string;
  espresso_item_id: string;
  espresso_item_name: string;
  amount_liter: number;
  usage_type: 'SERVING' | 'WASTE'; // Pemakaian jualan menu vs waste/spillage
  notes?: string;
  operator_name: string;
  user_id: string;
  created_at: string;
}

export interface WasteLog {
  id: string;
  shop_id: string;
  item_type: 'BEANS' | 'ESPRESSO';
  item_id: string;
  item_name: string;
  quantity: number;
  unit: string;
  reason: string;
  cost_loss: number;
  operator_name: string;
  user_id: string;
  created_at: string;
}

export type ExpenseCategory = 
  | 'Beans'
  | 'Bahan Baku'
  | 'Packaging'
  | 'Operasional'
  | 'Listrik'
  | 'Air'
  | 'Transportasi'
  | 'Gaji'
  | 'Lainnya';

export interface Expense {
  id: string;
  shop_id: string;
  category: ExpenseCategory;
  amount: number;
  description: string;
  expense_date: string; // ISO date string
  recorded_by: string;
  user_id: string;
  created_at: string;
}

export interface SupabaseConfig {
  url: string;
  anonKey: string;
  isConnected: boolean;
  lastTested?: string;
}
