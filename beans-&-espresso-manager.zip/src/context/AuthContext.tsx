import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, Shop } from '../types';
import { db, subscribeToDBUpdates } from '../services/database';

interface AuthContextType {
  currentUser: User | null;
  currentShop: Shop | null;
  isLoading: boolean;
  isMaster: boolean;
  isOwner: boolean;
  isStaff: boolean;
  allShops: Shop[];
  login: (username: string, password: string) => Promise<{ success: boolean; error?: string }>;
  logout: () => void;
  switchActiveShop: (shopId: string) => Promise<void>;
  refreshAuthData: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const SESSION_KEY = 'bem_session_user_id';
const ACTIVE_SHOP_OVERRIDE_KEY = 'bem_active_shop_id';

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [currentShop, setCurrentShop] = useState<Shop | null>(null);
  const [allShops, setAllShops] = useState<Shop[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const loadSession = async () => {
    try {
      const savedUserId = localStorage.getItem(SESSION_KEY);
      const shops = await db.getShops();
      setAllShops(shops);

      if (savedUserId) {
        const users = await db.getUsers();
        const found = users.find((u) => u.id === savedUserId && u.is_active);
        if (found) {
          setCurrentUser(found);
          await resolveShopForUser(found, shops);
        } else {
          // If session user not found or inactive, clear session
          localStorage.removeItem(SESSION_KEY);
          setCurrentUser(null);
          setCurrentShop(null);
        }
      } else {
        // Fallback default: automatically login as Master for immediate first-load usability
        const users = await db.getUsers();
        const masterUser = users.find((u) => u.role === 'MASTER');
        if (masterUser) {
          setCurrentUser(masterUser);
          localStorage.setItem(SESSION_KEY, masterUser.id);
          await resolveShopForUser(masterUser, shops);
        }
      }
    } catch (e) {
      console.error('Error loading auth session:', e);
    } finally {
      setIsLoading(false);
    }
  };

  const resolveShopForUser = async (user: User, shopsList?: Shop[]) => {
    const list = shopsList || (await db.getShops());
    setAllShops(list);

    if (user.role === 'MASTER') {
      // Master can select any shop, default to first or saved override
      const savedOverride = localStorage.getItem(ACTIVE_SHOP_OVERRIDE_KEY);
      const targetShop = list.find((s) => s.id === savedOverride) || list[0] || null;
      setCurrentShop(targetShop);
    } else if (user.role === 'OWNER') {
      // Find shop where owner_id is user.id or shop_id matches
      const shop = list.find((s) => s.owner_id === user.id || s.id === user.shop_id) || list[0] || null;
      setCurrentShop(shop);
    } else if (user.role === 'STAFF') {
      // Staff is assigned to specific shop_id
      const shop = list.find((s) => s.id === user.shop_id) || null;
      setCurrentShop(shop);
    }
  };

  useEffect(() => {
    loadSession();

    // Re-verify if database changes happen (realtime or local)
    const unsub = subscribeToDBUpdates(async () => {
      const shops = await db.getShops();
      setAllShops(shops);
      if (currentUser) {
        const users = await db.getUsers();
        const updatedUser = users.find((u) => u.id === currentUser.id);
        if (updatedUser) {
          setCurrentUser(updatedUser);
          await resolveShopForUser(updatedUser, shops);
        }
      }
    });

    return () => unsub();
  }, []);

  const login = async (username: string, password: string): Promise<{ success: boolean; error?: string }> => {
    try {
      const user = await db.findUserByUsername(username);
      if (!user) {
        return { success: false, error: 'Username tidak ditemukan. Periksa kembali username Anda.' };
      }

      if (!user.is_active) {
        return { success: false, error: 'Akun Anda dinonaktifkan. Silakan hubungi Owner atau Master.' };
      }

      if (user.password !== password) {
        return { success: false, error: 'Password salah. Silakan coba lagi.' };
      }

      localStorage.setItem(SESSION_KEY, user.id);
      setCurrentUser(user);
      const shops = await db.getShops();
      await resolveShopForUser(user, shops);

      return { success: true };
    } catch (err: any) {
      return { success: false, error: err?.message || 'Gagal masuk sistem' };
    }
  };

  const logout = () => {
    localStorage.removeItem(SESSION_KEY);
    localStorage.removeItem(ACTIVE_SHOP_OVERRIDE_KEY);
    setCurrentUser(null);
    setCurrentShop(null);
  };

  const switchActiveShop = async (shopId: string) => {
    if (currentUser?.role !== 'MASTER') return;
    localStorage.setItem(ACTIVE_SHOP_OVERRIDE_KEY, shopId);
    const shop = allShops.find((s) => s.id === shopId) || null;
    setCurrentShop(shop);
  };

  const refreshAuthData = async () => {
    await loadSession();
  };

  const isMaster = currentUser?.role === 'MASTER';
  const isOwner = currentUser?.role === 'OWNER';
  const isStaff = currentUser?.role === 'STAFF';

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        currentShop,
        isLoading,
        isMaster,
        isOwner,
        isStaff,
        allShops,
        login,
        logout,
        switchActiveShop,
        refreshAuthData
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
