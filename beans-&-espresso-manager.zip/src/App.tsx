import React, { useState } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { Header } from './components/common/Header';
import { BottomNav, NavTab } from './components/common/BottomNav';
import { LoginView } from './components/auth/LoginView';
import { DashboardView } from './components/dashboard/DashboardView';
import { InventoryView } from './components/inventory/InventoryView';
import { ProductionView } from './components/production/ProductionView';
import { ExpensesView } from './components/expenses/ExpensesView';
import { ReportsView } from './components/reports/ReportsView';
import { AccountManagementView } from './components/accounts/AccountManagementView';
import { SettingsView } from './components/settings/SettingsView';
import { InventoryItem } from './types';

const MainApp: React.FC = () => {
  const { currentUser, isLoading } = useAuth();
  const [activeTab, setActiveTab] = useState<NavTab>('dashboard');
  const [quickRestockItem, setQuickRestockItem] = useState<InventoryItem | null>(null);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#0A0E17] flex items-center justify-center">
        <div className="flex flex-col items-center gap-3">
          <div className="w-10 h-10 border-2 border-emerald-500 border-t-transparent rounded-full animate-spin" />
          <span className="text-xs font-semibold tracking-wider text-slate-400 uppercase">
            Memuat Beans & Espresso Manager...
          </span>
        </div>
      </div>
    );
  }

  if (!currentUser) {
    return <LoginView />;
  }

  const handleQuickRestock = (item: InventoryItem) => {
    setQuickRestockItem(item);
    setActiveTab('inventory');
  };

  return (
    <div className="min-h-screen bg-[#0A0E17] text-[#F1F5F9] flex flex-col relative selection:bg-emerald-500 selection:text-[#0A0E17]">
      {/* Ambient background glows for sophisticated fintech depth */}
      <div className="pointer-events-none fixed inset-0 overflow-hidden z-0 opacity-40">
        <div className="absolute -top-32 -left-32 w-96 h-96 rounded-full bg-blue-600/10 blur-3xl" />
        <div className="absolute top-1/4 -right-32 w-96 h-96 rounded-full bg-emerald-500/10 blur-3xl" />
        <div className="absolute bottom-10 left-1/3 w-80 h-80 rounded-full bg-indigo-600/10 blur-3xl" />
      </div>

      {/* Sticky Top Header */}
      <Header onOpenSettings={() => setActiveTab('settings')} />

      {/* Main Content Area */}
      <main className="flex-1 max-w-6xl w-full mx-auto px-3 sm:px-6 pt-3 sm:pt-5 relative z-10">
        {activeTab === 'dashboard' && (
          <DashboardView
            onNavigate={(tab: NavTab) => setActiveTab(tab)}
            onQuickRestock={handleQuickRestock}
          />
        )}

        {activeTab === 'inventory' && (
          <InventoryView
            initialRestockItem={quickRestockItem}
            onClearInitialRestock={() => setQuickRestockItem(null)}
          />
        )}

        {activeTab === 'production' && <ProductionView />}

        {activeTab === 'expenses' && <ExpensesView />}

        {activeTab === 'reports' && <ReportsView />}

        {activeTab === 'accounts' && <AccountManagementView />}

        {activeTab === 'settings' && <SettingsView />}
      </main>

      {/* Fixed Bottom Thumb Zone Navigation Bar */}
      <BottomNav activeTab={activeTab} onChangeTab={setActiveTab} />
    </div>
  );
};

export default function App() {
  return (
    <AuthProvider>
      <MainApp />
    </AuthProvider>
  );
}
