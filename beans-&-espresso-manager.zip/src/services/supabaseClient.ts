import { createClient, SupabaseClient } from '@supabase/supabase-js';

export const DEFAULT_SUPABASE_URL = 'https://dhgkscdwzhupfiacsxxi.supabase.co';
export const DEFAULT_SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImRoZ2tzY2R3emh1cGZpYWNzeHhpIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTE0NDIxODcsImV4cCI6MjEwNzAxODE4N30.UyRaVC3LC8sc72-lnOyWAz2t74El4Lf75tUWq38P_b0';

const STORAGE_KEY_URL = 'bem_supabase_url';
const STORAGE_KEY_ANON = 'bem_supabase_anon_key';

export function getStoredSupabaseConfig() {
  const envUrl = (import.meta.env.VITE_SUPABASE_URL as string) || DEFAULT_SUPABASE_URL;
  const envAnon = (import.meta.env.VITE_SUPABASE_ANON_KEY as string) || DEFAULT_SUPABASE_ANON_KEY;

  const storedUrl = localStorage.getItem(STORAGE_KEY_URL) || envUrl;
  const storedAnon = localStorage.getItem(STORAGE_KEY_ANON) || envAnon;

  return {
    url: (storedUrl || DEFAULT_SUPABASE_URL).trim(),
    anonKey: (storedAnon || DEFAULT_SUPABASE_ANON_KEY).trim(),
    isConfigured: true
  };
}

export function saveSupabaseConfig(url: string, anonKey: string) {
  localStorage.setItem(STORAGE_KEY_URL, url.trim());
  localStorage.setItem(STORAGE_KEY_ANON, anonKey.trim());
  // Reset cached client
  cachedClient = null;
}

export function clearSupabaseConfig() {
  localStorage.removeItem(STORAGE_KEY_URL);
  localStorage.removeItem(STORAGE_KEY_ANON);
  cachedClient = null;
}

let cachedClient: SupabaseClient | null = null;

export function getSupabaseClient(): SupabaseClient | null {
  const { url, anonKey, isConfigured } = getStoredSupabaseConfig();
  if (!isConfigured) return null;

  if (!cachedClient) {
    try {
      cachedClient = createClient(url, anonKey, {
        auth: {
          persistSession: false,
          autoRefreshToken: false,
          detectSessionInUrl: false
        },
        realtime: {
          params: {
            eventsPerSecond: 15
          }
        }
      });
    } catch (err) {
      console.error('Gagal inisialisasi Supabase client:', err);
      return null;
    }
  }

  return cachedClient;
}

export async function testSupabaseConnection(url: string, anonKey: string): Promise<{ success: boolean; message: string; tablesExist?: boolean }> {
  try {
    if (!url || !anonKey) {
      return { success: false, message: 'URL dan Anon Key wajib diisi.' };
    }

    if (!url.startsWith('https://') || !url.includes('.supabase.co')) {
      return { success: false, message: 'Format URL Supabase harus dimulai dengan https://...supabase.co' };
    }

    const testClient = createClient(url, anonKey, {
      auth: { persistSession: false }
    });

    // Test querying users table or schema
    const { error, data } = await testClient.from('users').select('id').limit(1);

    if (error) {
      // Check if table does not exist
      if (error.code === '42P01' || error.message?.includes('relation "users" does not exist') || error.message?.includes('does not exist')) {
        return { 
          success: true, 
          message: 'Terkoneksi ke Supabase! Namun tabel database belum dibuat. Silakan jalankan Skrip SQL di Supabase SQL Editor.', 
          tablesExist: false 
        };
      }
      return { success: false, message: `Error koneksi: ${error.message} (${error.code || 'unknown'})` };
    }

    return { 
      success: true, 
      message: 'Koneksi Berhasil! Database Supabase siap digunakan & tersinkronisasi realtime.',
      tablesExist: true
    };
  } catch (err: any) {
    return { success: false, message: `Gagal terhubung: ${err?.message || 'Periksa koneksi internet dan kredensial'}` };
  }
}

export const SUPABASE_SQL_SCHEMA = `-- ==============================================================
-- BEANS & ESPRESSO MANAGER (BEM) - SUPABASE DATABASE SCHEMA
-- Jalankan skrip ini di SQL Editor pada Dashboard Supabase Anda
-- ==============================================================

-- 1. Tabel Shops (Toko Kopi)
CREATE TABLE IF NOT EXISTS public.shops (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    address TEXT,
    phone TEXT,
    owner_id TEXT NOT NULL,
    conversion_ratio NUMERIC DEFAULT 3.0,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 2. Tabel Users (Sistem Akun Kustom: Master, Owner, Staff Produksi)
CREATE TABLE IF NOT EXISTS public.users (
    id TEXT PRIMARY KEY,
    username TEXT UNIQUE NOT NULL,
    name TEXT NOT NULL,
    role TEXT NOT NULL CHECK (role IN ('MASTER', 'OWNER', 'STAFF')),
    password TEXT NOT NULL,
    shop_id TEXT REFERENCES public.shops(id) ON DELETE SET NULL,
    is_active BOOLEAN DEFAULT TRUE,
    phone TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 3. Tabel Inventory Items (Stok Biji Kopi & Bahan Baku)
CREATE TABLE IF NOT EXISTS public.inventory_items (
    id TEXT PRIMARY KEY,
    shop_id TEXT NOT NULL REFERENCES public.shops(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    category TEXT NOT NULL,
    unit TEXT NOT NULL,
    current_stock NUMERIC DEFAULT 0,
    min_stock NUMERIC DEFAULT 0,
    cost_price NUMERIC DEFAULT 0,
    supplier TEXT,
    notes TEXT,
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 4. Tabel Stock Transactions (Riwayat Mutasi Stok Realtime)
CREATE TABLE IF NOT EXISTS public.stock_transactions (
    id TEXT PRIMARY KEY,
    shop_id TEXT NOT NULL REFERENCES public.shops(id) ON DELETE CASCADE,
    item_id TEXT NOT NULL REFERENCES public.inventory_items(id) ON DELETE CASCADE,
    item_name TEXT NOT NULL,
    type TEXT NOT NULL CHECK (type IN ('IN', 'OUT', 'PRODUCTION_USE', 'PRODUCTION_IN', 'ESPRESSO_USAGE', 'WASTE', 'ADJUSTMENT')),
    quantity NUMERIC NOT NULL,
    previous_stock NUMERIC NOT NULL,
    new_stock NUMERIC NOT NULL,
    notes TEXT,
    reference_id TEXT,
    created_by TEXT NOT NULL,
    user_id TEXT NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 5. Tabel Productions (Pencatatan Produksi Espresso dari Beans dengan HPP)
CREATE TABLE IF NOT EXISTS public.productions (
    id TEXT PRIMARY KEY,
    shop_id TEXT NOT NULL REFERENCES public.shops(id) ON DELETE CASCADE,
    beans_item_id TEXT NOT NULL,
    beans_item_name TEXT NOT NULL,
    beans_used_kg NUMERIC NOT NULL,
    espresso_item_id TEXT,
    espresso_produced_liter NUMERIC NOT NULL,
    conversion_ratio NUMERIC NOT NULL DEFAULT 3.0,
    waste_liter NUMERIC DEFAULT 0,
    cost_per_kg NUMERIC DEFAULT 0,
    hpp_per_liter NUMERIC DEFAULT 0,
    batch_notes TEXT,
    operator_name TEXT NOT NULL,
    user_id TEXT NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 6. Tabel Espresso Usages (Pencatatan Pemakaian Espresso untuk Serving / Menu)
CREATE TABLE IF NOT EXISTS public.espresso_usages (
    id TEXT PRIMARY KEY,
    shop_id TEXT NOT NULL REFERENCES public.shops(id) ON DELETE CASCADE,
    espresso_item_id TEXT NOT NULL REFERENCES public.inventory_items(id) ON DELETE CASCADE,
    espresso_item_name TEXT NOT NULL,
    amount_liter NUMERIC NOT NULL,
    usage_type TEXT NOT NULL DEFAULT 'SERVING' CHECK (usage_type IN ('SERVING', 'WASTE')),
    notes TEXT,
    operator_name TEXT NOT NULL,
    user_id TEXT NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 7. Tabel Waste Logs (Catat Susut / Waste Beans & Espresso)
CREATE TABLE IF NOT EXISTS public.waste_logs (
    id TEXT PRIMARY KEY,
    shop_id TEXT NOT NULL REFERENCES public.shops(id) ON DELETE CASCADE,
    item_type TEXT NOT NULL CHECK (item_type IN ('BEANS', 'ESPRESSO')),
    item_id TEXT NOT NULL REFERENCES public.inventory_items(id) ON DELETE CASCADE,
    item_name TEXT NOT NULL,
    quantity NUMERIC NOT NULL,
    unit TEXT NOT NULL,
    reason TEXT NOT NULL,
    cost_loss NUMERIC DEFAULT 0,
    operator_name TEXT NOT NULL,
    user_id TEXT NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 8. Tabel Expenses (Pengeluaran Operasional Langsung)
CREATE TABLE IF NOT EXISTS public.expenses (
    id TEXT PRIMARY KEY,
    shop_id TEXT NOT NULL REFERENCES public.shops(id) ON DELETE CASCADE,
    category TEXT NOT NULL CHECK (category IN ('Beans', 'Bahan Baku', 'Packaging', 'Operasional', 'Listrik', 'Air', 'Transportasi', 'Gaji', 'Lainnya')),
    amount NUMERIC NOT NULL,
    description TEXT NOT NULL,
    expense_date TIMESTAMPTZ DEFAULT NOW(),
    recorded_by TEXT NOT NULL,
    user_id TEXT NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- AKTIFKAN ROW LEVEL SECURITY (RLS) DENGAN AKSES ANON
ALTER TABLE public.shops ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.inventory_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.stock_transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.productions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.espresso_usages ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.waste_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.expenses ENABLE ROW LEVEL SECURITY;

DO $$ 
BEGIN
    DROP POLICY IF EXISTS "Anon full access on shops" ON public.shops;
    CREATE POLICY "Anon full access on shops" ON public.shops FOR ALL TO anon USING (true) WITH CHECK (true);

    DROP POLICY IF EXISTS "Anon full access on users" ON public.users;
    CREATE POLICY "Anon full access on users" ON public.users FOR ALL TO anon USING (true) WITH CHECK (true);

    DROP POLICY IF EXISTS "Anon full access on inventory_items" ON public.inventory_items;
    CREATE POLICY "Anon full access on inventory_items" ON public.inventory_items FOR ALL TO anon USING (true) WITH CHECK (true);

    DROP POLICY IF EXISTS "Anon full access on stock_transactions" ON public.stock_transactions;
    CREATE POLICY "Anon full access on stock_transactions" ON public.stock_transactions FOR ALL TO anon USING (true) WITH CHECK (true);

    DROP POLICY IF EXISTS "Anon full access on productions" ON public.productions;
    CREATE POLICY "Anon full access on productions" ON public.productions FOR ALL TO anon USING (true) WITH CHECK (true);

    DROP POLICY IF EXISTS "Anon full access on espresso_usages" ON public.espresso_usages;
    CREATE POLICY "Anon full access on espresso_usages" ON public.espresso_usages FOR ALL TO anon USING (true) WITH CHECK (true);

    DROP POLICY IF EXISTS "Anon full access on waste_logs" ON public.waste_logs;
    CREATE POLICY "Anon full access on waste_logs" ON public.waste_logs FOR ALL TO anon USING (true) WITH CHECK (true);

    DROP POLICY IF EXISTS "Anon full access on expenses" ON public.expenses;
    CREATE POLICY "Anon full access on expenses" ON public.expenses FOR ALL TO anon USING (true) WITH CHECK (true);
END $$;

-- AKTIFKAN SUPABASE REALTIME REPLICATION
ALTER PUBLICATION supabase_realtime ADD TABLE 
    public.shops, 
    public.users, 
    public.inventory_items, 
    public.stock_transactions, 
    public.productions, 
    public.espresso_usages, 
    public.waste_logs, 
    public.expenses;

-- DATA AWAL (SEED): Master Account Tunggal
INSERT INTO public.users (id, username, name, role, password, is_active, created_at)
VALUES 
    ('user_master_real', 'mdqputra@gmail.com', 'M. D. Q. Putra', 'MASTER', '990830', true, NOW())
ON CONFLICT (username) DO UPDATE SET password = EXCLUDED.password, role = 'MASTER';
`;
