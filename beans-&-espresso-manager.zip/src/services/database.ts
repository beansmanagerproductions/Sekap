import { 
  User, 
  Shop, 
  InventoryItem, 
  StockTransaction, 
  ProductionLog, 
  EspressoUsageLog,
  WasteLog,
  Expense,
  TransactionType 
} from '../types';
import { getSupabaseClient, getStoredSupabaseConfig } from './supabaseClient';

// Local storage backup keys
const STORAGE_USERS = 'bem_local_users';
const STORAGE_SHOPS = 'bem_local_shops';
const STORAGE_ITEMS = 'bem_local_items';
const STORAGE_TXS = 'bem_local_transactions';
const STORAGE_PRODUCTIONS = 'bem_local_productions';
const STORAGE_USAGES = 'bem_local_espresso_usages';
const STORAGE_WASTE = 'bem_local_waste_logs';
const STORAGE_EXPENSES = 'bem_local_expenses';

// SEED INITIAL DATA
const SEED_USERS: User[] = [
  {
    id: 'user_master_real',
    username: 'mdqputra@gmail.com',
    name: 'M. D. Q. Putra',
    role: 'MASTER',
    password: '990830',
    is_active: true,
    phone: '081234567890',
    created_at: new Date().toISOString()
  },
  {
    id: 'user_owner_1',
    username: 'owner_senja',
    name: 'Rian Pratama',
    role: 'OWNER',
    password: 'senja123',
    shop_id: 'shop_senja',
    is_active: true,
    phone: '081987654321',
    created_at: new Date(Date.now() - 25 * 86400000).toISOString()
  },
  {
    id: 'user_staff_1',
    username: 'staff_budi',
    name: 'Budi Santoso (Barista)',
    role: 'STAFF',
    password: 'staff123',
    shop_id: 'shop_senja',
    is_active: true,
    phone: '081299887766',
    created_at: new Date(Date.now() - 20 * 86400000).toISOString()
  },
  {
    id: 'user_owner_2',
    username: 'owner_lab',
    name: 'Maya Wijaya',
    role: 'OWNER',
    password: 'lab123',
    shop_id: 'shop_lab',
    is_active: true,
    phone: '081333444555',
    created_at: new Date(Date.now() - 15 * 86400000).toISOString()
  },
  {
    id: 'user_staff_2',
    username: 'staff_dina',
    name: 'Dina Pratiwi (Staff)',
    role: 'STAFF',
    password: 'staff123',
    shop_id: 'shop_lab',
    is_active: true,
    phone: '081555666777',
    created_at: new Date(Date.now() - 10 * 86400000).toISOString()
  }
];

const SEED_SHOPS: Shop[] = [
  {
    id: 'shop_senja',
    name: 'Kopi Senja Artisan',
    address: 'Jl. Senopati No. 42, Jakarta Selatan',
    phone: '081987654321',
    owner_id: 'user_owner_1',
    conversion_ratio: 3.0,
    created_at: new Date(Date.now() - 25 * 86400000).toISOString()
  },
  {
    id: 'shop_lab',
    name: 'Espresso Lab Specialty',
    address: 'Jl. Riau No. 18, Bandung',
    phone: '081333444555',
    owner_id: 'user_owner_2',
    conversion_ratio: 3.0,
    created_at: new Date(Date.now() - 15 * 86400000).toISOString()
  }
];

const SEED_ITEMS: InventoryItem[] = [
  {
    id: 'item_beans_1',
    shop_id: 'shop_senja',
    name: 'Arabica Gayo Washed Single Origin',
    category: 'Coffee Beans',
    unit: 'kg',
    current_stock: 14.0,
    min_stock: 5.0,
    cost_price: 180000, // Rp180.000 / kg -> HPP Rp60.000 / L
    supplier: 'Koperasi Tani Gayo Highland',
    notes: 'Grade 1 Specialty, medium roast untuk batch espresso',
    updated_at: new Date().toISOString(),
    created_at: new Date(Date.now() - 20 * 86400000).toISOString()
  },
  {
    id: 'item_beans_2',
    shop_id: 'shop_senja',
    name: 'House Blend Signature (70 Arabica / 30 Robusta)',
    category: 'Coffee Beans',
    unit: 'kg',
    current_stock: 8.0,
    min_stock: 5.0,
    cost_price: 120000, // Rp120.000 / kg -> HPP Rp40.000 / L
    supplier: 'Roastery Nusantara Utama',
    notes: 'Karakter nutty, dark chocolate, body tebal untuk es kopi susu',
    updated_at: new Date().toISOString(),
    created_at: new Date(Date.now() - 20 * 86400000).toISOString()
  },
  {
    id: 'item_beans_3',
    shop_id: 'shop_senja',
    name: 'Robusta Dampit Natural',
    category: 'Coffee Beans',
    unit: 'kg',
    current_stock: 3.5,
    min_stock: 4.0,
    cost_price: 90000,
    supplier: 'Petani Dampit Malang',
    notes: 'Cadangan base blend',
    updated_at: new Date().toISOString(),
    created_at: new Date(Date.now() - 20 * 86400000).toISOString()
  },
  {
    id: 'item_espresso_1',
    shop_id: 'shop_senja',
    name: 'Espresso Base Concentrate (Fresh Brew)',
    category: 'Espresso Base',
    unit: 'Liter',
    current_stock: 4.2,
    min_stock: 2.0,
    cost_price: 60000,
    supplier: 'Produksi Internal Toko',
    notes: 'Hasil ekstraksi espresso per batch untuk ready-to-serve',
    updated_at: new Date().toISOString(),
    created_at: new Date(Date.now() - 15 * 86400000).toISOString()
  },
  {
    id: 'item_milk_1',
    shop_id: 'shop_senja',
    name: 'Fresh Milk Pasteurisasi Diamond 1L',
    category: 'Dairy & Susu',
    unit: 'Liter',
    current_stock: 22.0,
    min_stock: 8.0,
    cost_price: 21500,
    supplier: 'Distributor Diamond Dairy',
    notes: 'Simpan di chiller 4°C',
    updated_at: new Date().toISOString(),
    created_at: new Date(Date.now() - 15 * 86400000).toISOString()
  },
  {
    id: 'item_milk_2',
    shop_id: 'shop_senja',
    name: 'Oatside Barista Blend Oat Milk 1L',
    category: 'Dairy & Susu',
    unit: 'Liter',
    current_stock: 2.0,
    min_stock: 5.0,
    cost_price: 38000,
    supplier: 'Oatside Official Jakarta',
    notes: 'Untuk menu vegan & plant-based latte',
    updated_at: new Date().toISOString(),
    created_at: new Date(Date.now() - 15 * 86400000).toISOString()
  },
  {
    id: 'item_syrup_1',
    shop_id: 'shop_senja',
    name: 'Sirup Vanilla Monin 700ml',
    category: 'Sirup & Perasa',
    unit: 'botol',
    current_stock: 4.0,
    min_stock: 2.0,
    cost_price: 145000,
    supplier: 'Toffin Indonesia',
    notes: 'Stok aman',
    updated_at: new Date().toISOString(),
    created_at: new Date(Date.now() - 15 * 86400000).toISOString()
  },
  {
    id: 'item_cup_1',
    shop_id: 'shop_senja',
    name: 'Cup Dingin PET 16oz + Tutup Strawless',
    category: 'Packaging',
    unit: 'pcs',
    current_stock: 40.0,
    min_stock: 100.0,
    cost_price: 950,
    supplier: 'Mitra Kemasan Sukses',
    notes: 'Perlu restock segera!',
    updated_at: new Date().toISOString(),
    created_at: new Date(Date.now() - 15 * 86400000).toISOString()
  },
  // Shop 2 Items (Isolated)
  {
    id: 'item_lab_beans_1',
    shop_id: 'shop_lab',
    name: 'Specialty Flores Bajawa Anaerobic',
    category: 'Coffee Beans',
    unit: 'kg',
    current_stock: 7.0,
    min_stock: 3.0,
    cost_price: 180000,
    supplier: 'Bajawa Specialty Direct',
    notes: 'Light-medium roast',
    updated_at: new Date().toISOString(),
    created_at: new Date(Date.now() - 10 * 86400000).toISOString()
  },
  {
    id: 'item_lab_espresso_1',
    shop_id: 'shop_lab',
    name: 'Espresso Base Lab',
    category: 'Espresso Base',
    unit: 'Liter',
    current_stock: 3.0,
    min_stock: 1.5,
    cost_price: 60000,
    supplier: 'Lab Internal',
    notes: 'Batch extraction',
    updated_at: new Date().toISOString(),
    created_at: new Date(Date.now() - 10 * 86400000).toISOString()
  }
];

const SEED_TXS: StockTransaction[] = [
  {
    id: 'tx_1',
    shop_id: 'shop_senja',
    item_id: 'item_beans_1',
    item_name: 'Arabica Gayo Washed Single Origin',
    type: 'IN',
    quantity: 15.0,
    previous_stock: 0,
    new_stock: 15.0,
    notes: 'Penerimaan stok awal dari supplier',
    created_by: 'Rian Pratama',
    user_id: 'user_owner_1',
    created_at: new Date(Date.now() - 5 * 86400000).toISOString()
  },
  {
    id: 'tx_2',
    shop_id: 'shop_senja',
    item_id: 'item_beans_1',
    item_name: 'Arabica Gayo Washed Single Origin',
    type: 'PRODUCTION_USE',
    quantity: 1.0,
    previous_stock: 15.0,
    new_stock: 14.0,
    notes: 'Penggilingan batch 1 kg beans -> 3 L espresso',
    reference_id: 'prod_1',
    created_by: 'Budi Santoso (Barista)',
    user_id: 'user_staff_1',
    created_at: new Date(Date.now() - 2 * 86400000).toISOString()
  },
  {
    id: 'tx_3',
    shop_id: 'shop_senja',
    item_id: 'item_espresso_1',
    item_name: 'Espresso Base Concentrate (Fresh Brew)',
    type: 'PRODUCTION_IN',
    quantity: 3.0,
    previous_stock: 2.0,
    new_stock: 5.0,
    notes: 'Hasil ekstraksi batch pagi (1 kg = 3 L)',
    reference_id: 'prod_1',
    created_by: 'Budi Santoso (Barista)',
    user_id: 'user_staff_1',
    created_at: new Date(Date.now() - 2 * 86400000).toISOString()
  },
  {
    id: 'tx_4',
    shop_id: 'shop_senja',
    item_id: 'item_espresso_1',
    item_name: 'Espresso Base Concentrate (Fresh Brew)',
    type: 'ESPRESSO_USAGE',
    quantity: 0.8,
    previous_stock: 5.0,
    new_stock: 4.2,
    notes: 'Serving pesanan shift siang (Kopi Susu & Americano)',
    reference_id: 'usage_1',
    created_by: 'Budi Santoso (Barista)',
    user_id: 'user_staff_1',
    created_at: new Date(Date.now() - 86400000).toISOString()
  }
];

const SEED_PRODUCTIONS: ProductionLog[] = [
  {
    id: 'prod_1',
    shop_id: 'shop_senja',
    beans_item_id: 'item_beans_1',
    beans_item_name: 'Arabica Gayo Washed Single Origin',
    beans_used_kg: 1.0,
    espresso_item_id: 'item_espresso_1',
    espresso_produced_liter: 3.0,
    conversion_ratio: 3.0,
    waste_liter: 0.05,
    cost_per_kg: 180000,
    hpp_per_liter: 60000,
    batch_notes: 'Batch pagi: 3 Liter Espresso (HPP Rp60.000/L)',
    operator_name: 'Budi Santoso (Barista)',
    user_id: 'user_staff_1',
    created_at: new Date(Date.now() - 2 * 86400000).toISOString()
  }
];

const SEED_USAGES: EspressoUsageLog[] = [
  {
    id: 'usage_1',
    shop_id: 'shop_senja',
    espresso_item_id: 'item_espresso_1',
    espresso_item_name: 'Espresso Base Concentrate (Fresh Brew)',
    amount_liter: 0.8,
    usage_type: 'SERVING',
    notes: 'Serving pesanan shift siang (Kopi Susu & Americano)',
    operator_name: 'Budi Santoso (Barista)',
    user_id: 'user_staff_1',
    created_at: new Date(Date.now() - 86400000).toISOString()
  }
];

const SEED_WASTE: WasteLog[] = [
  {
    id: 'waste_1',
    shop_id: 'shop_senja',
    item_type: 'ESPRESSO',
    item_id: 'item_espresso_1',
    item_name: 'Espresso Base Concentrate (Fresh Brew)',
    quantity: 0.05,
    unit: 'Liter',
    reason: 'Purging & dial-in espresso pagi',
    cost_loss: 3000,
    operator_name: 'Budi Santoso (Barista)',
    user_id: 'user_staff_1',
    created_at: new Date(Date.now() - 2 * 86400000).toISOString()
  }
];

const SEED_EXPENSES: Expense[] = [
  {
    id: 'exp_1',
    shop_id: 'shop_senja',
    category: 'Air',
    amount: 50000,
    description: 'Beli 3 galon air mineral untuk mesin espresso & seduhan',
    expense_date: new Date(Date.now() - 86400000).toISOString(),
    recorded_by: 'Budi Santoso (Barista)',
    user_id: 'user_staff_1',
    created_at: new Date(Date.now() - 86400000).toISOString()
  },
  {
    id: 'exp_2',
    shop_id: 'shop_senja',
    category: 'Operasional',
    amount: 120000,
    description: 'Sabun cuci food-grade, spon, dan kain microfiber bar',
    expense_date: new Date(Date.now() - 2 * 86400000).toISOString(),
    recorded_by: 'Rian Pratama',
    user_id: 'user_owner_1',
    created_at: new Date(Date.now() - 2 * 86400000).toISOString()
  }
];

// Memory/Local Cache Loader
function getLocal<T>(key: string, defaultValue: T): T {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) {
      localStorage.setItem(key, JSON.stringify(defaultValue));
      return defaultValue;
    }
    return JSON.parse(raw);
  } catch {
    return defaultValue;
  }
}

function setLocal<T>(key: string, value: T) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (e) {
    console.error('LocalStorage write error:', e);
  }
}

// Global Event Listeners for local & realtime sync
type DBListener = () => void;
const listeners = new Set<DBListener>();

export function subscribeToDBUpdates(listener: DBListener) {
  listeners.add(listener);
  return () => {
    listeners.delete(listener);
  };
}

function notifyAllListeners() {
  listeners.forEach((l) => {
    try {
      l();
    } catch (e) {
      console.error(e);
    }
  });
}

// Supabase Realtime Channel Subscription
let activeChannel: any = null;
export function initSupabaseRealtimeListener() {
  const supabase = getSupabaseClient();
  if (!supabase || activeChannel) return;

  try {
    activeChannel = supabase
      .channel('bem_realtime_all_v2')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public' },
        (payload) => {
          console.log('[Supabase Realtime Sync Event]:', payload.eventType, payload.table);
          notifyAllListeners();
        }
      )
      .subscribe((status) => {
        console.log('[Supabase Realtime Status]:', status);
      });
  } catch (e) {
    console.error('Failed to init Supabase Realtime channel:', e);
  }
}

// Automatic Initialization for Real Master Account
export async function initializeRealMasterAccount() {
  const masterUser: User = {
    id: 'user_master_real',
    username: 'mdqputra@gmail.com',
    name: 'M. D. Q. Putra',
    role: 'MASTER',
    password: '990830',
    is_active: true,
    created_at: new Date().toISOString()
  };

  // Sync to local storage
  const users = getLocal<User[]>(STORAGE_USERS, SEED_USERS);
  // Remove old demo 'master' account so mdqputra@gmail.com is the ONLY master account
  const cleanList = users.filter((u) => u.username !== 'master' && u.id !== 'user_master_1');
  const existingIdx = cleanList.findIndex((u) => u.username === 'mdqputra@gmail.com');
  if (existingIdx !== -1) {
    cleanList[existingIdx] = { ...cleanList[existingIdx], password: '990830', role: 'MASTER', is_active: true };
  } else {
    cleanList.unshift(masterUser);
  }
  setLocal(STORAGE_USERS, cleanList);

  // Sync to Supabase
  const supabase = getSupabaseClient();
  if (supabase) {
    try {
      await supabase.from('users').upsert([masterUser], { onConflict: 'username' });
      // Delete old demo master from Supabase if exists
      await supabase.from('users').delete().eq('username', 'master');
    } catch (e) {
      console.warn('Real master sync to Supabase notice:', e);
    }
  }
}

// Call on startup
initializeRealMasterAccount().catch(console.error);

// Helper ID Generator
export function generateId(prefix: string): string {
  return `${prefix}_${Date.now().toString(36)}_${Math.random().toString(36).substring(2, 7)}`;
}

/* =========================================================================
   DATABASE OPERATIONS (Dual Engine: Supabase Remote + Local Fallback)
========================================================================= */

export const db = {
  // ------------------ SHOPS ------------------
  async getShops(): Promise<Shop[]> {
    const supabase = getSupabaseClient();
    if (supabase) {
      const { data, error } = await supabase.from('shops').select('*').order('created_at', { ascending: false });
      if (!error && data) return data as Shop[];
    }
    return getLocal<Shop[]>(STORAGE_SHOPS, SEED_SHOPS);
  },

  async getShopById(id: string): Promise<Shop | null> {
    const supabase = getSupabaseClient();
    if (supabase) {
      const { data, error } = await supabase.from('shops').select('*').eq('id', id).maybeSingle();
      if (!error && data) return data as Shop;
    }
    const shops = getLocal<Shop[]>(STORAGE_SHOPS, SEED_SHOPS);
    return shops.find((s) => s.id === id) || null;
  },

  async createShop(shop: Omit<Shop, 'id' | 'created_at'>): Promise<Shop> {
    const newShop: Shop = {
      ...shop,
      id: generateId('shop'),
      conversion_ratio: shop.conversion_ratio || 3.0,
      created_at: new Date().toISOString()
    };

    const supabase = getSupabaseClient();
    if (supabase) {
      await supabase.from('shops').insert([newShop]);
    }

    const shops = getLocal<Shop[]>(STORAGE_SHOPS, SEED_SHOPS);
    shops.unshift(newShop);
    setLocal(STORAGE_SHOPS, shops);
    notifyAllListeners();
    return newShop;
  },

  async updateShop(id: string, updates: Partial<Shop>): Promise<Shop | null> {
    const supabase = getSupabaseClient();
    if (supabase) {
      await supabase.from('shops').update(updates).eq('id', id);
    }
    const shops = getLocal<Shop[]>(STORAGE_SHOPS, SEED_SHOPS);
    const index = shops.findIndex((s) => s.id === id);
    if (index !== -1) {
      shops[index] = { ...shops[index], ...updates };
      setLocal(STORAGE_SHOPS, shops);
      notifyAllListeners();
      return shops[index];
    }
    return null;
  },

  // ------------------ USERS ------------------
  async getUsers(role?: string, shopId?: string): Promise<User[]> {
    const supabase = getSupabaseClient();
    if (supabase) {
      let query = supabase.from('users').select('*').order('created_at', { ascending: false });
      if (role) query = query.eq('role', role);
      if (shopId) query = query.eq('shop_id', shopId);
      const { data, error } = await query;
      if (!error && data) return data as User[];
    }

    let users = getLocal<User[]>(STORAGE_USERS, SEED_USERS);
    if (role) users = users.filter((u) => u.role === role);
    if (shopId) users = users.filter((u) => u.shop_id === shopId);
    return users;
  },

  async findUserByUsername(username: string): Promise<User | null> {
    const clean = username.trim().toLowerCase();
    const supabase = getSupabaseClient();
    if (supabase) {
      const { data, error } = await supabase
        .from('users')
        .select('*')
        .or(`username.eq.${clean},username.eq.${clean.includes('@') ? clean : clean + '@gmail.com'}`)
        .maybeSingle();
      if (!error && data) return data as User;
    }
    const users = getLocal<User[]>(STORAGE_USERS, SEED_USERS);
    return users.find((u) => {
      const uName = u.username.toLowerCase();
      return uName === clean || 
             (clean === 'mdqputra' && uName === 'mdqputra@gmail.com') ||
             (clean === 'mdqputra@gmail.com' && uName === 'mdqputra');
    }) || null;
  },

  async createUser(user: Omit<User, 'id' | 'created_at'>): Promise<User> {
    const cleanUsername = user.username.trim().toLowerCase();
    const users = getLocal<User[]>(STORAGE_USERS, SEED_USERS);
    if (users.some((u) => u.username.toLowerCase() === cleanUsername)) {
      throw new Error(`Username '${cleanUsername}' sudah digunakan.`);
    }

    const newUser: User = {
      ...user,
      id: generateId('user'),
      username: cleanUsername,
      created_at: new Date().toISOString()
    };

    const supabase = getSupabaseClient();
    if (supabase) {
      const { error } = await supabase.from('users').insert([newUser]);
      if (error) {
        console.error('Supabase user insert error:', error);
        throw new Error(`Gagal menyimpan ke Supabase: ${error.message}`);
      }
    }

    users.unshift(newUser);
    setLocal(STORAGE_USERS, users);
    notifyAllListeners();
    return newUser;
  },

  async getMasterUsers(): Promise<User[]> {
    const supabase = getSupabaseClient();
    if (supabase) {
      const { data, error } = await supabase.from('users').select('*').eq('role', 'MASTER').order('created_at', { ascending: false });
      if (!error && data && data.length > 0) return data as User[];
    }
    const users = getLocal<User[]>(STORAGE_USERS, SEED_USERS);
    return users.filter((u) => u.role === 'MASTER');
  },

  async upsertMasterUser(masterData: { username: string; password: string; name: string; phone?: string }): Promise<User> {
    const cleanUsername = masterData.username.trim().toLowerCase();
    const cleanName = masterData.name.trim();
    const cleanPassword = masterData.password.trim();

    if (!cleanUsername) throw new Error('Username Master tidak boleh kosong.');
    if (!cleanPassword) throw new Error('Password Master tidak boleh kosong.');
    if (!cleanName) throw new Error('Nama Master tidak boleh kosong.');

    const users = getLocal<User[]>(STORAGE_USERS, SEED_USERS);
    const existingIndex = users.findIndex((u) => u.username.toLowerCase() === cleanUsername);

    let targetUser: User;
    if (existingIndex !== -1) {
      targetUser = {
        ...users[existingIndex],
        name: cleanName,
        password: cleanPassword,
        role: 'MASTER',
        is_active: true,
        phone: masterData.phone?.trim() || users[existingIndex].phone
      };
      users[existingIndex] = targetUser;
    } else {
      targetUser = {
        id: generateId('master'),
        username: cleanUsername,
        name: cleanName,
        password: cleanPassword,
        role: 'MASTER',
        is_active: true,
        phone: masterData.phone?.trim(),
        created_at: new Date().toISOString()
      };
      users.unshift(targetUser);
    }

    // Save to Supabase if configured
    const supabase = getSupabaseClient();
    if (supabase) {
      const { error } = await supabase
        .from('users')
        .upsert([targetUser], { onConflict: 'username' });
      if (error) {
        console.error('Supabase upsert master error:', error);
        throw new Error(`Gagal menyimpan akun Master ke Supabase: ${error.message}`);
      }
    }

    setLocal(STORAGE_USERS, users);
    notifyAllListeners();
    return targetUser;
  },

  async updateUser(id: string, updates: Partial<User>): Promise<User | null> {
    const supabase = getSupabaseClient();
    if (supabase) {
      await supabase.from('users').update(updates).eq('id', id);
    }
    const users = getLocal<User[]>(STORAGE_USERS, SEED_USERS);
    const index = users.findIndex((u) => u.id === id);
    if (index !== -1) {
      users[index] = { ...users[index], ...updates };
      setLocal(STORAGE_USERS, users);
      notifyAllListeners();
      return users[index];
    }
    return null;
  },

  async deleteUser(id: string): Promise<boolean> {
    const supabase = getSupabaseClient();
    if (supabase) {
      await supabase.from('users').delete().eq('id', id);
    }
    let users = getLocal<User[]>(STORAGE_USERS, SEED_USERS);
    users = users.filter((u) => u.id !== id);
    setLocal(STORAGE_USERS, users);
    notifyAllListeners();
    return true;
  },

  // ------------------ INVENTORY ITEMS ------------------
  async getInventory(shopId: string): Promise<InventoryItem[]> {
    const supabase = getSupabaseClient();
    if (supabase) {
      const { data, error } = await supabase
        .from('inventory_items')
        .select('*')
        .eq('shop_id', shopId)
        .order('name', { ascending: true });
      if (!error && data) return data as InventoryItem[];
    }

    const items = getLocal<InventoryItem[]>(STORAGE_ITEMS, SEED_ITEMS);
    return items.filter((i) => i.shop_id === shopId);
  },

  async getItemById(id: string): Promise<InventoryItem | null> {
    const supabase = getSupabaseClient();
    if (supabase) {
      const { data, error } = await supabase.from('inventory_items').select('*').eq('id', id).maybeSingle();
      if (!error && data) return data as InventoryItem;
    }
    const items = getLocal<InventoryItem[]>(STORAGE_ITEMS, SEED_ITEMS);
    return items.find((i) => i.id === id) || null;
  },

  async createInventoryItem(item: Omit<InventoryItem, 'id' | 'created_at' | 'updated_at'>): Promise<InventoryItem> {
    const now = new Date().toISOString();
    const newItem: InventoryItem = {
      ...item,
      id: generateId('item'),
      created_at: now,
      updated_at: now
    };

    const supabase = getSupabaseClient();
    if (supabase) {
      const { error } = await supabase.from('inventory_items').insert([newItem]);
      if (error) console.error('Supabase item insert error:', error);
    }

    const items = getLocal<InventoryItem[]>(STORAGE_ITEMS, SEED_ITEMS);
    items.unshift(newItem);
    setLocal(STORAGE_ITEMS, items);

    if (newItem.current_stock > 0) {
      await this.recordStockTransactionInternal({
        shop_id: newItem.shop_id,
        item_id: newItem.id,
        item_name: newItem.name,
        type: 'IN',
        quantity: newItem.current_stock,
        previous_stock: 0,
        new_stock: newItem.current_stock,
        notes: 'Stok awal saat penambahan item baru',
        created_by: 'Sistem / Owner',
        user_id: 'system'
      });
    }

    notifyAllListeners();
    return newItem;
  },

  async updateInventoryItem(id: string, updates: Partial<InventoryItem>): Promise<InventoryItem | null> {
    const now = new Date().toISOString();
    const fullUpdates = { ...updates, updated_at: now };

    const supabase = getSupabaseClient();
    if (supabase) {
      await supabase.from('inventory_items').update(fullUpdates).eq('id', id);
    }

    const items = getLocal<InventoryItem[]>(STORAGE_ITEMS, SEED_ITEMS);
    const index = items.findIndex((i) => i.id === id);
    if (index !== -1) {
      items[index] = { ...items[index], ...fullUpdates };
      setLocal(STORAGE_ITEMS, items);
      notifyAllListeners();
      return items[index];
    }
    return null;
  },

  async deleteInventoryItem(id: string): Promise<boolean> {
    const supabase = getSupabaseClient();
    if (supabase) {
      await supabase.from('inventory_items').delete().eq('id', id);
    }

    let items = getLocal<InventoryItem[]>(STORAGE_ITEMS, SEED_ITEMS);
    items = items.filter((i) => i.id !== id);
    setLocal(STORAGE_ITEMS, items);
    notifyAllListeners();
    return true;
  },

  // ------------------ STOCK MOVEMENTS & TRANSACTIONS ------------------
  async recordStockMovement(params: {
    shop_id: string;
    item_id: string;
    type: TransactionType;
    quantity: number;
    notes?: string;
    reference_id?: string;
    user: { id: string; name: string };
  }): Promise<{ item: InventoryItem; transaction: StockTransaction }> {
    const currentItem = await this.getItemById(params.item_id);
    if (!currentItem) {
      throw new Error('Item stok tidak ditemukan.');
    }

    const prev = Number(currentItem.current_stock) || 0;
    let next = prev;
    const qty = Math.abs(Number(params.quantity));

    if (params.type === 'IN' || params.type === 'PRODUCTION_IN') {
      next = prev + qty;
    } else if (
      params.type === 'OUT' || 
      params.type === 'PRODUCTION_USE' || 
      params.type === 'ESPRESSO_USAGE' || 
      params.type === 'WASTE'
    ) {
      if (prev < qty) {
        throw new Error(
          `Stok tidak mencukupi! Stok saat ini: ${prev} ${currentItem.unit}, diminta keluar: ${qty} ${currentItem.unit}. Tidak boleh menghasilkan stok negatif.`
        );
      }
      next = prev - qty;
    } else if (params.type === 'ADJUSTMENT') {
      next = Number(params.quantity);
      if (next < 0) {
        throw new Error('Stok fisik hasil opname tidak boleh bernilai negatif.');
      }
    }

    // Rounding safety for floating numbers (e.g. 0.333 L)
    next = Math.round(next * 1000) / 1000;

    // 1. Update item stock
    await this.updateInventoryItem(currentItem.id, { current_stock: next });
    const updatedItem = { ...currentItem, current_stock: next, updated_at: new Date().toISOString() };

    // 2. Insert transaction record
    const tx = await this.recordStockTransactionInternal({
      shop_id: params.shop_id,
      item_id: currentItem.id,
      item_name: currentItem.name,
      type: params.type,
      quantity: params.type === 'ADJUSTMENT' ? Math.abs(next - prev) : qty,
      previous_stock: prev,
      new_stock: next,
      notes: params.notes || '',
      reference_id: params.reference_id,
      created_by: params.user.name,
      user_id: params.user.id
    });

    notifyAllListeners();
    return { item: updatedItem, transaction: tx };
  },

  async recordStockTransactionInternal(data: Omit<StockTransaction, 'id' | 'created_at'>): Promise<StockTransaction> {
    const newTx: StockTransaction = {
      ...data,
      id: generateId('tx'),
      created_at: new Date().toISOString()
    };

    const supabase = getSupabaseClient();
    if (supabase) {
      await supabase.from('stock_transactions').insert([newTx]);
    }

    const txs = getLocal<StockTransaction[]>(STORAGE_TXS, SEED_TXS);
    txs.unshift(newTx);
    setLocal(STORAGE_TXS, txs);
    return newTx;
  },

  async getTransactions(shopId: string, itemId?: string, limit = 100): Promise<StockTransaction[]> {
    const supabase = getSupabaseClient();
    if (supabase) {
      let query = supabase
        .from('stock_transactions')
        .select('*')
        .eq('shop_id', shopId)
        .order('created_at', { ascending: false })
        .limit(limit);

      if (itemId) query = query.eq('item_id', itemId);
      const { data, error } = await query;
      if (!error && data) return data as StockTransaction[];
    }

    let txs = getLocal<StockTransaction[]>(STORAGE_TXS, SEED_TXS);
    txs = txs.filter((t) => t.shop_id === shopId);
    if (itemId) txs = txs.filter((t) => t.item_id === itemId);
    return txs.slice(0, limit);
  },

  // ------------------ PRODUCTIONS (PROMPT 2 FORMULA: ESPRESSO -> BEANS) ------------------
  async recordProduction(params: {
    shop_id: string;
    beans_item_id: string;
    espresso_produced_liter: number; // Staff inputs actual Espresso produced!
    espresso_item_id?: string;
    conversion_ratio?: number; // active ratio from shop, e.g. 3.0
    waste_liter?: number; // Susut / waste during production
    batch_notes?: string;
    user: { id: string; name: string };
  }): Promise<ProductionLog> {
    const beansItem = await this.getItemById(params.beans_item_id);
    if (!beansItem) {
      throw new Error('Biji kopi (Beans) tidak ditemukan.');
    }

    const ratio = params.conversion_ratio || 3.0;
    if (ratio <= 0) {
      throw new Error('Rasio konversi tidak valid.');
    }

    // Formula specified in Prompt 2:
    // Beans terpakai = Espresso diproduksi ÷ Rasio (default ÷ 3)
    // Contoh: 1,5 L -> 0,5 KG Beans; 2,8 L -> 0,933 KG Beans
    const beansUsedKg = Math.round((params.espresso_produced_liter / ratio) * 1000) / 1000;

    // Check negative stock restriction: "Jangan izinkan stok Beans negatif."
    const availableBeans = Number(beansItem.current_stock) || 0;
    if (availableBeans < beansUsedKg) {
      throw new Error(
        `Stok Beans tidak mencukupi! Dibutuhkan: ${beansUsedKg} kg untuk menghasilkan ${params.espresso_produced_liter} L Espresso, namun stok saat ini hanya ${availableBeans} kg. Transaksi dibatalkan agar stok tidak negatif.`
      );
    }

    // HPP Calculation specified in Prompt 2:
    // Contoh: 1 KG Beans = Rp180.000, 1 KG = 3 L Espresso -> HPP Beans = Rp60.000/L
    const costPerKg = Number(beansItem.cost_price) || 0;
    const hppPerLiter = Math.round(costPerKg / ratio);

    const prodId = generateId('prod');
    const wasteLiter = Number(params.waste_liter) || 0;

    const newProd: ProductionLog = {
      id: prodId,
      shop_id: params.shop_id,
      beans_item_id: beansItem.id,
      beans_item_name: beansItem.name,
      beans_used_kg: beansUsedKg,
      espresso_item_id: params.espresso_item_id,
      espresso_produced_liter: params.espresso_produced_liter,
      conversion_ratio: ratio,
      waste_liter: wasteLiter,
      cost_per_kg: costPerKg,
      hpp_per_liter: hppPerLiter,
      batch_notes: params.batch_notes || '',
      operator_name: params.user.name,
      user_id: params.user.id,
      created_at: new Date().toISOString()
    };

    // 1. Deduct beans stock automatically
    await this.recordStockMovement({
      shop_id: params.shop_id,
      item_id: beansItem.id,
      type: 'PRODUCTION_USE',
      quantity: beansUsedKg,
      notes: `Produksi Espresso #${prodId.slice(-5)}: ${params.espresso_produced_liter} L Espresso (HPP Rp${hppPerLiter.toLocaleString('id-ID')}/L)`,
      reference_id: prodId,
      user: params.user
    });

    // 2. Add espresso stock to target espresso item
    let targetEspressoItemId = params.espresso_item_id;
    if (!targetEspressoItemId) {
      const items = await this.getInventory(params.shop_id);
      const defaultEspresso = items.find((i) => i.category === 'Espresso Base');
      if (defaultEspresso) {
        targetEspressoItemId = defaultEspresso.id;
      } else {
        const createdEspresso = await this.createInventoryItem({
          shop_id: params.shop_id,
          name: 'Espresso Base Concentrate',
          category: 'Espresso Base',
          unit: 'Liter',
          current_stock: 0,
          min_stock: 2.0,
          cost_price: hppPerLiter,
          supplier: 'Produksi Internal Bar',
          notes: 'Dihasilkan otomatis dari modul produksi'
        });
        targetEspressoItemId = createdEspresso.id;
      }
      newProd.espresso_item_id = targetEspressoItemId;
    }

    if (targetEspressoItemId) {
      await this.recordStockMovement({
        shop_id: params.shop_id,
        item_id: targetEspressoItemId,
        type: 'PRODUCTION_IN',
        quantity: params.espresso_produced_liter,
        notes: `Hasil Produksi dari ${beansUsedKg} kg ${beansItem.name} (Rasio 1:${ratio})`,
        reference_id: prodId,
        user: params.user
      });

      // Update espresso item cost_price with latest HPP
      await this.updateInventoryItem(targetEspressoItemId, { cost_price: hppPerLiter });
    }

    // 3. If waste occurred during production, record to waste_logs
    if (wasteLiter > 0 && targetEspressoItemId) {
      await this.recordWasteInternal({
        shop_id: params.shop_id,
        item_type: 'ESPRESSO',
        item_id: targetEspressoItemId,
        item_name: 'Espresso Base (Susut Produksi)',
        quantity: wasteLiter,
        unit: 'Liter',
        reason: `Susut/waste produksi batch #${prodId.slice(-5)}`,
        cost_loss: Math.round(wasteLiter * hppPerLiter),
        operator_name: params.user.name,
        user_id: params.user.id
      });
    }

    // 4. Save production log
    const supabase = getSupabaseClient();
    if (supabase) {
      await supabase.from('productions').insert([newProd]);
    }

    const prods = getLocal<ProductionLog[]>(STORAGE_PRODUCTIONS, SEED_PRODUCTIONS);
    prods.unshift(newProd);
    setLocal(STORAGE_PRODUCTIONS, prods);

    notifyAllListeners();
    return newProd;
  },

  async getProductions(shopId: string, limit = 100): Promise<ProductionLog[]> {
    const supabase = getSupabaseClient();
    if (supabase) {
      const { data, error } = await supabase
        .from('productions')
        .select('*')
        .eq('shop_id', shopId)
        .order('created_at', { ascending: false })
        .limit(limit);
      if (!error && data) return data as ProductionLog[];
    }

    const prods = getLocal<ProductionLog[]>(STORAGE_PRODUCTIONS, SEED_PRODUCTIONS);
    return prods.filter((p) => p.shop_id === shopId).slice(0, limit);
  },

  // ------------------ ESPRESSO USAGE (PEMAKAIAN ESPRESSO) ------------------
  async recordEspressoUsage(params: {
    shop_id: string;
    espresso_item_id: string;
    amount_liter: number;
    usage_type: 'SERVING' | 'WASTE';
    notes?: string;
    user: { id: string; name: string };
  }): Promise<EspressoUsageLog> {
    const espressoItem = await this.getItemById(params.espresso_item_id);
    if (!espressoItem) {
      throw new Error('Item Espresso tidak ditemukan.');
    }

    const available = Number(espressoItem.current_stock) || 0;
    const requested = Number(params.amount_liter) || 0;

    if (requested <= 0) {
      throw new Error('Jumlah pemakaian Espresso harus lebih dari 0 Liter.');
    }

    // Restriction: "Stok Espresso otomatis berkurang dan tidak boleh negatif."
    if (available < requested) {
      throw new Error(
        `Stok Espresso tidak cukup! Sisa stok saat ini: ${available} Liter, diminta: ${requested} Liter. Stok tidak boleh bernilai negatif.`
      );
    }

    const usageId = generateId('use');
    const newUsage: EspressoUsageLog = {
      id: usageId,
      shop_id: params.shop_id,
      espresso_item_id: espressoItem.id,
      espresso_item_name: espressoItem.name,
      amount_liter: requested,
      usage_type: params.usage_type,
      notes: params.notes || '',
      operator_name: params.user.name,
      user_id: params.user.id,
      created_at: new Date().toISOString()
    };

    // Deduct stock
    await this.recordStockMovement({
      shop_id: params.shop_id,
      item_id: espressoItem.id,
      type: params.usage_type === 'WASTE' ? 'WASTE' : 'ESPRESSO_USAGE',
      quantity: requested,
      notes: params.notes || (params.usage_type === 'SERVING' ? 'Pemakaian serving menu kopi' : 'Susut/waste espresso'),
      reference_id: usageId,
      user: params.user
    });

    const supabase = getSupabaseClient();
    if (supabase) {
      await supabase.from('espresso_usages').insert([newUsage]);
    }

    const usages = getLocal<EspressoUsageLog[]>(STORAGE_USAGES, SEED_USAGES);
    usages.unshift(newUsage);
    setLocal(STORAGE_USAGES, usages);

    notifyAllListeners();
    return newUsage;
  },

  async getEspressoUsages(shopId: string, limit = 100): Promise<EspressoUsageLog[]> {
    const supabase = getSupabaseClient();
    if (supabase) {
      const { data, error } = await supabase
        .from('espresso_usages')
        .select('*')
        .eq('shop_id', shopId)
        .order('created_at', { ascending: false })
        .limit(limit);
      if (!error && data) return data as EspressoUsageLog[];
    }

    const usages = getLocal<EspressoUsageLog[]>(STORAGE_USAGES, SEED_USAGES);
    return usages.filter((u) => u.shop_id === shopId).slice(0, limit);
  },

  // ------------------ WASTE / SUSUT LOGS ------------------
  async recordWaste(params: {
    shop_id: string;
    item_type: 'BEANS' | 'ESPRESSO';
    item_id: string;
    quantity: number;
    reason: string;
    user: { id: string; name: string };
  }): Promise<WasteLog> {
    const item = await this.getItemById(params.item_id);
    if (!item) {
      throw new Error('Item tidak ditemukan.');
    }

    const available = Number(item.current_stock) || 0;
    const requested = Number(params.quantity) || 0;

    if (requested <= 0) {
      throw new Error('Jumlah susut/waste harus lebih dari 0.');
    }

    if (available < requested) {
      throw new Error(`Stok tidak mencukupi untuk mencatat waste sebesar ${requested} ${item.unit}. Sisa stok: ${available} ${item.unit}.`);
    }

    const costLoss = Math.round(requested * Number(item.cost_price));

    // Deduct item stock
    await this.recordStockMovement({
      shop_id: params.shop_id,
      item_id: item.id,
      type: 'WASTE',
      quantity: requested,
      notes: `Waste: ${params.reason}`,
      user: params.user
    });

    const wasteLog = await this.recordWasteInternal({
      shop_id: params.shop_id,
      item_type: params.item_type,
      item_id: item.id,
      item_name: item.name,
      quantity: requested,
      unit: item.unit,
      reason: params.reason,
      cost_loss: costLoss,
      operator_name: params.user.name,
      user_id: params.user.id
    });

    notifyAllListeners();
    return wasteLog;
  },

  async recordWasteInternal(data: Omit<WasteLog, 'id' | 'created_at'>): Promise<WasteLog> {
    const newLog: WasteLog = {
      ...data,
      id: generateId('waste'),
      created_at: new Date().toISOString()
    };

    const supabase = getSupabaseClient();
    if (supabase) {
      await supabase.from('waste_logs').insert([newLog]);
    }

    const logs = getLocal<WasteLog[]>(STORAGE_WASTE, SEED_WASTE);
    logs.unshift(newLog);
    setLocal(STORAGE_WASTE, logs);
    return newLog;
  },

  async getWasteLogs(shopId: string, limit = 100): Promise<WasteLog[]> {
    const supabase = getSupabaseClient();
    if (supabase) {
      const { data, error } = await supabase
        .from('waste_logs')
        .select('*')
        .eq('shop_id', shopId)
        .order('created_at', { ascending: false })
        .limit(limit);
      if (!error && data) return data as WasteLog[];
    }

    const logs = getLocal<WasteLog[]>(STORAGE_WASTE, SEED_WASTE);
    return logs.filter((w) => w.shop_id === shopId).slice(0, limit);
  },

  // ------------------ EXPENSES ------------------
  async recordExpense(params: {
    shop_id: string;
    category: Expense['category'];
    amount: number;
    description: string;
    expense_date?: string;
    user: { id: string; name: string };
  }): Promise<Expense> {
    const newExpense: Expense = {
      id: generateId('exp'),
      shop_id: params.shop_id,
      category: params.category,
      amount: Number(params.amount),
      description: params.description.trim(),
      expense_date: params.expense_date || new Date().toISOString(),
      recorded_by: params.user.name,
      user_id: params.user.id,
      created_at: new Date().toISOString()
    };

    const supabase = getSupabaseClient();
    if (supabase) {
      await supabase.from('expenses').insert([newExpense]);
    }

    const expenses = getLocal<Expense[]>(STORAGE_EXPENSES, SEED_EXPENSES);
    expenses.unshift(newExpense);
    setLocal(STORAGE_EXPENSES, expenses);

    notifyAllListeners();
    return newExpense;
  },

  async getExpenses(shopId: string, limit = 100): Promise<Expense[]> {
    const supabase = getSupabaseClient();
    if (supabase) {
      const { data, error } = await supabase
        .from('expenses')
        .select('*')
        .eq('shop_id', shopId)
        .order('expense_date', { ascending: false })
        .limit(limit);
      if (!error && data) return data as Expense[];
    }

    const expenses = getLocal<Expense[]>(STORAGE_EXPENSES, SEED_EXPENSES);
    return expenses.filter((e) => e.shop_id === shopId).slice(0, limit);
  },

  // ------------------ SYNC LOCAL SEED TO SUPABASE ------------------
  async pushLocalDataToSupabase(): Promise<{ success: boolean; message: string }> {
    const supabase = getSupabaseClient();
    if (!supabase) {
      return { success: false, message: 'Supabase client belum terkonfigurasi.' };
    }

    try {
      const shops = getLocal<Shop[]>(STORAGE_SHOPS, SEED_SHOPS);
      const users = getLocal<User[]>(STORAGE_USERS, SEED_USERS);
      const items = getLocal<InventoryItem[]>(STORAGE_ITEMS, SEED_ITEMS);
      const txs = getLocal<StockTransaction[]>(STORAGE_TXS, SEED_TXS);
      const prods = getLocal<ProductionLog[]>(STORAGE_PRODUCTIONS, SEED_PRODUCTIONS);
      const usages = getLocal<EspressoUsageLog[]>(STORAGE_USAGES, SEED_USAGES);
      const waste = getLocal<WasteLog[]>(STORAGE_WASTE, SEED_WASTE);
      const expenses = getLocal<Expense[]>(STORAGE_EXPENSES, SEED_EXPENSES);

      if (shops.length > 0) {
        await supabase.from('shops').upsert(shops, { onConflict: 'id' });
      }
      if (users.length > 0) {
        await supabase.from('users').upsert(users, { onConflict: 'username' });
      }
      if (items.length > 0) {
        await supabase.from('inventory_items').upsert(items, { onConflict: 'id' });
      }
      if (txs.length > 0) {
        await supabase.from('stock_transactions').upsert(txs, { onConflict: 'id' });
      }
      if (prods.length > 0) {
        await supabase.from('productions').upsert(prods, { onConflict: 'id' });
      }
      if (usages.length > 0) {
        await supabase.from('espresso_usages').upsert(usages, { onConflict: 'id' });
      }
      if (waste.length > 0) {
        await supabase.from('waste_logs').upsert(waste, { onConflict: 'id' });
      }
      if (expenses.length > 0) {
        await supabase.from('expenses').upsert(expenses, { onConflict: 'id' });
      }

      notifyAllListeners();
      return { success: true, message: 'Seluruh data berhasil disinkronkan ke Supabase!' };
    } catch (e: any) {
      return { success: false, message: `Gagal sinkronisasi data: ${e?.message || 'Error'}` };
    }
  }
};
